# Fast Player (MX Player-style) — Kotlin + Jetpack Compose + Media3
Upload this ZIP to GitHub, add .github/workflows/build.yml (see chat), run the workflow, download FastPlayer.apk from Releases.
Requirements: JDK 17, compileSdk 34, minSdk 29.
