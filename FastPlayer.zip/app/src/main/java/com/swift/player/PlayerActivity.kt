@file:OptIn(UnstableApi::class)

package com.swift.player

import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Rational
import android.view.LayoutInflater
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : ComponentActivity() {
    lateinit var player: ExoPlayer
    lateinit var queue: List<QItem>
    private var ready = false
    private var listener: Player.Listener? = null
    private val handler = Handler(Looper.getMainLooper())
    private val sleepRun = Runnable { if (ready) player.pause(); sleepMin = 0 }
    var inPip by mutableStateOf(false)
    var audioOnly by mutableStateOf(false)
    var sleepMin by mutableIntStateOf(0)
    private var bright = -1f
    private var volF = -1f
    private val am by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)

        val d = intent?.data
        val attach = intent?.getBooleanExtra("attach", false) == true && PlayerHolder.player != null
        queue = if (!attach && d != null)
            listOf(QItem(d.toString(), d.lastPathSegment ?: "Media", intent.type?.startsWith("audio") == true))
        else PlayQueue.items
        if (queue.isEmpty()) { finish(); return }
        if (!attach && d != null) PlayQueue.items = queue
        val start = if (attach || d != null) 0 else intent.getIntExtra("index", 0).coerceIn(0, queue.size - 1)
        ready = true
        PlayerHolder.alive++

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).run {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        requestedOrientation = when (Prefs.orient) {
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            "system" -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR
        }

        player = PlayerHolder.get(this)
        val l = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                saveLast()
                updateKeep()
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && !Prefs.autoNext) player.pause()
                if (isAudioNow()) ensureService()
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (Prefs.orient == "video" && videoSize.width > 0) requestedOrientation =
                    if (videoSize.width >= videoSize.height) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }
        listener = l
        player.addListener(l)

        if (attach) {
            audioOnly = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_VIDEO)
        } else {
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().clearOverrides()
                .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
            player.setPlaybackSpeed(1f)
            player.repeatMode = if (Prefs.loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            val items = queue.map {
                MediaItem.Builder().setUri(it.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).build()).build()
            }
            val sp = if (Prefs.resume) Prefs.pos(queue[start].uri) else 0L
            player.setMediaItems(items, start, if (sp > 0) sp else C.TIME_UNSET)
            player.prepare()
            player.playWhenReady = true
        }
        updateKeep()
        if (isAudioNow()) ensureService()
        setContent { AppTheme { PlayerScreen(this) } }
    }

    fun isAudioNow(): Boolean = audioOnly || queue.getOrNull(player.currentMediaItemIndex)?.audio == true

    /** Keep the screen on only while a VIDEO is on screen. Audio never forces the screen on. */
    fun updateKeep() {
        if (!ready) return
        if (Prefs.keepOn && !isAudioNow()) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun ensureService() {
        try { ContextCompat.startForegroundService(this, Intent(this, AudioService::class.java)) } catch (_: Exception) {}
    }
    private fun stopSvc() { try { stopService(Intent(this, AudioService::class.java)) } catch (_: Exception) {} }

    fun saveLast() {
        if (!ready) return
        val q = queue.getOrNull(player.currentMediaItemIndex) ?: return
        val dur = player.duration; val p = player.currentPosition
        Prefs.setPos(q.uri, if (dur > 0 && p > dur - 3000) 0 else p)
        Prefs.lastUri = q.uri; Prefs.lastTitle = q.title; Prefs.lastAudio = q.audio; Prefs.save()
    }

    override fun onStop() {
        super.onStop()
        if (!ready) return
        saveLast()
        if (PlayerHolder.alive <= 1 && !isInPictureInPictureMode && !isAudioNow()) player.pause()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (ready && Prefs.pipHome && player.isPlaying && !isAudioNow()) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        if (!ready) return
        listener?.let { player.removeListener(it) }
        saveLast()
        PlayerHolder.alive--
        // Audio keeps playing in the background (notification); video stops and frees memory.
        val keep = player.isPlaying && isAudioNow()
        if (!keep && PlayerHolder.alive == 0) { stopSvc(); PlayerHolder.release() }
    }

    fun enterPip() {
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        } catch (_: Exception) {}
    }

    /** Headphone button: play as audio only (screen can be turned off, playback continues). */
    fun applyAudioOnly(v: Boolean) {
        audioOnly = v
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, v).build()
        if (v) ensureService() else if (!isAudioNow()) stopSvc()
        updateKeep()
    }

    fun setSleep(min: Int) {
        handler.removeCallbacks(sleepRun)
        sleepMin = min
        if (min > 0) handler.postDelayed(sleepRun, min * 60_000L)
    }

    fun addSubtitle(u: Uri) {
        val name = (u.lastPathSegment ?: "").lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val i = player.currentMediaItemIndex
        val cur = player.currentMediaItem ?: return
        val pos = player.currentPosition
        val sub = MediaItem.SubtitleConfiguration.Builder(u).setMimeType(mime).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        player.replaceMediaItem(i, cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build())
        player.seekTo(i, pos)
    }

    // ---- System brightness (window) / system media volume ----
    fun addBright(f: Float): Int {
        if (bright < 0) bright = try {
            android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Exception) { 0.5f }
        bright = (bright + f).coerceIn(0.01f, 1f)
        window.attributes = window.attributes.also { it.screenBrightness = bright }
        return (bright * 100).roundToInt()
    }
    fun syncVol() { volF = -1f }
    fun addVolume(f: Float): Int {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (volF < 0) volF = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
        volF = (volF + f).coerceIn(0f, 1f)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (volF * max).roundToInt(), 0)
        return (volF * 100).roundToInt()
    }
}

// ------------------------------------------------------------------ UI pieces

@Composable
fun CtlBtn(icon: ImageVector, desc: String, active: Boolean = false, onClick: () -> Unit) {
    IconButton(
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 10.dp).size(44.dp)
            .background(if (active) Color(0xFF2F6BFF) else Color(0x44FFFFFF), CircleShape)
    ) { Icon(icon, desc, tint = Color.White) }
}

@Composable
fun Pill(text: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color(0x66000000), shape = RoundedCornerShape(50)) {
        Text(text, color = Color(0xEEFFFFFF), fontSize = 18.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
    }
}

@Composable
fun PLabel(t: String) {
    Text(t, Modifier.padding(top = 14.dp, bottom = 4.dp), color = Color(0xFF8FB3FF), style = MaterialTheme.typography.labelLarge)
}

@Composable
fun PChoice(name: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(10.dp))
        Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun PSwitch(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

fun trackName(g: Tracks.Group, i: Int): String {
    val f = g.getTrackFormat(0)
    val lang = f.language?.takeIf { it != "und" }?.let { Locale(it).displayLanguage }
    return listOfNotNull(f.label, lang).distinct().joinToString(" · ").ifEmpty { "Track ${i + 1}" }
}

@Composable
fun TrackSection(title: String, p: ExoPlayer, tracks: Tracks, type: Int, offOption: Boolean) {
    val groups = tracks.groups.filter { it.type == type && it.length > 0 }
    PLabel(title)
    if (groups.isEmpty()) {
        Text(if (type == C.TRACK_TYPE_TEXT) "No subtitles in this file" else "Only one track", color = Color(0x99FFFFFF), fontSize = 13.sp)
        return
    }
    var sel by remember { mutableIntStateOf(groups.indexOfFirst { it.isSelected }) }
    if (offOption) PChoice("Off", sel == -1) {
        sel = -1
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(type, true).build()
    }
    groups.forEachIndexed { i, g ->
        PChoice(trackName(g, i), sel == i) {
            sel = i
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(type, false)
                .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
        }
    }
}

@Composable
fun BoxScope.SidePanel(visible: Boolean, width: Dp, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AnimatedVisibility(visible, enter = fadeIn(), exit = fadeOut()) {
        Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose))
    }
    AnimatedVisibility(
        visible, modifier = Modifier.align(Alignment.CenterEnd),
        enter = slideInHorizontally { it } + fadeIn(), exit = slideOutHorizontally { it } + fadeOut()
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF6FA0FF))) {
            Surface(Modifier.fillMaxHeight().width(width), color = Color(0xB3121212), contentColor = Color.White) {
                Column(Modifier.displayCutoutPadding().verticalScroll(rememberScrollState()).padding(16.dp), content = content)
            }
        }
    }
}

@Composable
fun BoxScope.CenterPanel(visible: Boolean, wFrac: Float, hFrac: Float, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AnimatedVisibility(visible, enter = fadeIn(), exit = fadeOut()) {
        Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose))
    }
    AnimatedVisibility(
        visible, modifier = Modifier.align(Alignment.Center),
        enter = scaleIn(initialScale = 0.92f) + fadeIn(), exit = scaleOut(targetScale = 0.92f) + fadeOut()
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF6FA0FF))) {
            Surface(
                Modifier.fillMaxWidth(wFrac).fillMaxHeight(hFrac),
                color = Color(0xB3121212), contentColor = Color.White, shape = RoundedCornerShape(18.dp)
            ) { Column(Modifier.padding(14.dp), content = content) }
        }
    }
}

val EQ_PRESETS = listOf(
    "Flat" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Bass" to floatArrayOf(7f, 7f, 6f, 5f, 3f, 1f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Treble" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 2f, 3f, 4f, 5f, 6f, 6f),
    "Vocal" to floatArrayOf(-2f, -2f, -1f, 0f, 0f, 1f, 2f, 3f, 4f, 4f, 3f, 2f, 0f, -1f, -2f),
    "Rock" to floatArrayOf(5f, 4f, 3f, 2f, 0f, -1f, -2f, -1f, 1f, 2f, 3f, 4f, 4f, 4f, 3f),
    "Pop" to floatArrayOf(-1f, 0f, 1f, 2f, 3f, 3f, 2f, 0f, -1f, -1f, 0f, 1f, 2f, 2f, 1f),
    "Classical" to floatArrayOf(4f, 3f, 3f, 2f, 2f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 2f, 3f, 3f),
    "Loudness" to floatArrayOf(6f, 5f, 4f, 2f, 0f, 0f, -1f, 0f, 0f, 0f, 0f, 1f, 3f, 4f, 4f)
)

@Composable
fun ColumnScope.EqPanel(onClose: () -> Unit) {
    val eqp = PlayerHolder.eq
    var on by remember { mutableStateOf(eqp.enabled) }
    val gains = remember { mutableStateListOf<Float>().apply { addAll(eqp.gains.toList()) } }
    fun push() { eqp.set(gains.toFloatArray(), on) }
    fun save() { Prefs.eqSave(gains.toFloatArray(), on) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Equalizer", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        Switch(checked = on, onCheckedChange = { on = it; push(); save() })
        IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close") }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        EQ_PRESETS.forEach { (n, g) ->
            FilterChip(selected = false, onClick = { g.forEachIndexed { i, v -> gains[i] = v }; push(); save() }, label = { Text(n) })
        }
    }
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        EqProcessor.LABELS.forEachIndexed { i, label ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, Modifier.width(58.dp), fontSize = 12.sp)
                Slider(
                    value = gains[i], onValueChange = { gains[i] = it; push() }, onValueChangeFinished = { save() },
                    valueRange = -12f..12f, modifier = Modifier.weight(1f)
                )
                Text("%+d dB".format(gains[i].roundToInt()), Modifier.width(54.dp), fontSize = 12.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ Player screen

@Composable
fun PlayerScreen(a: PlayerActivity) {
    val p = a.player
    val cfg = LocalConfiguration.current
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(true) }
    var title by remember { mutableStateOf("") }
    var idx by remember { mutableIntStateOf(0) }
    var rate by remember { mutableFloatStateOf(1f) }
    var controls by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var showUnlock by remember { mutableStateOf(false) }
    var seeking by remember { mutableStateOf(false) }
    var seekVal by remember { mutableFloatStateOf(0f) }
    var hud by remember { mutableStateOf("") }
    var hudKey by remember { mutableIntStateOf(0) }
    var holdHud by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf("") }
    var lastDlg by remember { mutableStateOf("settings") }
    var resize by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var scale by remember { mutableFloatStateOf(1f) }
    var tx by remember { mutableFloatStateOf(0f) }
    var ty by remember { mutableFloatStateOf(0f) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    var vw by remember { mutableFloatStateOf(0f) }
    var vh by remember { mutableFloatStateOf(0f) }
    var side by remember { mutableIntStateOf(0) }
    var acc by remember { mutableIntStateOf(0) }
    var sideKey by remember { mutableIntStateOf(0) }
    var tapKey by remember { mutableIntStateOf(0) }
    var tracks by remember { mutableStateOf(p.currentTracks) }
    val pinching = remember { BooleanArray(1) }
    val hold = remember { BooleanArray(1) }
    val pendingToggle = remember { BooleanArray(1) }
    val lastTap = remember { LongArray(1) }
    val lastZone = remember { IntArray(1) { 9 } }
    val seriesUntil = remember { LongArray(1) }
    val seriesSide = remember { IntArray(1) { 9 } }

    DisposableEffect(Unit) {
        val l = object : Player.Listener { override fun onTracksChanged(t: Tracks) { tracks = t } }
        p.addListener(l)
        onDispose { p.removeListener(l) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            pos = p.currentPosition; dur = p.duration.coerceAtLeast(0L); playing = p.isPlaying
            title = p.mediaMetadata.title?.toString() ?: ""; idx = p.currentMediaItemIndex
            rate = p.playbackParameters.speed
            val vs = p.videoSize
            var w = vs.width * vs.pixelWidthHeightRatio; var h = vs.height.toFloat()
            if (vs.unappliedRotationDegrees % 180 != 0) { val t = w; w = h; h = t }
            vw = w; vh = h
            delay(if (controls || seeking) 250L else 1000L)
        }
    }
    LaunchedEffect(controls, playing, seeking, dlg) {
        if (controls && playing && !seeking && dlg == "") { delay(3500); controls = false }
    }
    LaunchedEffect(hudKey) { if (hud.isNotEmpty()) { delay(700); hud = "" } }
    LaunchedEffect(sideKey) { if (side != 0) { delay(650); side = 0 } }
    LaunchedEffect(showUnlock) { if (showUnlock) { delay(2000); showUnlock = false } }
    LaunchedEffect(dlg) { if (dlg != "") lastDlg = dlg }
    LaunchedEffect(a.audioOnly, idx) { a.updateKeep() }
    LaunchedEffect(tapKey) {
        if (tapKey > 0) { delay(280); if (pendingToggle[0]) { pendingToggle[0] = false; controls = !controls } }
    }
    BackHandler(enabled = dlg != "" || locked) { if (!locked) dlg = "" }
    val subLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) a.addSubtitle(u) }

    fun flash(s: String) { hud = s; hudKey++ }
    fun toggle() {
        if (p.isPlaying) p.pause() else { if (p.playbackState == Player.STATE_ENDED) p.seekTo(0); p.play() }
    }
    /** Seek by [sec]; consecutive skips on the same side add up in the faint side bubble (+10s, +20s, ...). */
    fun seek(sec: Int) {
        val d = p.duration
        p.seekTo((p.currentPosition + sec * 1000L).coerceIn(0L, if (d > 0) d else Long.MAX_VALUE))
        val s = if (sec > 0) 1 else -1
        acc = if (side == s) acc + abs(sec) else abs(sec)
        side = s; sideKey++
    }
    /** The rectangle where the video is actually visible (after fit + user zoom). Gestures work only here. */
    fun rect(): Rect {
        val w = box.width.toFloat(); val h = box.height.toFloat()
        if (w <= 0f || h <= 0f) return Rect.Zero
        var l = 0f; var t = 0f; var r = w; var b = h
        val logo = a.audioOnly || a.queue.getOrNull(p.currentMediaItemIndex)?.audio == true
        if (!logo && vw > 0f && vh > 0f && resize == AspectRatioFrameLayout.RESIZE_MODE_FIT) {
            val s = minOf(w / vw, h / vh)
            val vWidth = vw * s; val vHeight = vh * s
            l = (w - vWidth) / 2f; t = (h - vHeight) / 2f; r = l + vWidth; b = t + vHeight
        }
        val cx = w / 2f; val cy = h / 2f
        return Rect(
            maxOf(0f, cx + tx + scale * (l - cx)), maxOf(0f, cy + ty + scale * (t - cy)),
            minOf(w, cx + tx + scale * (r - cx)), minOf(h, cy + ty + scale * (b - cy))
        )
    }
    /** -1 = left zone, 1 = right zone, 0 = center, 9 = outside / dead zone. */
    fun zoneOf(o: Offset): Int {
        val r = rect()
        if (r.width <= 0f || !r.contains(o)) return 9
        val fx = (o.x - r.left) / r.width; val fy = (o.y - r.top) / r.height
        if (fy < 0.1f || fy > 0.9f) return 9
        return if (fx in 0.04f..0.4f) -1 else if (fx in 0.6f..0.96f) 1 else if (fx in 0.4f..0.6f) 0 else 9
    }
    fun zoomBy(c: Offset, z: Float, pan: Offset) {
        val w = box.width.toFloat(); val h = box.height.toFloat()
        val ns = (scale * z).coerceIn(1f, 6f)
        val k = ns / scale
        val ox = c.x - w / 2f; val oy = c.y - h / 2f
        val nx = ox - k * (ox - tx) + pan.x
        val ny = oy - k * (oy - ty) + pan.y
        val mx = w * (ns - 1f) / 2f; val my = h * (ns - 1f) / 2f
        tx = nx.coerceIn(-mx, mx); ty = ny.coerceIn(-my, my); scale = ns
        flash("Zoom ${"%.1f".format(ns)}x")
    }
    fun resetZoom() { scale = 1f; tx = 0f; ty = 0f }

    val showLogo = a.audioOnly || a.queue.getOrNull(idx)?.audio == true

    Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { box = it }) {
        AndroidView(
            factory = { c -> (LayoutInflater.from(c).inflate(R.layout.player_view, null) as PlayerView).also { it.player = p } },
            update = { it.resizeMode = resize },
            modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = tx; translationY = ty }
        )
        if (showLogo) Box(Modifier.fillMaxSize().background(Color(0xFF0A1A4A)), contentAlignment = Alignment.Center) {
            Image(painterResource(R.drawable.resume_logo), null, Modifier.size(140.dp))
        }

        if (locked) {
            Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { showUnlock = true } }) {
                AnimatedVisibility(showUnlock, Modifier.align(Alignment.CenterStart).padding(28.dp), enter = fadeIn(), exit = fadeOut()) {
                    IconButton(onClick = { locked = false }, modifier = Modifier.size(54.dp).background(Color(0x66000000), CircleShape)) {
                        Icon(Icons.Default.LockOpen, "Unlock", tint = Color.White)
                    }
                }
            }
        } else {
            // ---- gesture layer (all gestures work only on the visible video area) ----
            Box(
                Modifier.fillMaxSize()
                    // two-finger pinch zoom + pan, anchored at the fingers
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val ev = awaitPointerEvent()
                                if (ev.changes.count { it.pressed } >= 2) {
                                    pinching[0] = true
                                    val z = ev.calculateZoom(); val pan = ev.calculatePan(); val c = ev.calculateCentroid(useCurrent = true)
                                    if (z != 1f || pan != Offset.Zero) {
                                        zoomBy(c, z, pan)
                                        ev.changes.forEach { if (it.positionChanged()) it.consume() }
                                    }
                                }
                            } while (ev.changes.any { it.pressed })
                            pinching[0] = false
                        }
                    }
                    // press & hold = fast speed; slide left/right while holding to change it
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            var cancelled = false
                            val r = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    if (c == null || !c.pressed || ev.changes.size > 1 ||
                                        (c.position - down.position).getDistance() > viewConfiguration.touchSlop
                                    ) { cancelled = true; break }
                                }
                            }
                            if (r == null && !cancelled && !pinching[0] && rect().contains(down.position)) {
                                hold[0] = true
                                val base = p.playbackParameters.speed
                                var cur = Prefs.holdSpeed
                                p.setPlaybackSpeed(cur)
                                holdHud = "%.2fx".format(cur)
                                var accX = 0f
                                val step = 30.dp.toPx()
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    if (c == null || !c.pressed) { c?.consume(); break }
                                    accX += c.positionChange().x
                                    val ns = (Prefs.holdSpeed + (accX / step).toInt() * 0.25f).coerceIn(0.25f, 4f)
                                    if (ns != cur) { cur = ns; p.setPlaybackSpeed(cur); holdHud = "%.2fx".format(cur) }
                                    c.consume()
                                }
                                p.setPlaybackSpeed(base)
                                holdHud = ""
                                hold[0] = false
                            }
                        }
                    }
                    // taps: single = show/hide controls, double = skip / pause, then more taps keep skipping
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val up = waitForUpOrCancellation()
                            if (up != null && !pinching[0] && !hold[0] &&
                                up.uptimeMillis - down.uptimeMillis < viewConfiguration.longPressTimeoutMillis
                            ) {
                                val now = SystemClock.uptimeMillis()
                                val z = zoneOf(up.position)
                                if (Prefs.doubleTap && z != 9 && z != 0 && now < seriesUntil[0] && z == seriesSide[0]) {
                                    pendingToggle[0] = false
                                    seek(z * Prefs.seekSec); seriesUntil[0] = now + 600
                                } else if (Prefs.doubleTap && z != 9 && now - lastTap[0] < 300 && z == lastZone[0]) {
                                    pendingToggle[0] = false; lastTap[0] = 0L
                                    if (z == 0) toggle() else { seek(z * Prefs.seekSec); seriesSide[0] = z; seriesUntil[0] = now + 600 }
                                } else {
                                    lastTap[0] = now; lastZone[0] = z
                                    if (Prefs.doubleTap) { pendingToggle[0] = true; tapKey++ } else controls = !controls
                                }
                            }
                        }
                    }
                    // vertical swipe: left half = brightness, right half = volume
                    .pointerInput(Unit) {
                        var mode = 0
                        detectVerticalDragGestures(
                            onDragStart = { o ->
                                val r = rect()
                                val inner = r.deflate(40.dp.toPx())
                                mode = if (!Prefs.swipe || pinching[0] || hold[0] || r.width <= 0f ||
                                    (if (inner.width > 0f && inner.height > 0f) !inner.contains(o) else !r.contains(o))
                                ) 0 else if (o.x < r.center.x) 1 else 2
                                a.syncVol()
                            },
                            onDragEnd = { mode = 0 }, onDragCancel = { mode = 0 },
                            onVerticalDrag = { change, dy ->
                                if (mode != 0 && !pinching[0]) {
                                    change.consume()
                                    val f = -dy / rect().height.coerceAtLeast(1f) * 1.2f
                                    if (mode == 1) flash("Brightness ${a.addBright(f)}%") else flash("Volume ${a.addVolume(f)}%")
                                }
                            }
                        )
                    }
                    // horizontal swipe: seek (shows only the total seconds moved)
                    .pointerInput(Unit) {
                        var ok = false; var accX = 0f; var base = 0L; var target = 0L
                        detectHorizontalDragGestures(
                            onDragStart = { o ->
                                val r = rect()
                                val inner = r.deflate(40.dp.toPx())
                                ok = Prefs.swipe && !pinching[0] && !hold[0] && r.width > 0f &&
                                    (if (inner.width > 0f && inner.height > 0f) inner.contains(o) else r.contains(o))
                                accX = 0f; base = p.currentPosition; target = base
                            },
                            onDragEnd = { if (ok) p.seekTo(target); ok = false },
                            onDragCancel = { ok = false },
                            onHorizontalDrag = { change, dx ->
                                if (ok && !pinching[0]) {
                                    change.consume(); accX += dx
                                    val d = p.duration
                                    target = (base + (accX / rect().width.coerceAtLeast(1f) * 90000).toLong())
                                        .coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
                                    val s = (target - base) / 1000
                                    flash(if (s >= 0) "+${s}s" else "${s}s")
                                }
                            }
                        )
                    }
            )

            // faint side bubbles for skip, with the running total
            AnimatedVisibility(side < 0, Modifier.align(Alignment.CenterStart), enter = fadeIn(), exit = fadeOut()) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(0.36f)
                        .background(Color(0x22FFFFFF), RoundedCornerShape(topEndPercent = 50, bottomEndPercent = 50)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FastRewind, null, tint = Color(0xCCFFFFFF), modifier = Modifier.size(34.dp))
                        Text("-${acc}s", color = Color(0xCCFFFFFF), fontSize = 16.sp)
                    }
                }
            }
            AnimatedVisibility(side > 0, Modifier.align(Alignment.CenterEnd), enter = fadeIn(), exit = fadeOut()) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(0.36f)
                        .background(Color(0x22FFFFFF), RoundedCornerShape(topStartPercent = 50, bottomStartPercent = 50)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FastForward, null, tint = Color(0xCCFFFFFF), modifier = Modifier.size(34.dp))
                        Text("+${acc}s", color = Color(0xCCFFFFFF), fontSize = 16.sp)
                    }
                }
            }

            if (hud.isNotEmpty()) Pill(hud, Modifier.align(Alignment.Center))
            if (holdHud.isNotEmpty()) Pill("▶▶  $holdHud", Modifier.align(Alignment.TopCenter).padding(top = 28.dp))

            AnimatedVisibility(controls && !a.inPip, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                            .displayCutoutPadding().padding(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { a.finish() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                            Text(title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            IconButton(onClick = { dlg = "settings" }) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) }
                        }
                        // spread-out, swipeable button strip: shows 2+ buttons, drag right to bring the rest in
                        val shown = (cfg.screenWidthDp * 0.4f / 64f).toInt().coerceIn(2, 5)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Box(Modifier.width((shown * 64 + 30).dp)) {
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                                        CtlBtn(Icons.Default.Headphones, "Audio only", a.audioOnly) { a.applyAudioOnly(!a.audioOnly) }
                                        CtlBtn(Icons.Default.ScreenRotation, "Rotate") {
                                            val land = a.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                                            a.requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                                            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                        }
                                        CtlBtn(Icons.Default.Equalizer, "Equalizer") { dlg = "eq" }
                                        CtlBtn(Icons.Default.PictureInPictureAlt, "Picture in picture") { a.enterPip() }
                                        CtlBtn(Icons.Default.AspectRatio, "Aspect ratio") {
                                            resize = when (resize) {
                                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                            }
                                            resetZoom()
                                            flash(when (resize) { AspectRatioFrameLayout.RESIZE_MODE_FIT -> "Fit"; AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Crop"; else -> "Stretch" })
                                        }
                                        CtlBtn(Icons.Default.Lock, "Lock") { locked = true; controls = false }
                                    }
                                }
                            }
                        }
                    }
                    Column(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                            .displayCutoutPadding().padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmt(if (seeking) (seekVal * dur).toLong() else pos), color = Color.White, fontSize = 12.sp)
                            Slider(
                                value = if (seeking) seekVal else if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
                                onValueChange = { seeking = true; seekVal = it },
                                onValueChangeFinished = { p.seekTo((seekVal * dur).toLong()); seeking = false },
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                            )
                            Text(fmt(dur), color = Color.White, fontSize = 12.sp)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { p.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
                            IconButton(onClick = { seek(-Prefs.seekSec) }) { Icon(Icons.Default.FastRewind, "Back", tint = Color.White) }
                            IconButton(onClick = { toggle() }, modifier = Modifier.size(56.dp)) {
                                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", tint = Color.White, modifier = Modifier.size(40.dp))
                            }
                            IconButton(onClick = { seek(Prefs.seekSec) }) { Icon(Icons.Default.FastForward, "Forward", tint = Color.White) }
                            IconButton(onClick = { p.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
                        }
                    }
                }
            }
        }

        // ---- settings: slides in from the RIGHT, translucent so the video stays visible ----
        val pw = (cfg.screenWidthDp * 0.5f).coerceIn(280f, 360f).coerceAtMost(cfg.screenWidthDp * 0.92f).dp
        SidePanel(dlg == "settings", pw, { dlg = "" }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Player settings", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = { dlg = "" }) { Icon(Icons.Default.Close, "Close") }
            }
            PLabel("Playback speed")
            listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { s ->
                        FilterChip(selected = rate == s, onClick = { p.setPlaybackSpeed(s); rate = s }, label = { Text("${s}x") })
                    }
                }
            }
            TrackSection("Audio track", p, tracks, C.TRACK_TYPE_AUDIO, false)
            TrackSection("Subtitles", p, tracks, C.TRACK_TYPE_TEXT, true)
            TextButton(onClick = { subLauncher.launch(arrayOf("*/*")) }) { Text("Load subtitle file (.srt / .vtt / .ass)") }
            PLabel("Sleep timer")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0, 15, 30, 60).forEach { m ->
                    FilterChip(selected = a.sleepMin == m, onClick = { a.setSleep(m) }, label = { Text(if (m == 0) "Off" else "${m}m") })
                }
            }
            PLabel("Controls")
            PSwitch("Loop current", Prefs.loop) {
                Prefs.loop = it; Prefs.save(); p.repeatMode = if (it) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            }
            PSwitch("Double-tap gestures", Prefs.doubleTap) { Prefs.doubleTap = it; Prefs.save() }
            PSwitch("Swipe gestures", Prefs.swipe) { Prefs.swipe = it; Prefs.save() }
        }

        // ---- equalizer: small floating window in the middle, scrollable, video visible behind ----
        val land = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE
        CenterPanel(dlg == "eq", if (land) 0.55f else 0.92f, if (land) 0.88f else 0.62f, { dlg = "" }) {
            EqPanel { dlg = "" }
        }
    }
}
