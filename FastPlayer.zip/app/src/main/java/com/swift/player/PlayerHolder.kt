@file:OptIn(UnstableApi::class)

package com.swift.player

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters

/** One player for the whole process, so audio can keep playing after the screen closes. */
object PlayerHolder {
    var player: ExoPlayer? = null
    var alive = 0
    val eq = EqProcessor()

    fun get(ctx: Context): ExoPlayer {
        player?.let { return it }
        val app = ctx.applicationContext
        val lc = DefaultLoadControl.Builder().setBufferDurationsMs(2000, 12000, 250, 700).build()
        eq.set(Prefs.eqLoad(), Prefs.eqOn())
        val rf = object : DefaultRenderersFactory(app) {
            override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean): AudioSink? =
                DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(false)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioProcessors(arrayOf<AudioProcessor>(eq))
                    .build()
        }
        rf.setEnableDecoderFallback(true)
        rf.forceEnableMediaCodecAsynchronousQueueing()
        val p = ExoPlayer.Builder(app, rf).setLoadControl(lc).build()
        p.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        p.setHandleAudioBecomingNoisy(true)
        p.setAudioAttributes(AudioAttributes.DEFAULT, true)
        player = p
        return p
    }

    fun release() {
        player?.release()
        player = null
    }
}

class AudioService : Service() {
    private var listener: Player.Listener? = null
    private val nm by lazy { getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm.createNotificationChannel(NotificationChannel("play", "Playback", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p = PlayerHolder.player
        when (intent?.action) {
            "toggle" -> {
                p?.let { if (it.isPlaying) it.pause() else it.play() }
                nm.notify(1, build())
                return START_NOT_STICKY
            }
            "close" -> {
                p?.pause()
                if (PlayerHolder.alive == 0) PlayerHolder.release()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        startForeground(1, build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        if (p == null) { stopSelf(); return START_NOT_STICKY }
        if (listener == null) {
            listener = object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) { nm.notify(1, build()) }
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { nm.notify(1, build()) }
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_ENDED && PlayerHolder.alive == 0) {
                        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
                    }
                }
            }
            p.addListener(listener!!)
        }
        return START_NOT_STICKY
    }

    private fun build(): Notification {
        val p = PlayerHolder.player
        val title = p?.mediaMetadata?.title?.toString() ?: "Fast Player"
        val playing = p?.isPlaying == true
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java).putExtra("attach", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun act(a: String, c: Int) = PendingIntent.getService(
            this, c, Intent(this, AudioService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "play")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title).setContentText("Fast Player")
            .setContentIntent(open).setOngoing(playing)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1))
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play),
                if (playing) "Pause" else "Play", act("toggle", 1)).build())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Close", act("close", 2)).build())
            .build()
    }

    override fun onDestroy() {
        listener?.let { PlayerHolder.player?.removeListener(it) }
        listener = null
        super.onDestroy()
    }
}
