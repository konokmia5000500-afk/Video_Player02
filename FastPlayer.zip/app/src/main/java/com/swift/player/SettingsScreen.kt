package com.swift.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen() {
    var dlg by remember { mutableStateOf("") }
    val themes = listOf("system" to "System default", "light" to "Light", "dark" to "Dark", "amoled" to "AMOLED black", "blue" to "Ocean blue")
    val fonts = listOf("0.9" to "Small", "1.0" to "Default", "1.15" to "Large", "1.3" to "Extra large")
    val orients = listOf("auto" to "Auto (sensor)", "landscape" to "Landscape", "portrait" to "Portrait",
        "system" to "System default", "video" to "Based on video size")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Section("Appearance")
        RowItem("Theme", themes.first { it.first == Prefs.theme }.second) { dlg = "theme" }
        RowItem("Font size", fonts.firstOrNull { it.first.toFloat() == Prefs.fontScale }?.second ?: "Custom") { dlg = "font" }
        Section("Player")
        RowItem("Double-tap skip", "${Prefs.seekSec} seconds") { dlg = "seek" }
        RowItem("Press & hold speed", "${Prefs.holdSpeed}x") { dlg = "hold" }
        RowItem("Screen orientation", orients.first { it.first == Prefs.orient }.second) { dlg = "orient" }
        Sw("Double-tap gestures", "Left/right to skip, center to pause", Prefs.doubleTap) { Prefs.doubleTap = it; Prefs.save() }
        Sw("Swipe gestures", "Volume, brightness and seek by swiping", Prefs.swipe) { Prefs.swipe = it; Prefs.save() }
        Sw("Remember position", "Continue from where you stopped", Prefs.resume) { Prefs.resume = it; Prefs.save() }
        Sw("Play next automatically", "Go to the next item when finished", Prefs.autoNext) { Prefs.autoNext = it; Prefs.save() }
        Sw("Loop current item", "Repeat when finished", Prefs.loop) { Prefs.loop = it; Prefs.save() }
        Sw("Keep screen on", "While playing", Prefs.keepOn) { Prefs.keepOn = it; Prefs.save() }
        Sw("Auto Picture-in-Picture", "Enter PiP when you press Home", Prefs.pipHome) { Prefs.pipHome = it; Prefs.save() }
        Spacer(Modifier.height(90.dp))
    }
    when (dlg) {
        "theme" -> RadioDlg("Theme", themes, Prefs.theme, { Prefs.theme = it; Prefs.save() }) { dlg = "" }
        "font" -> RadioDlg("Font size", fonts, fonts.firstOrNull { it.first.toFloat() == Prefs.fontScale }?.first ?: "1.0",
            { Prefs.fontScale = it.toFloat(); Prefs.save() }) { dlg = "" }
        "orient" -> RadioDlg("Screen orientation", orients, Prefs.orient, { Prefs.orient = it; Prefs.save() }) { dlg = "" }
        "hold" -> RadioDlg("Press & hold speed", listOf("1.5" to "1.5x", "2.0" to "2x", "3.0" to "3x", "4.0" to "4x"),
            Prefs.holdSpeed.toString(), { Prefs.holdSpeed = it.toFloat(); Prefs.save() }) { dlg = "" }
        "seek" -> SeekDlg { dlg = "" }
    }
}

@Composable
fun Section(t: String) {
    Text(t, Modifier.padding(start = 16.dp, top = 18.dp, bottom = 4.dp), color = MaterialTheme.colorScheme.primary,
        style = MaterialTheme.typography.labelLarge)
}

@Composable
fun RowItem(title: String, summary: String, onClick: () -> Unit) {
    ListItem(headlineContent = { Text(title) }, supportingContent = { Text(summary) }, modifier = Modifier.clickable(onClick = onClick))
}

@Composable
fun Sw(title: String, summary: String, value: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) }, supportingContent = { Text(summary) },
        trailingContent = { Switch(checked = value, onCheckedChange = onChange) },
        modifier = Modifier.clickable { onChange(!value) }
    )
}

@Composable
fun RadioDlg(title: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, title = { Text(title) },
        text = {
            Column {
                options.forEach { (k, l) ->
                    Row(Modifier.fillMaxWidth().clickable { onSelect(k); onClose() }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = k == selected, onClick = null)
                        Spacer(Modifier.width(12.dp)); Text(l)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

@Composable
fun SeekDlg(onClose: () -> Unit) {
    var t by remember { mutableStateOf(Prefs.seekSec.toString()) }
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Double-tap skip (seconds)") },
        text = {
            Column {
                OutlinedTextField(t, { t = it.filter(Char::isDigit).take(3) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("Seconds (1–300)") })
                Spacer(Modifier.height(8.dp))
                Text("Suggestions", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(5, 10, 15, 20, 30).forEach { s ->
                        FilterChip(selected = t == s.toString(), onClick = { t = s.toString() }, label = { Text("$s") })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { t.toIntOrNull()?.let { if (it in 1..300) { Prefs.seekSec = it; Prefs.save() } }; onClose() }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
