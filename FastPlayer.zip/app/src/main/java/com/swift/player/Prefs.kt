package com.swift.player

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*

object Prefs {
    private lateinit var sp: SharedPreferences
    private var ready = false

    var theme by mutableStateOf("system")
    var fontScale by mutableFloatStateOf(1f)
    var seekSec by mutableIntStateOf(10)
    var resume by mutableStateOf(true)
    var autoNext by mutableStateOf(true)
    var loop by mutableStateOf(false)
    var swipe by mutableStateOf(true)
    var doubleTap by mutableStateOf(true)
    var keepOn by mutableStateOf(true)
    var pipHome by mutableStateOf(false)
    var orient by mutableStateOf("auto")
    var holdSpeed by mutableFloatStateOf(2f)
    var lastUri by mutableStateOf("")
    var lastTitle by mutableStateOf("")
    var lastAudio by mutableStateOf(false)
    var playlistTick by mutableIntStateOf(0)

    fun init(c: Context) {
        if (ready) return
        sp = c.getSharedPreferences("swift", Context.MODE_PRIVATE)
        theme = sp.getString("theme", "system")!!
        fontScale = sp.getFloat("font", 1f)
        seekSec = sp.getInt("seek", 10)
        resume = sp.getBoolean("resume", true)
        autoNext = sp.getBoolean("autoNext", true)
        loop = sp.getBoolean("loop", false)
        swipe = sp.getBoolean("swipe", true)
        doubleTap = sp.getBoolean("dtap", true)
        keepOn = sp.getBoolean("keepOn", true)
        pipHome = sp.getBoolean("pipHome", false)
        orient = sp.getString("orient", "auto")!!
        holdSpeed = sp.getFloat("hold", 2f)
        lastUri = sp.getString("lastUri", "")!!
        lastTitle = sp.getString("lastTitle", "")!!
        lastAudio = sp.getBoolean("lastAudio", false)
        ready = true
    }

    fun save() {
        sp.edit().putString("theme", theme).putFloat("font", fontScale).putInt("seek", seekSec)
            .putBoolean("resume", resume).putBoolean("autoNext", autoNext).putBoolean("loop", loop)
            .putBoolean("swipe", swipe).putBoolean("dtap", doubleTap).putBoolean("keepOn", keepOn)
            .putBoolean("pipHome", pipHome).putString("orient", orient).putFloat("hold", holdSpeed)
            .putString("lastUri", lastUri).putString("lastTitle", lastTitle).putBoolean("lastAudio", lastAudio)
            .apply()
    }

    fun pos(uri: String): Long = sp.getLong("p_$uri", 0L)
    fun setPos(uri: String, ms: Long) { sp.edit().putLong("p_$uri", ms).apply() }

    // ---- Playlists (stored as text: name list + "uri<TAB>title" lines) ----
    fun plNames(): List<String> = sp.getString("pl_names", "")!!.split("\n").filter { it.isNotBlank() }
    fun plItems(n: String): List<Pair<String, String>> =
        sp.getString("pl_$n", "")!!.split("\n").filter { it.isNotBlank() }.map {
            val a = it.split("\t"); a[0] to a.getOrElse(1) { a[0] }
        }
    fun plCreate(n: String) {
        val name = n.trim(); if (name.isEmpty() || plNames().contains(name)) return
        sp.edit().putString("pl_names", (plNames() + name).joinToString("\n")).apply(); playlistTick++
    }
    fun plAdd(n: String, uri: String, title: String) {
        val cur = plItems(n)
        if (cur.any { it.first == uri }) return
        sp.edit().putString("pl_$n", (cur + (uri to title)).joinToString("\n") { it.first + "\t" + it.second }).apply()
        playlistTick++
    }
    fun plDelete(n: String) {
        sp.edit().putString("pl_names", plNames().filter { it != n }.joinToString("\n")).remove("pl_$n").apply(); playlistTick++
    }

    // ---- Equalizer (15 bands, dB) ----
    fun eqLoad(): FloatArray {
        val l = sp.getString("eq", "")!!.split(",").mapNotNull { it.toFloatOrNull() }
        return if (l.size == EqProcessor.N) l.toFloatArray() else FloatArray(EqProcessor.N)
    }
    fun eqOn(): Boolean = sp.getBoolean("eqOn", true)
    fun eqSave(g: FloatArray, on: Boolean) { sp.edit().putString("eq", g.joinToString(",")).putBoolean("eqOn", on).apply() }
}
