@file:OptIn(UnstableApi::class)

package com.swift.player

import android.app.Application
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil

class FastApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        // Warm up the codec list in the background so the first video starts faster.
        Thread {
            try {
                MediaCodecUtil.getDecoderInfos("video/avc", false, false)
                MediaCodecUtil.getDecoderInfos("video/hevc", false, false)
                MediaCodecUtil.getDecoderInfos("audio/mp4a-latm", false, false)
            } catch (_: Exception) {}
        }.start()
    }
}
