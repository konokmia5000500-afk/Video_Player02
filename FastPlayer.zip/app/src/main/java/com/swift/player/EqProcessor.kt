@file:OptIn(UnstableApi::class)

package com.swift.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * 15-band graphic equalizer (software, independent of the phone's hardware EQ).
 * Each active band is one peaking biquad filter (RBJ cookbook). Bands at 0 dB cost nothing.
 */
class EqProcessor : BaseAudioProcessor() {
    companion object {
        const val N = 15
        val FREQS = floatArrayOf(25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f, 1000f, 1600f, 2500f, 4000f, 6300f, 10000f, 16000f)
        val LABELS = listOf("25 Hz", "40 Hz", "63 Hz", "100 Hz", "160 Hz", "250 Hz", "400 Hz", "630 Hz",
            "1 kHz", "1.6 kHz", "2.5 kHz", "4 kHz", "6.3 kHz", "10 kHz", "16 kHz")
    }

    @Volatile var gains = FloatArray(N)
        private set
    @Volatile var enabled = true
        private set
    @Volatile private var dirty = true
    private var rate = 0
    private var ch = 0
    private val b0 = FloatArray(N); private val b1 = FloatArray(N); private val b2 = FloatArray(N)
    private val a1 = FloatArray(N); private val a2 = FloatArray(N)
    private val on = BooleanArray(N)
    private var z1 = FloatArray(0)
    private var z2 = FloatArray(0)

    fun set(g: FloatArray, e: Boolean) { gains = g.copyOf(); enabled = e; dirty = true }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        rate = inputAudioFormat.sampleRate
        ch = inputAudioFormat.channelCount
        z1 = FloatArray(ch * N); z2 = FloatArray(ch * N)
        dirty = true
        return inputAudioFormat
    }

    override fun onFlush() { z1.fill(0f); z2.fill(0f) }

    private fun recalc(g: FloatArray) {
        for (i in 0 until N) {
            val f = FREQS[i]
            if (abs(g[i]) < 0.05f || f >= rate * 0.45f) { on[i] = false; continue }
            on[i] = true
            val a = 10.0.pow((g[i] / 40f).toDouble())
            val w0 = 2.0 * PI * f / rate
            val alpha = sin(w0) / (2.0 * 2.0)
            val cw = cos(w0)
            val a0 = 1.0 + alpha / a
            b0[i] = ((1.0 + alpha * a) / a0).toFloat()
            b1[i] = ((-2.0 * cw) / a0).toFloat()
            b2[i] = ((1.0 - alpha * a) / a0).toFloat()
            a1[i] = ((-2.0 * cw) / a0).toFloat()
            a2[i] = ((1.0 - alpha / a) / a0).toFloat()
        }
        dirty = false
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val out = replaceOutputBuffer(remaining)
        val g = gains
        val act = enabled && rate > 0 && g.any { abs(it) >= 0.05f }
        if (!act) {
            out.put(inputBuffer)
        } else {
            if (dirty) recalc(g)
            val channels = ch
            while (inputBuffer.remaining() >= 2 * channels) {
                for (c in 0 until channels) {
                    var x = inputBuffer.getShort().toFloat()
                    val base = c * N
                    for (b in 0 until N) {
                        if (on[b]) {
                            val y = b0[b] * x + z1[base + b]
                            z1[base + b] = b1[b] * x - a1[b] * y + z2[base + b]
                            z2[base + b] = b2[b] * x - a2[b] * y
                            x = y
                        }
                    }
                    out.putShort(x.coerceIn(-32768f, 32767f).toInt().toShort())
                }
            }
            if (inputBuffer.hasRemaining()) out.put(inputBuffer)
        }
        out.flip()
    }
}
