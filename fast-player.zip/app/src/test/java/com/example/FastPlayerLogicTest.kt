package com.example

import com.example.data.local.MediaStoreRepository
import com.example.model.MediaItemModel
import com.example.model.SortField
import com.example.model.SortOrder
import com.example.util.FormatUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FastPlayerLogicTest {

    private fun sampleItem(
        id: Long,
        title: String,
        folderPath: String,
        durationMs: Long = 60_000L
    ) = MediaItemModel(
        id = id,
        uriString = "content://media/external/video/media/$id",
        title = title,
        displayName = "$title.mp4",
        path = "$folderPath/$title.mp4",
        folderPath = folderPath,
        folderName = folderPath.substringAfterLast('/'),
        durationMs = durationMs,
        sizeBytes = 10_000_000L,
        dateAddedSec = 1_700_000_000L + id,
        dateModifiedSec = 1_700_000_000L + id
    )

    @Test
    fun `search matches any substring and groups related items`() {
        val videos = listOf(
            sampleItem(1, "Summer Vacation Vlog", "/storage/emulated/0/Movies/Trip"),
            sampleItem(2, "Winter Vacation Highlight", "/storage/emulated/0/Movies/Trip"),
            sampleItem(3, "Mountain Hike", "/storage/emulated/0/Movies/Trip"),
            sampleItem(4, "City Timelapse", "/storage/emulated/0/DCIM/Camera")
        )

        val results = MediaStoreRepository.searchMediaWithRelated(videos, "Vacation")
        assertEquals(2, results.directMatches.size)
        assertTrue(results.directMatches.all { it.title.contains("Vacation") })
        // Mountain Hike shares the same folder as direct matches so appears in related
        assertEquals(1, results.relatedMatches.size)
        assertEquals("Mountain Hike", results.relatedMatches.first().title)
    }

    @Test
    fun `folder tree builds hierarchy and counts accurately`() {
        val videos = listOf(
            sampleItem(1, "Clip1", "/storage/emulated/0/Movies/Action"),
            sampleItem(2, "Clip2", "/storage/emulated/0/Movies/Action"),
            sampleItem(3, "Clip3", "/storage/emulated/0/Movies/Comedy"),
            sampleItem(4, "Clip4", "/storage/emulated/0/DCIM/Camera")
        )

        val (rootChildren, direct) = MediaStoreRepository.buildTreeChildren(
            videos = videos,
            currentTreePath = null,
            lastPlayedFolderPath = "/storage/emulated/0/Movies/Action",
            markLastPlayed = true
        )

        assertTrue(direct.isEmpty())
        assertEquals(2, rootChildren.size)
        val movies = rootChildren.first { it.name == "Movies" }
        assertEquals(3, movies.videoCount)
        assertEquals(2, movies.subfolderCount)
        assertTrue(movies.isLastPlayedFolder)
    }

    @Test
    fun `sort and formatting utilities produce expected output`() {
        assertEquals("01:05", FormatUtils.formatDuration(65_000L))
        assertEquals("1:01:05", FormatUtils.formatDuration(3_665_000L))
        assertEquals("[+00:50]", FormatUtils.formatSignedDelta(50_000L))
        assertEquals("1.5x", FormatUtils.formatSpeed(1.5f))

        val items = listOf(
            sampleItem(1, "Alpha", "/a", 10_000L),
            sampleItem(2, "Beta", "/a", 30_000L)
        )
        val sortedDesc = MediaStoreRepository.sortMedia(items, SortField.LENGTH, SortOrder.DESCENDING)
        assertEquals("Beta", sortedDesc.first().title)
    }
}
