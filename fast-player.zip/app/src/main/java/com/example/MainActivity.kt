package com.example

import android.Manifest
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.PlaylistPlay
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.MainTab
import com.example.ui.components.FloatingResumeButton
import com.example.ui.components.NowPlayingMiniBar
import com.example.ui.screens.AudioLibraryScreen
import com.example.ui.screens.MeScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.PlaylistScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VideoLibraryScreen
import com.example.ui.screens.enterPipMode
import com.example.ui.theme.FastPlayerTheme
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.PlayerViewModel
import com.example.util.FormatUtils

private enum class AppDestination {
    MAIN, SETTINGS, PLAYER
}

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()
    private val pendingExternalUri = mutableStateOf<Uri?>(null)
    private val isInPipState = mutableStateOf(false)
    private val isPlayerActive = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIntent(intent)

        setContent {
            val uiState by mainViewModel.uiState.collectAsStateWithLifecycle()
            val playerViewModel: PlayerViewModel = viewModel()
            val playbackState by playerViewModel.playbackState.collectAsStateWithLifecycle()

            var destination by remember { mutableStateOf(AppDestination.MAIN) }
            var currentTab by remember { mutableStateOf(MainTab.VIDEO) }
            val context = LocalContext.current

            val selectedPlaylistId by mainViewModel.selectedPlaylistId.collectAsStateWithLifecycle()
            val playlistEntries by mainViewModel.selectedPlaylistEntries.collectAsStateWithLifecycle()

            // Permission Launchers
            val mediaPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) {
                mainViewModel.onPermissionResult()
            }

            val notificationPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { }

            val openFileLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    try {
                        contentResolver.takePersistableUriPermission(
                            uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    } catch (_: Exception) {
                    }
                    mainViewModel.openExternalUri(uri)
                    destination = AppDestination.PLAYER
                }
            }

            // Ask for storage + notification permissions once on startup if not granted,
            // and warm up ExoPlayer asynchronously right after first frame draws
            LaunchedEffect(Unit) {
                val needed = mutableListOf<String>()
                if (!FormatUtils.hasMediaPermission(context)) {
                    needed.addAll(FormatUtils.requiredMediaPermissions())
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    !FormatUtils.hasNotificationPermission(context)
                ) {
                    needed.add(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (needed.isNotEmpty()) {
                    mediaPermissionLauncher.launch(needed.toTypedArray())
                }
                kotlinx.coroutines.delay(180L)
                mainViewModel.playerEngine.warmUp()
            }

            // Handle external "Open with Fast Player" URI
            val extUri = pendingExternalUri.value
            LaunchedEffect(extUri) {
                if (extUri != null) {
                    mainViewModel.openExternalUri(extUri)
                    pendingExternalUri.value = null
                    destination = AppDestination.PLAYER
                }
            }

            LaunchedEffect(destination) {
                isPlayerActive.value = destination == AppDestination.PLAYER
            }

            val requestMediaAndNotification: () -> Unit = {
                val perms = buildList {
                    addAll(FormatUtils.requiredMediaPermissions())
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        !FormatUtils.hasNotificationPermission(context)
                    ) {
                        add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                mediaPermissionLauncher.launch(perms.toTypedArray())
            }

            val ensureNotificationPermission: () -> Unit = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    !FormatUtils.hasNotificationPermission(context)
                ) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            FastPlayerTheme(
                themeOption = uiState.settings.themeOption,
                fontSizeOption = uiState.settings.fontSizeOption,
                isInPlayer = destination == AppDestination.PLAYER
            ) {
                AnimatedContent(
                    targetState = destination,
                    transitionSpec = {
                        (fadeIn(animationSpec = tween(210, easing = FastOutSlowInEasing)) +
                            scaleIn(initialScale = 0.96f, animationSpec = tween(210, easing = FastOutSlowInEasing)))
                            .togetherWith(
                                fadeOut(animationSpec = tween(160, easing = FastOutSlowInEasing)) +
                                    scaleOut(targetScale = 1.02f, animationSpec = tween(160))
                            )
                    },
                    label = "root_nav"
                ) { dest ->
                    when (dest) {
                        AppDestination.PLAYER -> {
                            PlayerScreen(
                                viewModel = playerViewModel,
                                isInPipMode = isInPipState.value,
                                onExitToLibrary = { destination = AppDestination.MAIN },
                                onEnterBackgroundAudio = {
                                    ensureNotificationPermission()
                                    destination = AppDestination.MAIN
                                }
                            )
                        }

                        AppDestination.SETTINGS -> {
                            Scaffold(
                                contentWindowInsets = WindowInsets.safeDrawing
                            ) { innerPadding ->
                                SettingsScreen(
                                    uiState = uiState,
                                    viewModel = mainViewModel,
                                    onBack = { destination = AppDestination.MAIN },
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                        }

                        AppDestination.MAIN -> {
                            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                                val useRail = maxWidth >= 700.dp

                                Scaffold(
                                    contentWindowInsets = WindowInsets.safeDrawing,
                                    bottomBar = {
                                        if (!useRail) {
                                            val showMiniBar = playbackState.currentItem != null &&
                                                (playbackState.isBackgroundAudioMode || playbackState.currentItem?.isAudio == true)
                                            Column {
                                                AnimatedVisibility(
                                                    visible = showMiniBar,
                                                    enter = fadeIn(tween(200)) + slideInVertically(tween(200)) { it / 2 },
                                                    exit = fadeOut(tween(150)) + slideOutVertically(tween(150)) { it / 2 }
                                                ) {
                                                    NowPlayingMiniBar(
                                                        playbackState = playbackState,
                                                        onOpenPlayer = {
                                                            if (playbackState.currentItem?.isAudio == false) {
                                                                mainViewModel.playerEngine.enterVideoMode()
                                                            }
                                                            destination = AppDestination.PLAYER
                                                        },
                                                        onTogglePlayPause = { mainViewModel.playerEngine.togglePlayPause() },
                                                        onClose = { mainViewModel.playerEngine.stopPlaybackAndClear() }
                                                    )
                                                }
                                                FastPlayerBottomBar(
                                                    currentTab = currentTab,
                                                    onSelectTab = { tab ->
                                                        if (currentTab != tab) {
                                                            mainViewModel.setSearchActive(false)
                                                            currentTab = tab
                                                        }
                                                    }
                                                )
                                            }
                                        }
                                    }
                                ) { innerPadding ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(innerPadding)
                                    ) {
                                        if (useRail) {
                                            FastPlayerNavigationRail(
                                                currentTab = currentTab,
                                                onSelectTab = { tab ->
                                                    if (currentTab != tab) {
                                                        mainViewModel.setSearchActive(false)
                                                        currentTab = tab
                                                    }
                                                }
                                            )
                                        }

                                        Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                            Column(modifier = Modifier.fillMaxSize()) {
                                                val showRailMiniBar = useRail &&
                                                    playbackState.currentItem != null &&
                                                    (playbackState.isBackgroundAudioMode || playbackState.currentItem?.isAudio == true)
                                                AnimatedVisibility(
                                                    visible = showRailMiniBar,
                                                    enter = fadeIn(tween(200)) + slideInVertically(tween(200)) { -it / 2 },
                                                    exit = fadeOut(tween(150)) + slideOutVertically(tween(150)) { -it / 2 }
                                                ) {
                                                    NowPlayingMiniBar(
                                                        playbackState = playbackState,
                                                        onOpenPlayer = {
                                                            if (playbackState.currentItem?.isAudio == false) {
                                                                mainViewModel.playerEngine.enterVideoMode()
                                                            }
                                                            destination = AppDestination.PLAYER
                                                        },
                                                        onTogglePlayPause = { mainViewModel.playerEngine.togglePlayPause() },
                                                        onClose = { mainViewModel.playerEngine.stopPlaybackAndClear() }
                                                    )
                                                }

                                                Box(modifier = Modifier.weight(1f)) {
                                                    AnimatedContent(
                                                        targetState = currentTab,
                                                        transitionSpec = {
                                                            (fadeIn(tween(180, easing = FastOutSlowInEasing)) +
                                                                slideInVertically(tween(180)) { it / 32 })
                                                                .togetherWith(fadeOut(tween(130)))
                                                        },
                                                        label = "tab_nav"
                                                    ) { tab ->
                                                        when (tab) {
                                                            MainTab.VIDEO -> VideoLibraryScreen(
                                                                uiState = uiState,
                                                                onRequestPermissions = requestMediaAndNotification,
                                                                onOpenExternalPicker = {
                                                                    openFileLauncher.launch(arrayOf("video/*", "audio/*"))
                                                                },
                                                                onOpenFolder = mainViewModel::openFolder,
                                                                onNavigateFolderUp = mainViewModel::navigateFolderUp,
                                                                onCycleViewMode = mainViewModel::cycleViewMode,
                                                                onUpdateViewOptions = mainViewModel::updateViewOptions,
                                                                onSetSearchActive = mainViewModel::setSearchActive,
                                                                onSearchQueryChange = mainViewModel::updateSearchQuery,
                                                                onPlayVideo = { item, list, fromZero ->
                                                                    mainViewModel.playVideoItem(item, list, fromZero)
                                                                    destination = AppDestination.PLAYER
                                                                },
                                                                onPlayAsAudio = { item, list ->
                                                                    ensureNotificationPermission()
                                                                    mainViewModel.playVideoAsAudio(item, list)
                                                                },
                                                                onAddToPlaylist = mainViewModel::addItemToPlaylist,
                                                                onCreatePlaylistAndAdd = mainViewModel::createPlaylist
                                                            )

                                                            MainTab.AUDIO -> AudioLibraryScreen(
                                                                uiState = uiState,
                                                                onRequestPermissions = requestMediaAndNotification,
                                                                onOpenExternalPicker = {
                                                                    openFileLauncher.launch(arrayOf("audio/*", "video/*"))
                                                                },
                                                                onSetSearchActive = mainViewModel::setSearchActive,
                                                                onSearchQueryChange = mainViewModel::updateSearchQuery,
                                                                onUpdateSort = mainViewModel::updateAudioSort,
                                                                onPlayAudio = { item, list ->
                                                                    ensureNotificationPermission()
                                                                    mainViewModel.playAudioItem(item, list)
                                                                    destination = AppDestination.PLAYER
                                                                },
                                                                onAddToPlaylist = mainViewModel::addItemToPlaylist,
                                                                onCreatePlaylistAndAdd = mainViewModel::createPlaylist
                                                            )

                                                            MainTab.PLAYLIST -> PlaylistScreen(
                                                                uiState = uiState,
                                                                selectedPlaylistId = selectedPlaylistId,
                                                                playlistEntries = playlistEntries,
                                                                onSelectPlaylist = mainViewModel::selectPlaylist,
                                                                onCreatePlaylist = { mainViewModel.createPlaylist(it) },
                                                                onRenamePlaylist = mainViewModel::renamePlaylist,
                                                                onDeletePlaylist = mainViewModel::deletePlaylist,
                                                                onRemoveEntry = mainViewModel::removePlaylistEntry,
                                                                onPlayEntries = { entries, idx, shuffle ->
                                                                    ensureNotificationPermission()
                                                                    mainViewModel.playPlaylistEntries(entries, idx, shuffle)
                                                                    destination = AppDestination.PLAYER
                                                                },
                                                                onSetSearchActive = mainViewModel::setSearchActive,
                                                                onSearchQueryChange = mainViewModel::updateSearchQuery
                                                            )

                                                            MainTab.ME -> MeScreen(
                                                                uiState = uiState,
                                                                onOpenSettings = { destination = AppDestination.SETTINGS },
                                                                onSelectTheme = mainViewModel::setTheme,
                                                                onSelectFontSize = mainViewModel::setFontSize,
                                                                onUpdateDoubleTapSeek = mainViewModel::setDoubleTapSeekSeconds,
                                                                onToggleFloatingResume = mainViewModel::setShowFloatingResume,
                                                                onToggleRememberPosition = mainViewModel::setRememberPosition
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            // Floating round resume button on list screens only (Video, Audio, Playlist)
                                            val showFloatingBtn = currentTab != MainTab.ME &&
                                                uiState.settings.showFloatingResumeButton &&
                                                (uiState.lastPlayed != null || uiState.allVideosCount > 0 || uiState.audioItems.isNotEmpty())

                                            androidx.compose.animation.AnimatedVisibility(
                                                visible = showFloatingBtn,
                                                enter = fadeIn(tween(200)) + scaleIn(
                                                    initialScale = 0.82f,
                                                    animationSpec = spring(dampingRatio = 0.72f, stiffness = 420f)
                                                ),
                                                exit = fadeOut(tween(140)) + scaleOut(targetScale = 0.82f),
                                                modifier = Modifier
                                                    .align(Alignment.BottomEnd)
                                                    .padding(end = 18.dp, bottom = 18.dp)
                                            ) {
                                                FloatingResumeButton(
                                                    onClick = {
                                                        ensureNotificationPermission()
                                                        mainViewModel.resumeLastPlayed()
                                                        destination = AppDestination.PLAYER
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { uri ->
                pendingExternalUri.value = uri
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val settings = mainViewModel.settingsState.value
        val playback = mainViewModel.playerEngine.state.value
        val playingVideo = isPlayerActive.value &&
            playback.isPlaying &&
            playback.currentItem?.isAudio == false &&
            !playback.isBackgroundAudioMode
        if (playingVideo && settings.autoEnterPip) {
            enterPipMode(this, playback.videoWidth, playback.videoHeight)
        }
    }

    override fun onStop() {
        super.onStop()
        val playback = mainViewModel.playerEngine.state.value
        val inPip = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) isInPictureInPictureMode else false
        if (!isChangingConfigurations &&
            !inPip &&
            playback.isPlaying &&
            playback.currentItem?.isAudio == false &&
            !playback.isBackgroundAudioMode
        ) {
            mainViewModel.playerEngine.pause()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipState.value = isInPictureInPictureMode
    }
}

@Composable
private fun FastPlayerBottomBar(
    currentTab: MainTab,
    onSelectTab: (MainTab) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        NavigationBarItem(
            selected = currentTab == MainTab.VIDEO,
            onClick = { onSelectTab(MainTab.VIDEO) },
            icon = {
                Icon(
                    if (currentTab == MainTab.VIDEO) Icons.Rounded.VideoLibrary else Icons.Outlined.VideoLibrary,
                    contentDescription = stringResource(R.string.tab_video)
                )
            },
            label = { Text(stringResource(R.string.tab_video)) },
            modifier = Modifier.testTag("nav_video")
        )
        NavigationBarItem(
            selected = currentTab == MainTab.AUDIO,
            onClick = { onSelectTab(MainTab.AUDIO) },
            icon = {
                Icon(
                    if (currentTab == MainTab.AUDIO) Icons.Rounded.MusicNote else Icons.Outlined.MusicNote,
                    contentDescription = stringResource(R.string.tab_audio)
                )
            },
            label = { Text(stringResource(R.string.tab_audio)) },
            modifier = Modifier.testTag("nav_audio")
        )
        NavigationBarItem(
            selected = currentTab == MainTab.PLAYLIST,
            onClick = { onSelectTab(MainTab.PLAYLIST) },
            icon = {
                Icon(
                    if (currentTab == MainTab.PLAYLIST) Icons.AutoMirrored.Rounded.PlaylistPlay else Icons.AutoMirrored.Outlined.PlaylistPlay,
                    contentDescription = stringResource(R.string.tab_playlist)
                )
            },
            label = { Text(stringResource(R.string.tab_playlist)) },
            modifier = Modifier.testTag("nav_playlist")
        )
        NavigationBarItem(
            selected = currentTab == MainTab.ME,
            onClick = { onSelectTab(MainTab.ME) },
            icon = {
                Icon(
                    if (currentTab == MainTab.ME) Icons.Rounded.Person else Icons.Outlined.Person,
                    contentDescription = stringResource(R.string.tab_me)
                )
            },
            label = { Text(stringResource(R.string.tab_me)) },
            modifier = Modifier.testTag("nav_me")
        )
    }
}

@Composable
private fun FastPlayerNavigationRail(
    currentTab: MainTab,
    onSelectTab: (MainTab) -> Unit
) {
    NavigationRail(
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        NavigationRailItem(
            selected = currentTab == MainTab.VIDEO,
            onClick = { onSelectTab(MainTab.VIDEO) },
            icon = {
                Icon(
                    if (currentTab == MainTab.VIDEO) Icons.Rounded.VideoLibrary else Icons.Outlined.VideoLibrary,
                    contentDescription = stringResource(R.string.tab_video)
                )
            },
            label = { Text(stringResource(R.string.tab_video)) }
        )
        NavigationRailItem(
            selected = currentTab == MainTab.AUDIO,
            onClick = { onSelectTab(MainTab.AUDIO) },
            icon = {
                Icon(
                    if (currentTab == MainTab.AUDIO) Icons.Rounded.MusicNote else Icons.Outlined.MusicNote,
                    contentDescription = stringResource(R.string.tab_audio)
                )
            },
            label = { Text(stringResource(R.string.tab_audio)) }
        )
        NavigationRailItem(
            selected = currentTab == MainTab.PLAYLIST,
            onClick = { onSelectTab(MainTab.PLAYLIST) },
            icon = {
                Icon(
                    if (currentTab == MainTab.PLAYLIST) Icons.AutoMirrored.Rounded.PlaylistPlay else Icons.AutoMirrored.Outlined.PlaylistPlay,
                    contentDescription = stringResource(R.string.tab_playlist)
                )
            },
            label = { Text(stringResource(R.string.tab_playlist)) }
        )
        NavigationRailItem(
            selected = currentTab == MainTab.ME,
            onClick = { onSelectTab(MainTab.ME) },
            icon = {
                Icon(
                    if (currentTab == MainTab.ME) Icons.Rounded.Person else Icons.Outlined.Person,
                    contentDescription = stringResource(R.string.tab_me)
                )
            },
            label = { Text(stringResource(R.string.tab_me)) }
        )
    }
}
