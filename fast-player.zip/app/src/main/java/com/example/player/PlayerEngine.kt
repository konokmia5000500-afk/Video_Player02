package com.example.player

import android.content.Context
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.util.Log
import androidx.annotation.OptIn
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.upstream.DefaultAllocator
import com.example.data.local.PlaybackHistoryDao
import com.example.data.local.PlaybackHistoryEntity
import com.example.data.local.SettingsRepository
import com.example.model.AppSettings
import com.example.model.AspectRatioMode
import com.example.model.EqualizerPresetState
import com.example.model.MediaItemModel
import com.example.model.ResumeBehavior
import com.example.model.TrackInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

data class EqBandUi(
    val index: Int,
    val centerFreqHz: Int,
    val label: String,
    val levelMb: Int
)

data class PlaybackProgress(
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

data class PlayerPlaybackState(
    val queue: List<MediaItemModel> = emptyList(),
    val currentIndex: Int = -1,
    val currentItem: MediaItemModel? = null,
    val isPlaying: Boolean = false,
    val isBackgroundAudioMode: Boolean = false,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1.0f,
    val isMuted: Boolean = false,
    val isShuffle: Boolean = false,
    val loopOne: Boolean = false,
    val aspectRatioMode: AspectRatioMode = AspectRatioMode.FIT,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val audioTracks: List<TrackInfo> = emptyList(),
    val subtitleTracks: List<TrackInfo> = emptyList(),
    val subtitlesEnabled: Boolean = true,
    val externalSubtitleName: String? = null,
    val cuesText: List<String> = emptyList(),
    val abPointAMs: Long? = null,
    val abPointBMs: Long? = null,
    val sleepTimerRemainingSec: Int? = null,
    val nightModeActive: Boolean = false,
    val eqBands: List<EqBandUi> = defaultTenBandEq(),
    val eqPresets: List<String> = listOf("Normal", "Bass Boost", "Rock", "Pop", "Jazz", "Classical", "Vocal", "Custom"),
    val eqEnabled: Boolean = false,
    val eqSelectedPreset: Int = 0,
    val eqMinMb: Int = -1500,
    val eqMaxMb: Int = 1500,
    val bassBoostStrength: Int = 0,
    val loudnessGainMb: Int = 0,
    val errorMessage: String? = null,
    val pendingResumePromptMs: Long? = null
)

private fun defaultTenBandEq(): List<EqBandUi> {
    val freqs = listOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    return freqs.mapIndexed { idx, hz ->
        val label = if (hz >= 1000) "${hz / 1000} kHz" else "$hz Hz"
        EqBandUi(idx, hz, label, 0)
    }
}

@OptIn(UnstableApi::class)
class PlayerEngine(
    private val context: Context,
    private val historyDao: PlaybackHistoryDao,
    private val settingsRepository: SettingsRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _state = MutableStateFlow(PlayerPlaybackState())
    val state: StateFlow<PlayerPlaybackState> = _state.asStateFlow()

    private val _progress = MutableStateFlow(PlaybackProgress())
    val progress: StateFlow<PlaybackProgress> = _progress.asStateFlow()

    @Volatile
    private var latestSettings: AppSettings = AppSettings()
    private val historyCache = ConcurrentHashMap<String, PlaybackHistoryEntity>()

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var attachedAudioSessionId: Int = C.AUDIO_SESSION_ID_UNSET
    private var preMuteVolume: Float = 1.0f

    private var positionJob: Job? = null
    private var sleepTimerJob: Job? = null
    private var lastSavedHistoryMs: Long = 0L
    private var isPlayerInitialized = false

    val exoPlayer: ExoPlayer by lazy {
        isPlayerInitialized = true
        val allocator = DefaultAllocator(true, C.DEFAULT_BUFFER_SEGMENT_SIZE)
        val loadControl = DefaultLoadControl.Builder()
            .setAllocator(allocator)
            .setBufferDurationsMs(
                /* minBufferMs = */ 1000,
                /* maxBufferMs = */ 5000,
                /* bufferForPlaybackMs = */ 50,
                /* bufferForPlaybackAfterRebufferMs = */ 100
            )
            .setTargetBufferBytes(8 * 1024 * 1024)
            .setBackBuffer(2000, true)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val renderersFactory = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        ExoPlayer.Builder(context, renderersFactory)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setSeekParameters(SeekParameters.CLOSEST_SYNC)
            .build()
            .also { player ->
                player.addListener(playerListener)
            }
    }

    init {
        scope.launch {
            settingsRepository.settingsFlow.collect { settings ->
                latestSettings = settings
                if (isPlayerInitialized) {
                    applySettingsToPlayer(settings)
                }
            }
        }
        scope.launch(Dispatchers.IO) {
            historyDao.observeAllHistory().collect { rows ->
                for (row in rows) {
                    historyCache[row.mediaUri] = row
                }
            }
        }
    }

    fun warmUp() {
        // Initialize ExoPlayer ahead of time so first video starts instantaneously
        exoPlayer
    }

    private fun applySettingsToPlayer(settings: AppSettings) {
        try {
            exoPlayer.setSeekParameters(
                if (settings.fastSeeking) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT
            )
            val audioAttrs = AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(
                    if (_state.value.currentItem?.isAudio == true || _state.value.isBackgroundAudioMode)
                        C.AUDIO_CONTENT_TYPE_MUSIC
                    else
                        C.AUDIO_CONTENT_TYPE_MOVIE
                )
                .build()
            exoPlayer.setAudioAttributes(audioAttrs, settings.pauseOnAudioFocusLoss)

            val eq = settings.equalizerState
            val bands = if (eq.bandLevelsMb.size == 10) {
                defaultTenBandEq().mapIndexed { i, b -> b.copy(levelMb = eq.bandLevelsMb[i]) }
            } else {
                _state.value.eqBands
            }
            _state.update {
                it.copy(
                    eqEnabled = eq.enabled,
                    eqSelectedPreset = eq.selectedPresetIndex,
                    eqBands = bands,
                    bassBoostStrength = eq.bassBoostStrength,
                    loudnessGainMb = eq.loudnessGainMb
                )
            }
            if (eq.enabled || eq.bassBoostStrength > 0 || eq.loudnessGainMb > 0) {
                applyAudioEffectsToHardware()
            }
        } catch (_: Throwable) {
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.update { it.copy(isPlaying = isPlaying) }
            if (isPlaying) {
                startPositionTracker()
            } else {
                positionJob?.cancel()
                saveCurrentHistoryImmediate()
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val dur = exoPlayer.duration.coerceAtLeast(0L)
            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
            _progress.value = PlaybackProgress(pos, dur)
            if (dur != _state.value.durationMs) {
                _state.update { it.copy(durationMs = dur) }
            }

            if (playbackState == Player.STATE_ENDED) {
                saveCurrentHistoryImmediate(completed = true)
                if (_state.value.loopOne) {
                    exoPlayer.seekTo(0L)
                    exoPlayer.play()
                } else if (latestSettings.playNextAutomatically && hasNext()) {
                    playNext()
                }
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val idx = exoPlayer.currentMediaItemIndex
            val queue = _state.value.queue
            if (idx in queue.indices) {
                val item = queue[idx]
                _progress.value = PlaybackProgress(0L, item.durationMs)
                _state.update {
                    it.copy(
                        currentIndex = idx,
                        currentItem = item,
                        durationMs = item.durationMs,
                        abPointAMs = null,
                        abPointBMs = null,
                        externalSubtitleName = null,
                        cuesText = emptyList()
                    )
                }
            }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            _state.update {
                it.copy(
                    videoWidth = videoSize.width,
                    videoHeight = videoSize.height
                )
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            parseTracks(tracks)
        }

        override fun onCues(cueGroup: CueGroup) {
            val lines = cueGroup.cues.mapNotNull { it.text?.toString()?.takeIf { s -> s.isNotBlank() } }
            _state.update { it.copy(cuesText = lines) }
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            if (audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
                attachedAudioSessionId = audioSessionId
                val st = _state.value
                if (st.eqEnabled || st.bassBoostStrength > 0 || st.loudnessGainMb > 0) {
                    applyAudioEffectsToHardware()
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            if (!latestSettings.suppressErrorMessages) {
                _state.update {
                    it.copy(errorMessage = error.localizedMessage ?: "Unable to play this media file")
                }
            }
        }
    }

    fun playQueue(
        items: List<MediaItemModel>,
        startIndex: Int,
        backgroundAudioOnly: Boolean = false,
        forceStartFromZero: Boolean = false
    ) {
        if (items.isEmpty()) return

        // Window large queues around startIndex so preparation & RAM stay tiny and instant
        val maxWindow = 40
        val safeGlobalIdx = startIndex.coerceIn(0, items.lastIndex)
        val windowStart = if (items.size <= maxWindow) 0 else (safeGlobalIdx - 12).coerceIn(0, items.size - maxWindow)
        val windowEnd = (windowStart + maxWindow).coerceAtMost(items.size)
        val windowedItems = items.subList(windowStart, windowEnd)
        val safeIdx = (safeGlobalIdx - windowStart).coerceIn(0, windowedItems.lastIndex)
        val targetItem = windowedItems[safeIdx]

        val settings = latestSettings
        val savedHistory = if (settings.rememberPosition) historyCache[targetItem.uriString] else null

        val initialSpeed = if (settings.rememberTrackSelections && savedHistory != null) {
            savedHistory.playbackSpeed.coerceIn(0.25f, 4.0f)
        } else {
            settings.defaultPlaybackSpeed
        }

        val savedAspect = if (settings.rememberTrackSelections && savedHistory != null) {
            AspectRatioMode.entries.firstOrNull { it.name == savedHistory.aspectRatioMode }
                ?: AspectRatioMode.FIT
        } else {
            AspectRatioMode.FIT
        }

        val startPosMs: Long
        var promptPosMs: Long? = null
        if (!forceStartFromZero && settings.rememberPosition && savedHistory != null &&
            savedHistory.lastPositionMs > 3000L &&
            (savedHistory.durationMs <= 0L || savedHistory.lastPositionMs < savedHistory.durationMs - 5000L)
        ) {
            when (settings.resumeBehavior) {
                ResumeBehavior.ALWAYS_RESUME -> startPosMs = savedHistory.lastPositionMs
                ResumeBehavior.ASK -> {
                    startPosMs = 0L
                    promptPosMs = savedHistory.lastPositionMs
                }
                ResumeBehavior.START_OVER -> startPosMs = 0L
            }
        } else {
            startPosMs = 0L
        }

        val isMuted = settings.muteOnStart
        preMuteVolume = 1.0f

        val mediaItems = windowedItems.map { buildMedia3Item(it) }
        val audioMode = backgroundAudioOnly || targetItem.isAudio

        exoPlayer.volume = if (isMuted) 0f else 1f
        exoPlayer.setPlaybackSpeed(initialSpeed)
        exoPlayer.repeatMode = if (_state.value.loopOne) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        exoPlayer.shuffleModeEnabled = _state.value.isShuffle
        exoPlayer.setSeekParameters(
            if (settings.fastSeeking) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT
        )
        exoPlayer.setMediaItems(mediaItems, safeIdx, startPosMs)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true

        _progress.value = PlaybackProgress(startPosMs, targetItem.durationMs)
        _state.update {
            it.copy(
                queue = windowedItems,
                currentIndex = safeIdx,
                currentItem = targetItem,
                isBackgroundAudioMode = audioMode,
                durationMs = targetItem.durationMs,
                playbackSpeed = initialSpeed,
                isMuted = isMuted,
                aspectRatioMode = savedAspect,
                subtitlesEnabled = settings.subtitleAppearance.enabledByDefault,
                abPointAMs = null,
                abPointBMs = null,
                errorMessage = null,
                pendingResumePromptMs = promptPosMs
            )
        }

        // Start foreground service ONLY for audio/background playback (avoids Android 12 video start crashes)
        if (audioMode) {
            startPlaybackService()
        }
        startPositionTracker()
        saveCurrentHistoryImmediate()
    }

    fun confirmResumeFromPrompt(resume: Boolean) {
        val pos = _state.value.pendingResumePromptMs
        _state.update { it.copy(pendingResumePromptMs = null) }
        if (resume && pos != null) {
            seekTo(pos)
        }
    }

    fun clearError() {
        _state.update { it.copy(errorMessage = null) }
    }

    private fun buildMedia3Item(item: MediaItemModel, externalSubUri: Uri? = null): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(item.title)
            .setArtist(item.artist ?: item.folderName)
            .setAlbumTitle(item.album)
            .build()

        val builder = MediaItem.Builder()
            .setMediaId(item.uriString)
            .setUri(Uri.parse(item.uriString))
            .setMediaMetadata(metadata)

        if (externalSubUri != null) {
            val mime = guessSubtitleMimeType(externalSubUri)
            val subConfig = MediaItem.SubtitleConfiguration.Builder(externalSubUri)
                .setMimeType(mime)
                .setLanguage("en")
                .setLabel("External Subtitle")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            builder.setSubtitleConfigurations(listOf(subConfig))
        }
        return builder.build()
    }

    private fun guessSubtitleMimeType(uri: Uri): String {
        val lower = uri.toString().lowercase()
        return when {
            lower.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            lower.endsWith(".ass") || lower.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
    }

    fun loadExternalSubtitle(uri: Uri, displayName: String) {
        val item = _state.value.currentItem ?: return
        val currentPos = exoPlayer.currentPosition
        val wasPlaying = exoPlayer.isPlaying
        val idx = exoPlayer.currentMediaItemIndex.coerceAtLeast(0)
        val updatedMediaItem = buildMedia3Item(item, uri)
        exoPlayer.replaceMediaItem(idx, updatedMediaItem)
        exoPlayer.seekTo(idx, currentPos)
        exoPlayer.playWhenReady = wasPlaying
        setSubtitlesEnabled(true)
        _state.update { it.copy(externalSubtitleName = displayName) }
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            if (exoPlayer.playbackState == Player.STATE_ENDED) {
                exoPlayer.seekTo(0L)
            }
            exoPlayer.play()
        }
    }

    fun pause() {
        exoPlayer.pause()
    }

    fun play() {
        exoPlayer.play()
    }

    fun seekTo(positionMs: Long) {
        val dur = exoPlayer.duration.coerceAtLeast(_state.value.durationMs)
        val clamped = if (dur > 0L) positionMs.coerceIn(0L, dur) else positionMs.coerceAtLeast(0L)
        exoPlayer.seekTo(clamped)
        _progress.value = PlaybackProgress(clamped, dur)
    }

    fun seekBy(deltaMs: Long) {
        seekTo(exoPlayer.currentPosition + deltaMs)
    }

    fun hasNext(): Boolean {
        val q = _state.value.queue
        return q.size > 1 && (_state.value.currentIndex < q.lastIndex || _state.value.isShuffle)
    }

    fun playNext() {
        if (exoPlayer.hasNextMediaItem()) {
            exoPlayer.seekToNextMediaItem()
            exoPlayer.play()
        } else if (_state.value.queue.isNotEmpty()) {
            exoPlayer.seekTo(0, 0L)
            exoPlayer.play()
        }
    }

    fun playPrevious() {
        if (latestSettings.smartPreviousButton && exoPlayer.currentPosition > 3500L) {
            exoPlayer.seekTo(0L)
            return
        }
        if (exoPlayer.hasPreviousMediaItem()) {
            exoPlayer.seekToPreviousMediaItem()
            exoPlayer.play()
        } else {
            exoPlayer.seekTo(0L)
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.25f, 4.0f)
        exoPlayer.setPlaybackSpeed(clamped)
        _state.update { it.copy(playbackSpeed = clamped) }
        saveCurrentHistoryImmediate()
    }

    fun setTemporarySpeed(speed: Float) {
        exoPlayer.setPlaybackSpeed(speed.coerceIn(0.25f, 4.0f))
    }

    fun restoreSavedSpeed() {
        exoPlayer.setPlaybackSpeed(_state.value.playbackSpeed)
    }

    fun toggleMute() {
        val nextMuted = !_state.value.isMuted
        if (nextMuted) {
            preMuteVolume = exoPlayer.volume.takeIf { it > 0f } ?: 1f
            exoPlayer.volume = 0f
        } else {
            exoPlayer.volume = preMuteVolume
        }
        _state.update { it.copy(isMuted = nextMuted) }
    }

    fun toggleLoop() {
        val nextLoop = !_state.value.loopOne
        exoPlayer.repeatMode = if (nextLoop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        _state.update { it.copy(loopOne = nextLoop) }
    }

    fun toggleShuffle() {
        val nextShuffle = !_state.value.isShuffle
        exoPlayer.shuffleModeEnabled = nextShuffle
        _state.update { it.copy(isShuffle = nextShuffle) }
    }

    fun cycleAspectRatio(): AspectRatioMode {
        val modes = AspectRatioMode.entries
        val next = modes[(_state.value.aspectRatioMode.ordinal + 1) % modes.size]
        _state.update { it.copy(aspectRatioMode = next) }
        saveCurrentHistoryImmediate()
        return next
    }

    fun setAspectRatio(mode: AspectRatioMode) {
        _state.update { it.copy(aspectRatioMode = mode) }
        saveCurrentHistoryImmediate()
    }

    fun toggleNightMode() {
        _state.update { it.copy(nightModeActive = !it.nightModeActive) }
    }

    fun enterBackgroundAudioMode() {
        _state.update { it.copy(isBackgroundAudioMode = true) }
        startPlaybackService()
    }

    fun enterVideoMode() {
        _state.update { it.copy(isBackgroundAudioMode = false) }
    }

    fun stopPlaybackAndClear() {
        saveCurrentHistoryImmediate()
        sleepTimerJob?.cancel()
        positionJob?.cancel()
        releaseAudioEffects()
        exoPlayer.stop()
        exoPlayer.clearMediaItems()
        _progress.value = PlaybackProgress()
        _state.update {
            PlayerPlaybackState(
                eqBands = it.eqBands,
                eqPresets = it.eqPresets,
                eqEnabled = it.eqEnabled,
                eqSelectedPreset = it.eqSelectedPreset,
                bassBoostStrength = it.bassBoostStrength,
                loudnessGainMb = it.loudnessGainMb
            )
        }
        try {
            context.stopService(Intent(context, PlaybackService::class.java))
        } catch (_: Throwable) {
        }
    }

    fun setAbPointA(ms: Long = exoPlayer.currentPosition) {
        _state.update { it.copy(abPointAMs = ms) }
    }

    fun setAbPointB(ms: Long = exoPlayer.currentPosition) {
        val a = _state.value.abPointAMs
        if (a != null && ms > a + 300L) {
            _state.update { it.copy(abPointBMs = ms) }
        }
    }

    fun clearAbRepeat() {
        _state.update { it.copy(abPointAMs = null, abPointBMs = null) }
    }

    fun setSleepTimerMinutes(minutes: Int?) {
        sleepTimerJob?.cancel()
        if (minutes == null || minutes <= 0) {
            _state.update { it.copy(sleepTimerRemainingSec = null) }
            return
        }
        var remainingSec = minutes * 60
        _state.update { it.copy(sleepTimerRemainingSec = remainingSec) }
        sleepTimerJob = scope.launch {
            while (remainingSec > 0 && isActive) {
                delay(1000L)
                remainingSec -= 1
                _state.update { it.copy(sleepTimerRemainingSec = remainingSec) }
            }
            if (isActive) {
                exoPlayer.pause()
                _state.update { it.copy(sleepTimerRemainingSec = null) }
            }
        }
    }

    private fun parseTracks(tracks: Tracks) {
        val audio = mutableListOf<TrackInfo>()
        val subs = mutableListOf<TrackInfo>()

        tracks.groups.forEachIndexed { gIdx, group ->
            when (group.type) {
                C.TRACK_TYPE_AUDIO -> {
                    for (tIdx in 0 until group.length) {
                        val fmt = group.getTrackFormat(tIdx)
                        val lang = fmt.language ?: "und"
                        val label = fmt.label ?: lang.uppercase()
                        val ch = if (fmt.channelCount > 0) "${fmt.channelCount}ch" else ""
                        val details = listOfNotNull(
                            fmt.codecs?.takeIf { it.isNotBlank() },
                            ch.takeIf { it.isNotBlank() }
                        ).joinToString(" • ")
                        audio.add(
                            TrackInfo(
                                groupIndex = gIdx,
                                trackIndex = tIdx,
                                label = label,
                                language = fmt.language,
                                isSelected = group.isTrackSelected(tIdx),
                                details = details
                            )
                        )
                    }
                }
                C.TRACK_TYPE_TEXT -> {
                    for (tIdx in 0 until group.length) {
                        val fmt = group.getTrackFormat(tIdx)
                        val lang = fmt.language ?: "und"
                        val label = fmt.label ?: lang.uppercase()
                        subs.add(
                            TrackInfo(
                                groupIndex = gIdx,
                                trackIndex = tIdx,
                                label = label,
                                language = fmt.language,
                                isSelected = group.isTrackSelected(tIdx),
                                details = fmt.sampleMimeType ?: ""
                            )
                        )
                    }
                }
            }
        }
        _state.update { it.copy(audioTracks = audio, subtitleTracks = subs) }
    }

    fun selectAudioTrack(track: TrackInfo) {
        val groups = exoPlayer.currentTracks.groups
        if (track.groupIndex !in groups.indices) return
        val group: TrackGroup = groups[track.groupIndex].mediaTrackGroup
        val params = exoPlayer.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(group, track.trackIndex))
            .build()
        exoPlayer.trackSelectionParameters = params
    }

    fun selectSubtitleTrack(track: TrackInfo?) {
        if (track == null) {
            setSubtitlesEnabled(false)
            return
        }
        setSubtitlesEnabled(true)
        val groups = exoPlayer.currentTracks.groups
        if (track.groupIndex !in groups.indices) return
        val group: TrackGroup = groups[track.groupIndex].mediaTrackGroup
        val params = exoPlayer.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(group, track.trackIndex))
            .build()
        exoPlayer.trackSelectionParameters = params
    }

    fun setSubtitlesEnabled(enabled: Boolean) {
        val params = exoPlayer.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !enabled)
            .build()
        exoPlayer.trackSelectionParameters = params
        _state.update {
            it.copy(
                subtitlesEnabled = enabled,
                cuesText = if (enabled) it.cuesText else emptyList()
            )
        }
    }

    fun setEqualizerEnabled(enabled: Boolean) {
        _state.update { it.copy(eqEnabled = enabled) }
        applyAudioEffectsToHardware()
        persistEqualizerState()
    }

    fun selectEqualizerPreset(presetIndex: Int) {
        val presets = listOf(
            listOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
            listOf(600, 550, 450, 250, 50, 0, 0, 100, 150, 200),
            listOf(500, 400, 250, -100, -150, 50, 250, 400, 500, 550),
            listOf(-150, 150, 350, 450, 300, 50, -100, -50, 150, 250),
            listOf(350, 250, 100, 200, -150, -150, 0, 200, 350, 400),
            listOf(450, 350, 250, 150, -100, -100, 0, 250, 400, 450),
            listOf(-200, -150, 0, 250, 450, 500, 400, 200, 50, -100),
            _state.value.eqBands.map { it.levelMb }
        )
        val targetLevels = presets.getOrElse(presetIndex) { presets[0] }
        val updatedBands = _state.value.eqBands.mapIndexed { idx, band ->
            band.copy(levelMb = targetLevels.getOrElse(idx) { 0 })
        }
        _state.update {
            it.copy(
                eqEnabled = true,
                eqSelectedPreset = presetIndex,
                eqBands = updatedBands
            )
        }
        applyAudioEffectsToHardware()
        persistEqualizerState()
    }

    fun updateEqualizerBand(bandIndex: Int, levelMb: Int) {
        val min = _state.value.eqMinMb
        val max = _state.value.eqMaxMb
        val clamped = levelMb.coerceIn(min, max)
        val updated = _state.value.eqBands.map {
            if (it.index == bandIndex) it.copy(levelMb = clamped) else it
        }
        _state.update {
            it.copy(
                eqEnabled = true,
                eqSelectedPreset = it.eqPresets.lastIndex,
                eqBands = updated
            )
        }
        applyAudioEffectsToHardware()
        persistEqualizerState()
    }

    fun updateAudioEffects(bassStrength: Int, loudnessMb: Int) {
        _state.update {
            it.copy(
                bassBoostStrength = bassStrength.coerceIn(0, 1000),
                loudnessGainMb = loudnessMb.coerceIn(0, 1500)
            )
        }
        applyAudioEffectsToHardware()
        persistEqualizerState()
    }

    private fun applyAudioEffectsToHardware() {
        val sessionId = attachedAudioSessionId
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId == 0) return
        val st = _state.value

        try {
            if (st.eqEnabled) {
                if (equalizer == null) {
                    equalizer = Equalizer(0, sessionId).apply {
                        val range = bandLevelRange
                        if (range.size >= 2) {
                            _state.update {
                                it.copy(eqMinMb = range[0].toInt(), eqMaxMb = range[1].toInt())
                            }
                        }
                    }
                }
                equalizer?.let { eq ->
                    eq.enabled = true
                    val numHwBands = eq.numberOfBands.toInt()
                    val uiBands = st.eqBands
                    for (hwIdx in 0 until numHwBands) {
                        val centerHz = eq.getCenterFreq(hwIdx.toShort()) / 1000
                        val closest = uiBands.minByOrNull { kotlin.math.abs(it.centerFreqHz - centerHz) }
                        val level = (closest?.levelMb ?: 0).coerceIn(st.eqMinMb, st.eqMaxMb).toShort()
                        eq.setBandLevel(hwIdx.toShort(), level)
                    }
                }
            } else {
                equalizer?.enabled = false
            }
        } catch (t: Throwable) {
            Log.w("PlayerEngine", "Equalizer unavailable: ${t.message}")
        }

        try {
            if (st.bassBoostStrength > 0) {
                if (bassBoost == null) {
                    bassBoost = BassBoost(0, sessionId)
                }
                bassBoost?.let { bb ->
                    bb.enabled = true
                    if (bb.strengthSupported) {
                        bb.setStrength(st.bassBoostStrength.toShort())
                    }
                }
            } else {
                bassBoost?.enabled = false
            }
        } catch (t: Throwable) {
            Log.w("PlayerEngine", "BassBoost unavailable: ${t.message}")
        }

        try {
            if (st.loudnessGainMb > 0) {
                if (loudnessEnhancer == null) {
                    loudnessEnhancer = LoudnessEnhancer(sessionId)
                }
                loudnessEnhancer?.let { le ->
                    le.enabled = true
                    le.setTargetGain(st.loudnessGainMb)
                }
            } else {
                loudnessEnhancer?.enabled = false
            }
        } catch (t: Throwable) {
            Log.w("PlayerEngine", "LoudnessEnhancer unavailable: ${t.message}")
        }
    }

    private fun persistEqualizerState() {
        val st = _state.value
        scope.launch {
            settingsRepository.updateEqualizerState(
                EqualizerPresetState(
                    enabled = st.eqEnabled,
                    selectedPresetIndex = st.eqSelectedPreset,
                    bandLevelsMb = st.eqBands.map { it.levelMb },
                    bassBoostStrength = st.bassBoostStrength,
                    loudnessGainMb = st.loudnessGainMb
                )
            )
        }
    }

    private fun releaseAudioEffects() {
        try { equalizer?.release() } catch (_: Throwable) {}
        try { bassBoost?.release() } catch (_: Throwable) {}
        try { loudnessEnhancer?.release() } catch (_: Throwable) {}
        equalizer = null
        bassBoost = null
        loudnessEnhancer = null
    }

    private fun startPositionTracker() {
        if (positionJob?.isActive == true) return
        positionJob = scope.launch {
            while (isActive) {
                val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                val dur = exoPlayer.duration.coerceAtLeast(_state.value.currentItem?.durationMs ?: 0L)
                val isPlaying = exoPlayer.isPlaying
                _progress.value = PlaybackProgress(pos, dur)
                if (_state.value.isPlaying != isPlaying || _state.value.durationMs != dur) {
                    _state.update { it.copy(isPlaying = isPlaying, durationMs = dur) }
                }

                val a = _state.value.abPointAMs
                val b = _state.value.abPointBMs
                if (a != null && b != null && pos >= b) {
                    exoPlayer.seekTo(a)
                }

                val now = System.currentTimeMillis()
                if (isPlaying && now - lastSavedHistoryMs > 25000L) {
                    lastSavedHistoryMs = now
                    saveCurrentHistoryImmediate()
                }
                delay(280L)
            }
        }
    }

    fun saveCurrentHistoryImmediate(completed: Boolean = false) {
        val item = _state.value.currentItem ?: return
        if (!latestSettings.rememberPosition) return
        val pos = if (completed) 0L else exoPlayer.currentPosition.coerceAtLeast(0L)
        val dur = exoPlayer.duration.coerceAtLeast(item.durationMs)
        val speed = _state.value.playbackSpeed
        val aspect = _state.value.aspectRatioMode.name
        val entity = PlaybackHistoryEntity(
            mediaUri = item.uriString,
            title = item.title,
            folderPath = item.folderPath,
            isAudio = item.isAudio,
            lastPositionMs = pos,
            durationMs = dur,
            lastPlayedAt = System.currentTimeMillis(),
            playbackSpeed = speed,
            aspectRatioMode = aspect
        )
        historyCache[item.uriString] = entity
        scope.launch(Dispatchers.IO) {
            historyDao.upsert(entity)
        }
    }

    private fun startPlaybackService() {
        val intent = Intent(context, PlaybackService::class.java)
        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (_: Throwable) {
            try {
                context.startService(intent)
            } catch (_: Throwable) {
            }
        }
    }
}
