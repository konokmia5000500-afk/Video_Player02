package com.example

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.example.data.local.FastPlayerDatabase
import com.example.data.local.MediaStoreRepository
import com.example.data.local.SettingsRepository
import com.example.data.local.ThumbnailCacheManager
import com.example.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class FastPlayerApp : Application(), ImageLoaderFactory {

    lateinit var database: FastPlayerDatabase
        private set
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var mediaStoreRepository: MediaStoreRepository
        private set
    lateinit var playerEngine: PlayerEngine
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    @Volatile
    private var cachedImageLoader: ImageLoader? = null

    override fun onCreate() {
        super.onCreate()
        database = FastPlayerDatabase.getInstance(this)
        settingsRepository = SettingsRepository(this)
        mediaStoreRepository = MediaStoreRepository(this)
        playerEngine = PlayerEngine(
            context = this,
            historyDao = database.playbackHistoryDao(),
            settingsRepository = settingsRepository
        )

        // Apply thumbnail cache preference asynchronously without blocking startup
        appScope.launch {
            val thumbCache = settingsRepository.settingsFlow.first().thumbnailCacheEnabled
            if (!thumbCache) {
                rebuildImageLoader(false)
            }
        }
    }

    override fun newImageLoader(): ImageLoader {
        return ThumbnailCacheManager.buildImageLoader(this, diskCacheEnabled = true).also {
            cachedImageLoader = it
        }
    }

    fun rebuildImageLoader(diskCacheEnabled: Boolean): ImageLoader {
        return ThumbnailCacheManager.buildImageLoader(this, diskCacheEnabled).also {
            cachedImageLoader = it
        }
    }

    fun currentImageLoader(): ImageLoader {
        return cachedImageLoader ?: newImageLoader()
    }
}
