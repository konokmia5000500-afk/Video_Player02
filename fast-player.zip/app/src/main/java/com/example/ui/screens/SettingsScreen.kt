package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.PlayCircleOutline
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.model.ResumeBehavior
import com.example.model.ScreenOrientationMode
import com.example.ui.viewmodel.LibraryUiState
import com.example.ui.viewmodel.MainViewModel
import com.example.util.FormatUtils

private enum class SettingsCategory(val title: String, val subtitle: String, val icon: ImageVector) {
    LIST("List", "Appearance, NEW badge, scan folders, hidden folders", Icons.AutoMirrored.Rounded.FormatListBulleted),
    PLAYER("Player", "Interface, controls, resume, seeking, PiP", Icons.Rounded.PlayCircleOutline),
    DECODER("Decoder", "Seek accuracy, audio offload", Icons.Rounded.Memory),
    AUDIO("Audio", "Audio focus, start muted", Icons.Rounded.GraphicEq),
    SUBTITLE("Subtitle", "Appearance, font size, colors, margin", Icons.Rounded.Subtitles),
    GENERAL("General", "History, thumbnail cache, reset", Icons.Rounded.Settings)
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    uiState: LibraryUiState,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeCategory by remember { mutableStateOf<SettingsCategory?>(null) }
    val settings = uiState.settings

    BackHandler {
        if (activeCategory != null) {
            activeCategory = null
        } else {
            onBack()
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(activeCategory?.title ?: "Settings") },
            navigationIcon = {
                IconButton(
                    onClick = {
                        if (activeCategory != null) activeCategory = null else onBack()
                    }
                ) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        AnimatedContent(
            targetState = activeCategory,
            transitionSpec = {
                val offsetSign = if (targetState != null) 1 else -1
                (fadeIn(tween(180, easing = FastOutSlowInEasing)) +
                    slideInHorizontally(tween(180)) { offsetSign * (it / 16) })
                    .togetherWith(fadeOut(tween(130)))
            },
            label = "settings_cat_nav",
            modifier = Modifier.weight(1f)
        ) { currentCat ->
            if (currentCat == null) {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(SettingsCategory.entries) { cat ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { activeCategory = cat }
                                .padding(horizontal = 20.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = cat.icon,
                                contentDescription = cat.title,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(18.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(cat.title, style = MaterialTheme.typography.titleMedium)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    cat.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        HorizontalDivider(
                            modifier = Modifier.padding(start = 64.dp),
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 32.dp)
                ) {
                    when (currentCat) {
                        SettingsCategory.LIST -> ListSettingsContent(uiState, viewModel)
                        SettingsCategory.PLAYER -> PlayerSettingsContent(uiState, viewModel)
                        SettingsCategory.DECODER -> DecoderSettingsContent(uiState, viewModel)
                        SettingsCategory.AUDIO -> AudioSettingsContent(uiState, viewModel)
                        SettingsCategory.SUBTITLE -> SubtitleSettingsContent(uiState, viewModel)
                        SettingsCategory.GENERAL -> GeneralSettingsContent(uiState, viewModel)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ListSettingsContent(uiState: LibraryUiState, viewModel: MainViewModel) {
    val s = uiState.settings
    var showNewDaysDialog by remember { mutableStateOf(false) }
    var showFolderChooser by remember { mutableStateOf(false) }

    SettingsSectionHeader("Appearance")
    SettingsSwitchItem(
        title = "Mark last played in each folder",
        subtitle = "Highlight the most recently played media and folder in blue",
        checked = s.markLastPlayedInEachFolder,
        onCheckedChange = viewModel::setMarkLastPlayedFolder
    )
    SettingsSwitchItem(
        title = "Scroll to last media",
        subtitle = "Automatically scroll to the last played item when opening a folder",
        checked = s.scrollToLastMedia,
        onCheckedChange = viewModel::setScrollToLastMedia
    )
    SettingsSwitchItem(
        title = "Floating resume button",
        subtitle = "Show the round play button on list screens",
        checked = s.showFloatingResumeButton,
        onCheckedChange = viewModel::setShowFloatingResume
    )
    SettingsClickItem(
        title = "Period tagged as NEW",
        subtitle = "Mark files added within the last ${s.newBadgeDays} days",
        onClick = { showNewDaysDialog = true }
    )

    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
    SettingsSectionHeader("Scan")
    SettingsClickItem(
        title = "Choose folders",
        subtitle = if (s.excludedFolders.isEmpty()) "All video folders included"
        else "${s.excludedFolders.size} folder(s) hidden from list",
        onClick = {
            viewModel.loadDiscoveredFolders()
            showFolderChooser = true
        }
    )
    SettingsSwitchItem(
        title = "Show hidden folders",
        subtitle = "Include folders whose names start with a dot (.)",
        checked = s.viewOptions.showHiddenFolders,
        onCheckedChange = viewModel::setShowHiddenFolders
    )

    if (showNewDaysDialog) {
        var text by remember(s.newBadgeDays) { mutableStateOf(s.newBadgeDays.toString()) }
        val days = text.toIntOrNull()
        val valid = days != null && days in 1..90
        AlertDialog(
            onDismissRequest = { showNewDaysDialog = false },
            title = { Text("Period tagged as NEW") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it.filter { ch -> ch.isDigit() }.take(2) },
                        label = { Text("Days (1–90)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1, 3, 7, 14, 30).forEach { d ->
                            QuickChip(label = "${d}d", selected = days == d, onClick = { text = d.toString() })
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (valid) {
                            viewModel.setNewBadgeDays(days!!)
                            showNewDaysDialog = false
                        }
                    },
                    enabled = valid
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showNewDaysDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showFolderChooser) {
        LaunchedEffect(Unit) { viewModel.loadDiscoveredFolders() }
        AlertDialog(
            onDismissRequest = { showFolderChooser = false },
            title = { Text("Choose Folders") },
            text = {
                if (uiState.discoveredFolders.isEmpty()) {
                    Text("No video folders found on device.")
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                        items(uiState.discoveredFolders, key = { it.first }) { (path, count) ->
                            val included = path !in s.excludedFolders
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.toggleFolderExcluded(path) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = included,
                                    onCheckedChange = { viewModel.toggleFolderExcluded(path) }
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(path.substringAfterLast('/'), style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "$count videos • $path",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showFolderChooser = false }) { Text("Done") }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlayerSettingsContent(uiState: LibraryUiState, viewModel: MainViewModel) {
    val s = uiState.settings
    var showSeekDialog by remember { mutableStateOf(false) }
    var showOrientationDialog by remember { mutableStateOf(false) }
    var showResumeDialog by remember { mutableStateOf(false) }

    SettingsSectionHeader("Interface")
    SettingsClickItem(
        title = "Screen orientation",
        subtitle = s.screenOrientationMode.label,
        onClick = { showOrientationDialog = true }
    )
    SettingsSwitchItem(
        title = "Show battery & clock in player",
        subtitle = "Display current time and battery level in the player top bar",
        checked = s.showBatteryAndClock,
        onCheckedChange = viewModel::setShowBatteryAndClock
    )
    SettingsClickItem(
        title = "Controls auto-hide delay",
        subtitle = "Hide overlay after ${s.controlsAutoHideSeconds}s",
        onClick = {
            val next = when (s.controlsAutoHideSeconds) {
                3 -> 4
                4 -> 6
                6 -> 8
                else -> 3
            }
            viewModel.setControlsAutoHideSeconds(next)
        }
    )
    SettingsSwitchItem(
        title = "Quick zoom",
        subtitle = "Pinch with two fingers to zoom & pan during playback",
        checked = s.quickZoomEnabled,
        onCheckedChange = viewModel::setQuickZoomEnabled
    )
    SettingsSwitchItem(
        title = "Double-tap back to close",
        subtitle = "Require pressing Back twice to exit the video player",
        checked = s.doubleTapBackToClose,
        onCheckedChange = viewModel::setDoubleTapBackToClose
    )
    SettingsSwitchItem(
        title = "Keep screen on during video",
        subtitle = "Never keeps screen on during audio-only playback",
        checked = s.keepScreenOnVideo,
        onCheckedChange = viewModel::setKeepScreenOnVideo
    )

    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
    SettingsSectionHeader("Playback")
    SettingsClickItem(
        title = "Double-tap skip time",
        subtitle = "${s.doubleTapSeekSeconds} seconds",
        onClick = { showSeekDialog = true }
    )
    SettingsClickItem(
        title = "Resume",
        subtitle = s.resumeBehavior.label,
        onClick = { showResumeDialog = true }
    )
    SettingsSwitchItem(
        title = "Remember position",
        subtitle = "Save playback progress automatically",
        checked = s.rememberPosition,
        onCheckedChange = viewModel::setRememberPosition
    )
    SettingsSwitchItem(
        title = "Remember selections",
        subtitle = "Save playback speed and aspect ratio per file",
        checked = s.rememberTrackSelections,
        onCheckedChange = viewModel::setRememberTrackSelections
    )
    SettingsSwitchItem(
        title = "Fast seeking",
        subtitle = "Jump instantly to nearest keyframe without buffering delay",
        checked = s.fastSeeking,
        onCheckedChange = viewModel::setFastSeeking
    )
    SettingsSwitchItem(
        title = "Preview while seeking",
        subtitle = "Update video frame immediately while dragging seek bar",
        checked = s.previewWhileSeeking,
        onCheckedChange = viewModel::setPreviewWhileSeeking
    )
    SettingsSwitchItem(
        title = "Play next automatically",
        subtitle = "Automatically advance to the next item in the folder/playlist",
        checked = s.playNextAutomatically,
        onCheckedChange = viewModel::setPlayNextAutomatically
    )
    SettingsSwitchItem(
        title = "Smart previous button",
        subtitle = "Restart current track if past 3s, otherwise jump to previous",
        checked = s.smartPreviousButton,
        onCheckedChange = viewModel::setSmartPrevious
    )
    SettingsSwitchItem(
        title = "Auto Picture-in-Picture",
        subtitle = "Enter PiP mode automatically when leaving app during video playback",
        checked = s.autoEnterPip,
        onCheckedChange = viewModel::setAutoEnterPip
    )
    SettingsSwitchItem(
        title = "Suppress error message",
        subtitle = "Hide playback warning dialogs when a codec fails",
        checked = s.suppressErrorMessages,
        onCheckedChange = viewModel::setSuppressErrors
    )

    if (showSeekDialog) {
        DoubleTapSeekStepDialog(
            currentSeconds = s.doubleTapSeekSeconds,
            onDismiss = { showSeekDialog = false },
            onSave = {
                viewModel.setDoubleTapSeekSeconds(it)
                showSeekDialog = false
            }
        )
    }

    if (showOrientationDialog) {
        AlertDialog(
            onDismissRequest = { showOrientationDialog = false },
            title = { Text("Screen Orientation") },
            text = {
                Column {
                    ScreenOrientationMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setScreenOrientation(mode)
                                    showOrientationDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = s.screenOrientationMode == mode,
                                onClick = {
                                    viewModel.setScreenOrientation(mode)
                                    showOrientationDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(mode.label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showOrientationDialog = false }) { Text("Close") }
            }
        )
    }

    if (showResumeDialog) {
        AlertDialog(
            onDismissRequest = { showResumeDialog = false },
            title = { Text("Resume Playback") },
            text = {
                Column {
                    ResumeBehavior.entries.forEach { b ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setResumeBehavior(b)
                                    showResumeDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = s.resumeBehavior == b,
                                onClick = {
                                    viewModel.setResumeBehavior(b)
                                    showResumeDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(b.label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showResumeDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun DecoderSettingsContent(uiState: LibraryUiState, viewModel: MainViewModel) {
    val s = uiState.settings
    SettingsSectionHeader("Decoder & Seeking")
    SettingsSwitchItem(
        title = "Keyframe-aligned fast seek",
        subtitle = "Uses closest sync frames for zero-lag scrubbing and double-tap skips",
        checked = s.fastSeeking,
        onCheckedChange = viewModel::setFastSeeking
    )
    SettingsSwitchItem(
        title = "Hardware audio offload",
        subtitle = "Save battery on supported devices during long audio sessions",
        checked = s.audioOffload,
        onCheckedChange = viewModel::setAudioOffload
    )
}

@Composable
private fun AudioSettingsContent(uiState: LibraryUiState, viewModel: MainViewModel) {
    val s = uiState.settings
    SettingsSectionHeader("Audio Playback")
    SettingsSwitchItem(
        title = "Pause on audio focus loss",
        subtitle = "Automatically pause when calls or other media apps start",
        checked = s.pauseOnAudioFocusLoss,
        onCheckedChange = viewModel::setPauseOnAudioFocusLoss
    )
    SettingsSwitchItem(
        title = "Start muted",
        subtitle = "Start newly opened media with volume muted",
        checked = s.muteOnStart,
        onCheckedChange = viewModel::setMuteOnStart
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SubtitleSettingsContent(uiState: LibraryUiState, viewModel: MainViewModel) {
    val sub = uiState.settings.subtitleAppearance
    SettingsSectionHeader("Subtitles")
    SettingsSwitchItem(
        title = "Enable subtitles by default",
        subtitle = "Show embedded subtitles automatically if available",
        checked = sub.enabledByDefault,
        onCheckedChange = { viewModel.updateSubtitleAppearance(sub.copy(enabledByDefault = it)) }
    )
    SettingsSwitchItem(
        title = "Bold subtitle text",
        subtitle = "Render subtitles in bold weight",
        checked = sub.boldText,
        onCheckedChange = { viewModel.updateSubtitleAppearance(sub.copy(boldText = it)) }
    )
    SettingsSwitchItem(
        title = "Dark subtitle background",
        subtitle = "Add subtle translucent backdrop behind subtitle text",
        checked = sub.backgroundDim,
        onCheckedChange = { viewModel.updateSubtitleAppearance(sub.copy(backgroundDim = it)) }
    )

    Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
        Text("Font size: ${sub.fontSizeSp.toInt()}sp", style = MaterialTheme.typography.titleSmall)
        Slider(
            value = sub.fontSizeSp,
            onValueChange = { viewModel.updateSubtitleAppearance(sub.copy(fontSizeSp = it)) },
            valueRange = 12f..32f
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text("Bottom margin: ${sub.bottomPaddingDp.toInt()}dp", style = MaterialTheme.typography.titleSmall)
        Slider(
            value = sub.bottomPaddingDp,
            onValueChange = { viewModel.updateSubtitleAppearance(sub.copy(bottomPaddingDp = it)) },
            valueRange = 12f..100f
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text("Subtitle color", style = MaterialTheme.typography.titleSmall)
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "White" to 0xFFFFFFFFL,
                "Yellow" to 0xFFFFEB3BL,
                "Cyan" to 0xFF4DD0E1L,
                "Green" to 0xFF81C784L
            ).forEach { (name, argb) ->
                QuickChip(
                    label = name,
                    selected = sub.textColorArgb == argb,
                    onClick = { viewModel.updateSubtitleAppearance(sub.copy(textColorArgb = argb)) }
                )
            }
        }
    }
}

@Composable
private fun GeneralSettingsContent(uiState: LibraryUiState, viewModel: MainViewModel) {
    val s = uiState.settings
    var confirmClearHistory by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }

    SettingsSectionHeader("User Data & Cache")
    SettingsSwitchItem(
        title = "Thumbnail cache",
        subtitle = "Cache video thumbnails on disk for faster scrolling",
        checked = s.thumbnailCacheEnabled,
        onCheckedChange = viewModel::setThumbnailCacheEnabled
    )
    SettingsClickItem(
        title = "Clear thumbnail cache",
        subtitle = "Currently using ${FormatUtils.formatFileSize(uiState.thumbnailCacheSizeBytes)}",
        onClick = viewModel::clearThumbnailCache
    )
    SettingsClickItem(
        title = "Clear playback history",
        subtitle = "Remove saved resume positions and last-played markers",
        onClick = { confirmClearHistory = true }
    )
    SettingsClickItem(
        title = "Reset all settings",
        subtitle = "Restore default preferences",
        onClick = { confirmReset = true }
    )

    if (confirmClearHistory) {
        AlertDialog(
            onDismissRequest = { confirmClearHistory = false },
            title = { Text("Clear history?") },
            text = { Text("All saved resume positions and last-played markers will be cleared.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearPlaybackHistory()
                        confirmClearHistory = false
                    }
                ) { Text("Clear", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearHistory = false }) { Text("Cancel") }
            }
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset settings?") },
            text = { Text("All Fast Player preferences will return to their default values.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.resetAllSettings()
                        confirmReset = false
                    }
                ) { Text("Reset", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
    )
}

@Composable
private fun SettingsSwitchItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsClickItem(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
