package com.example.ui.viewmodel

import android.app.Application
import android.content.ContentValues
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.FastPlayerApp
import com.example.model.AppSettings
import com.example.model.PlayerQuickButton
import com.example.model.ScreenOrientationMode
import com.example.model.SubtitleAppearance
import com.example.player.PlaybackProgress
import com.example.player.PlayerPlaybackState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class PlayerViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as FastPlayerApp
    val engine = app.playerEngine
    private val settingsRepo = app.settingsRepository

    val playbackState: StateFlow<PlayerPlaybackState> = engine.state
    val progressState: StateFlow<PlaybackProgress> = engine.progress
    val settingsState: StateFlow<AppSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    fun updateQuickButtonOrder(order: List<PlayerQuickButton>) {
        viewModelScope.launch { settingsRepo.updateQuickButtonOrder(order) }
    }

    fun moveQuickButton(index: Int, delta: Int) {
        val current = settingsState.value.quickButtonOrder.toMutableList()
        val target = index + delta
        if (index !in current.indices || target !in current.indices) return
        val item = current.removeAt(index)
        current.add(target, item)
        updateQuickButtonOrder(current)
    }

    fun updateSubtitleAppearance(appearance: SubtitleAppearance) {
        viewModelScope.launch { settingsRepo.updateSubtitleAppearance(appearance) }
    }

    fun setScreenOrientation(mode: ScreenOrientationMode) {
        viewModelScope.launch { settingsRepo.setScreenOrientation(mode) }
    }

    fun setFastSeeking(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setFastSeeking(enabled) }
    }

    fun setPlayNextAuto(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setPlayNextAutomatically(enabled) }
    }

    fun loadExternalSubtitle(uri: Uri) {
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "External Subtitle"
        engine.loadExternalSubtitle(uri, name)
    }

    suspend fun saveScreenshot(bitmap: Bitmap): Boolean = withContext(Dispatchers.IO) {
        val fileName = "FastPlayer_${System.currentTimeMillis()}.png"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/FastPlayer")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = app.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return@withContext false
                resolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                true
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "FastPlayer"
                )
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, fileName)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                true
            }
        } catch (_: Exception) {
            false
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }
}
