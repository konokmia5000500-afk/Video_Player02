package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Brand Blues (Fast Player)
val FastBlue = Color(0xFF1A73E8)
val FastBlueDeep = Color(0xFF04448C)
val FastBlueLight = Color(0xFF60A5FA)
val FastCyan = Color(0xFF06B6D4)
val NewBadgeRed = Color(0xFFE53935)
val LastPlayedBlue = Color(0xFF1E88E5)
val LastPlayedBlueDark = Color(0xFF64B5F6)

// Light Palette
val LightPrimary = Color(0xFF1565C0)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFD6E4FF)
val LightOnPrimaryContainer = Color(0xFF001B3E)
val LightSecondary = Color(0xFF0288D1)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFCDE5FF)
val LightOnSecondaryContainer = Color(0xFF001E30)
val LightBackground = Color(0xFFF7F9FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF2F7)
val LightOnSurface = Color(0xFF111827)
val LightOnSurfaceVariant = Color(0xFF5A6577)
val LightOutline = Color(0xFFD5DCE6)

// Dark Palette
val DarkPrimary = Color(0xFF60A5FA)
val DarkOnPrimary = Color(0xFF002B5B)
val DarkPrimaryContainer = Color(0xFF0B3C78)
val DarkOnPrimaryContainer = Color(0xFFD6E4FF)
val DarkSecondary = Color(0xFF38BDF8)
val DarkOnSecondary = Color(0xFF00354A)
val DarkSecondaryContainer = Color(0xFF074C6B)
val DarkOnSecondaryContainer = Color(0xFFCDEEFF)
val DarkBackground = Color(0xFF111418)
val DarkSurface = Color(0xFF181C22)
val DarkSurfaceVariant = Color(0xFF232932)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF2E3642)

// Pure Black (AMOLED) Palette
val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF080A0D)
val AmoledSurfaceVariant = Color(0xFF141820)
val AmoledOutline = Color(0xFF222831)

// Ocean Colorful Palette
val OceanPrimary = Color(0xFF0061A4)
val OceanOnPrimary = Color(0xFFFFFFFF)
val OceanPrimaryContainer = Color(0xFFCFE5FF)
val OceanOnPrimaryContainer = Color(0xFF001D36)
val OceanSecondary = Color(0xFF006874)
val OceanSecondaryContainer = Color(0xFF97F0FF)
val OceanTertiary = Color(0xFF0284C7)
val OceanBackground = Color(0xFFECF4FF)
val OceanSurface = Color(0xFFF4F9FF)
val OceanSurfaceVariant = Color(0xFFDFECFF)
val OceanOnSurface = Color(0xFF0B1F3A)
val OceanOnSurfaceVariant = Color(0xFF3E5673)
