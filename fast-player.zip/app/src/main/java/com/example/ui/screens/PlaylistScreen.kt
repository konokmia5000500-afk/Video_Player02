package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.PlaylistEntryModel
import com.example.model.PlaylistModel
import com.example.ui.components.CreatePlaylistDialog
import com.example.ui.components.HighlightedText
import com.example.ui.viewmodel.LibraryUiState
import com.example.util.FormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistScreen(
    uiState: LibraryUiState,
    selectedPlaylistId: Long?,
    playlistEntries: List<PlaylistEntryModel>,
    onSelectPlaylist: (Long?) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onRenamePlaylist: (Long, String) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onRemoveEntry: (Long) -> Unit,
    onPlayEntries: (List<PlaylistEntryModel>, Int, Boolean) -> Unit,
    onSetSearchActive: (Boolean) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<PlaylistModel?>(null) }

    val selectedPlaylist = uiState.playlists.firstOrNull { it.id == selectedPlaylistId }

    BackHandler(enabled = uiState.isSearchActive || selectedPlaylist != null) {
        if (uiState.isSearchActive) {
            onSetSearchActive(false)
        } else {
            onSelectPlaylist(null)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                if (uiState.isSearchActive) {
                    OutlinedTextField(
                        value = uiState.searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = {
                            Text(
                                text = if (selectedPlaylist != null) "Search in ${selectedPlaylist.name}" else "Search playlists...",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(end = 4.dp)
                            .testTag("playlist_search_input")
                    )
                } else {
                    Text(selectedPlaylist?.name ?: "Playlist")
                }
            },
            navigationIcon = {
                if (uiState.isSearchActive) {
                    IconButton(onClick = { onSetSearchActive(false) }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Close search")
                    }
                } else if (selectedPlaylist != null) {
                    IconButton(onClick = { onSelectPlaylist(null) }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                }
            },
            actions = {
                if (uiState.isSearchActive) {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                        }
                    }
                } else {
                    IconButton(
                        onClick = { onSetSearchActive(true) },
                        modifier = Modifier.testTag("playlist_search_button")
                    ) {
                        Icon(Icons.Rounded.Search, contentDescription = stringResource(R.string.action_search))
                    }
                    if (selectedPlaylist == null) {
                        IconButton(
                            onClick = { showCreateDialog = true },
                            modifier = Modifier.testTag("create_playlist_button")
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = "Create playlist")
                        }
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        if (selectedPlaylist == null) {
            val filteredPlaylists = remember(uiState.playlists, uiState.isSearchActive, uiState.searchQuery) {
                if (!uiState.isSearchActive || uiState.searchQuery.isBlank()) {
                    uiState.playlists
                } else {
                    val q = uiState.searchQuery.trim().lowercase()
                    uiState.playlists.filter { it.name.lowercase().contains(q) }
                }
            }

            if (filteredPlaylists.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.PlaylistPlay,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (uiState.isSearchActive) "No matching playlists" else "No playlists yet",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        if (!uiState.isSearchActive) {
                            Button(onClick = { showCreateDialog = true }) {
                                Icon(Icons.Rounded.Add, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Create Playlist")
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(filteredPlaylists, key = { it.id }) { pl ->
                        PlaylistFolderRow(
                            playlist = pl,
                            highlightQuery = if (uiState.isSearchActive) uiState.searchQuery else "",
                            onClick = { onSelectPlaylist(pl.id) },
                            onRename = { renameTarget = pl },
                            onDelete = { onDeletePlaylist(pl.id) }
                        )
                    }
                }
            }
        } else {
            if (uiState.isSearchActive && uiState.searchQuery.isNotBlank()) {
                val direct = uiState.playlistSearchResults.directMatches
                val related = uiState.playlistSearchResults.relatedMatches
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    itemsIndexed(direct, key = { idx, it -> "pd_${it.id}_$idx" }) { _, item ->
                        val entry = playlistEntries.firstOrNull { it.entryId == item.id }
                        if (entry != null) {
                            PlaylistEntryRow(
                                entry = entry,
                                highlightQuery = uiState.searchQuery,
                                onClick = {
                                    val idx = playlistEntries.indexOfFirst { it.entryId == entry.entryId }.coerceAtLeast(0)
                                    onPlayEntries(playlistEntries, idx, false)
                                },
                                onRemove = { onRemoveEntry(entry.entryId) }
                            )
                        }
                    }
                    if (related.isNotEmpty()) {
                        item {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                            Text(
                                text = "Related",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                        itemsIndexed(related, key = { idx, it -> "pr_${it.id}_$idx" }) { _, item ->
                            val entry = playlistEntries.firstOrNull { it.entryId == item.id }
                            if (entry != null) {
                                PlaylistEntryRow(
                                    entry = entry,
                                    highlightQuery = uiState.searchQuery,
                                    onClick = {
                                        val idx = playlistEntries.indexOfFirst { it.entryId == entry.entryId }.coerceAtLeast(0)
                                        onPlayEntries(playlistEntries, idx, false)
                                    },
                                    onRemove = { onRemoveEntry(entry.entryId) }
                                )
                            }
                        }
                    }
                }
            } else if (playlistEntries.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "Add videos or audio from the three-dot menu on any item.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { onPlayEntries(playlistEntries, 0, false) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.PlayArrow, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Play All")
                            }
                            OutlinedButton(
                                onClick = { onPlayEntries(playlistEntries, 0, true) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.Shuffle, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Shuffle")
                            }
                        }
                    }
                    itemsIndexed(playlistEntries, key = { _, e -> e.entryId }) { index, entry ->
                        PlaylistEntryRow(
                            entry = entry,
                            highlightQuery = "",
                            onClick = { onPlayEntries(playlistEntries, index, false) },
                            onRemove = { onRemoveEntry(entry.entryId) }
                        )
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreatePlaylistDialog(
            onDismiss = { showCreateDialog = false },
            onConfirm = {
                onCreatePlaylist(it)
                showCreateDialog = false
            }
        )
    }

    renameTarget?.let { pl ->
        CreatePlaylistDialog(
            initialName = pl.name,
            title = "Rename Playlist",
            onDismiss = { renameTarget = null },
            onConfirm = {
                onRenamePlaylist(pl.id, it)
                renameTarget = null
            }
        )
    }
}

@Composable
private fun PlaylistFolderRow(
    playlist: PlaylistModel,
    highlightQuery: String,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.PlaylistPlay,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            HighlightedText(
                text = playlist.name,
                query = highlightQuery,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1
            )
            Text(
                text = "${playlist.itemCount} ${if (playlist.itemCount == 1) "item" else "items"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Box {
            IconButton(onClick = { menuExpanded = true }) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "Playlist options")
            }
            DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                DropdownMenuItem(
                    text = { Text("Rename") },
                    onClick = {
                        menuExpanded = false
                        onRename()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Delete") },
                    onClick = {
                        menuExpanded = false
                        onDelete()
                    }
                )
            }
        }
    }
}

@Composable
private fun PlaylistEntryRow(
    entry: PlaylistEntryModel,
    highlightQuery: String,
    onClick: () -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (entry.isAudio) Icons.Rounded.MusicNote else Icons.Rounded.VideoFile,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            HighlightedText(
                text = entry.title,
                query = highlightQuery,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1
            )
            Text(
                text = FormatUtils.formatDuration(entry.durationMs),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = onRemove) {
            Icon(
                imageVector = Icons.Rounded.Delete,
                contentDescription = "Remove from playlist",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
