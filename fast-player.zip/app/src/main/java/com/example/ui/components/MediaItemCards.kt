package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.size.Precision
import com.example.data.local.MediaThumbnailRequest
import com.example.model.FieldVisibility
import com.example.model.MediaFolder
import com.example.model.MediaItemModel
import com.example.ui.theme.FastBlue
import com.example.ui.theme.LastPlayedBlue
import com.example.ui.theme.NewBadgeRed
import com.example.util.FormatUtils

@Composable
fun NewBadgePill(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(NewBadgeRed)
            .padding(horizontal = 5.dp, vertical = 1.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "NEW",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold
            ),
            color = Color.White
        )
    }
}

@Composable
fun FolderListRow(
    folder: MediaFolder,
    showNewBadge: Boolean,
    compact: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val nameColor = if (folder.isLastPlayedFolder) LastPlayedBlue else MaterialTheme.colorScheme.onSurface
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = if (compact) 8.dp else 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Icon(
                imageVector = Icons.Rounded.Folder,
                contentDescription = folder.name,
                tint = if (folder.isLastPlayedFolder) LastPlayedBlue else FastBlue.copy(alpha = 0.88f),
                modifier = Modifier.size(if (compact) 44.dp else 48.dp)
            )
            if (showNewBadge && folder.hasNewMedia) {
                NewBadgePill(modifier = Modifier.padding(top = 3.dp))
            }
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = folder.name,
                style = MaterialTheme.typography.titleMedium,
                color = nameColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            val subtitle = buildString {
                if (folder.subfolderCount > 0) {
                    append("${folder.subfolderCount} ${if (folder.subfolderCount == 1) "folder" else "folders"}, ")
                }
                append("${folder.videoCount} ${if (folder.videoCount == 1) "video" else "videos"}")
            }
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
fun FolderGridCard(
    folder: MediaFolder,
    showNewBadge: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val nameColor = if (folder.isLastPlayedFolder) LastPlayedBlue else MaterialTheme.colorScheme.onSurface
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Icon(
                    imageVector = Icons.Rounded.Folder,
                    contentDescription = folder.name,
                    tint = if (folder.isLastPlayedFolder) LastPlayedBlue else FastBlue.copy(alpha = 0.85f),
                    modifier = Modifier.size(56.dp)
                )
                if (showNewBadge && folder.hasNewMedia) {
                    NewBadgePill()
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = folder.name,
                style = MaterialTheme.typography.titleSmall,
                color = nameColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${folder.videoCount} videos",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun VideoListRow(
    item: MediaItemModel,
    fields: FieldVisibility,
    showNewBadge: Boolean,
    compact: Boolean,
    highlightQuery: String = "",
    onClick: () -> Unit,
    onPlayFromStart: () -> Unit,
    onPlayAsAudio: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onShowDetails: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val titleColor = if (item.isLastPlayed) LastPlayedBlue else MaterialTheme.colorScheme.onSurface
    val context = LocalContext.current

    val secondaryMeta = remember(
        item.uriString,
        fields.thumbnail,
        fields.length,
        fields.size,
        fields.resolution,
        fields.extension,
        fields.path
    ) {
        buildList {
            if (!fields.thumbnail && fields.length && item.durationMs > 0L) {
                add(FormatUtils.formatDuration(item.durationMs))
            }
            if (fields.size && item.sizeBytes > 0L) add(FormatUtils.formatFileSize(item.sizeBytes))
            if (fields.resolution && item.resolutionLabel.isNotEmpty()) add(item.resolutionLabel)
            if (fields.extension && item.extension.isNotEmpty()) add(item.extension)
            if (fields.path) add(item.folderName)
        }.joinToString(" • ")
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 14.dp, end = 4.dp, top = if (compact) 6.dp else 8.dp, bottom = if (compact) 6.dp else 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (fields.thumbnail) {
            Box(
                modifier = Modifier
                    .width(if (compact) 102.dp else 116.dp)
                    .height(if (compact) 60.dp else 68.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                AsyncImage(
                    model = remember(item.uriString) {
                        ImageRequest.Builder(context)
                            .data(MediaThumbnailRequest.from(item))
                            .size(256, 160)
                            .precision(Precision.INEXACT)
                            .build()
                    },
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                if (showNewBadge && item.isNew) {
                    NewBadgePill(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(4.dp)
                    )
                }
                if (fields.length && item.durationMs > 0L) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.Black.copy(alpha = 0.74f))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = FormatUtils.formatDuration(item.durationMs),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }
                if (item.lastPositionMs > 1000L && item.durationMs > 0L) {
                    val fraction = (item.lastPositionMs.toFloat() / item.durationMs.toFloat()).coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { fraction },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(2.dp),
                        color = FastBlue,
                        trackColor = Color.Black.copy(alpha = 0.35f)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
        } else {
            Icon(
                imageVector = Icons.Rounded.VideoFile,
                contentDescription = item.title,
                tint = if (item.isLastPlayed) LastPlayedBlue else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
        }

        Column(modifier = Modifier.weight(1f)) {
            HighlightedText(
                text = item.title,
                query = highlightQuery,
                style = MaterialTheme.typography.titleSmall,
                defaultColor = titleColor,
                maxLines = 2
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (fields.date && item.dateAddedSec > 0L) {
                    SmallMetaChip(FormatUtils.formatDateChip(item.dateAddedSec))
                }
                if (secondaryMeta.isNotEmpty()) {
                    Text(
                        text = secondaryMeta,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                }
            }
        }

        Box {
            IconButton(onClick = { menuExpanded = true }) {
                Icon(
                    imageVector = Icons.Rounded.MoreVert,
                    contentDescription = "More options",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (menuExpanded) {
                MediaItemDropdownMenu(
                    expanded = true,
                    onDismiss = { menuExpanded = false },
                    isAudio = false,
                    onPlay = onClick,
                    onPlayFromStart = onPlayFromStart,
                    onPlayAsAudio = onPlayAsAudio,
                    onAddToPlaylist = onAddToPlaylist,
                    onDetails = onShowDetails
                )
            }
        }
    }
}

@Composable
fun VideoGridCard(
    item: MediaItemModel,
    fields: FieldVisibility,
    showNewBadge: Boolean,
    onClick: () -> Unit,
    onPlayFromStart: () -> Unit,
    onPlayAsAudio: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onShowDetails: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val titleColor = if (item.isLastPlayed) LastPlayedBlue else MaterialTheme.colorScheme.onSurface
    val context = LocalContext.current

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Column {
            if (fields.thumbnail) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 10f)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    AsyncImage(
                        model = remember(item.uriString) {
                            ImageRequest.Builder(context)
                                .data(MediaThumbnailRequest.from(item))
                                .size(256, 160)
                                .precision(Precision.INEXACT)
                                .build()
                        },
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (showNewBadge && item.isNew) {
                        NewBadgePill(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(6.dp)
                        )
                    }
                    if (fields.length && item.durationMs > 0L) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(6.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Black.copy(alpha = 0.74f))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = FormatUtils.formatDuration(item.durationMs),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }
                    if (item.lastPositionMs > 1000L && item.durationMs > 0L) {
                        val fraction = (item.lastPositionMs.toFloat() / item.durationMs.toFloat()).coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { fraction },
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .height(2.dp),
                            color = FastBlue,
                            trackColor = Color.Black.copy(alpha = 0.35f)
                        )
                    }
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 10.dp, end = 2.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.labelLarge,
                        color = titleColor,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (fields.date || fields.size) {
                        Spacer(modifier = Modifier.height(3.dp))
                        val meta = listOfNotNull(
                            if (fields.date) FormatUtils.formatDateChip(item.dateAddedSec) else null,
                            if (fields.size) FormatUtils.formatFileSize(item.sizeBytes) else null
                        ).joinToString(" • ")
                        Text(
                            text = meta,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
                Box {
                    IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Rounded.MoreVert,
                            contentDescription = "More options",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    if (menuExpanded) {
                        MediaItemDropdownMenu(
                            expanded = true,
                            onDismiss = { menuExpanded = false },
                            isAudio = false,
                            onPlay = onClick,
                            onPlayFromStart = onPlayFromStart,
                            onPlayAsAudio = onPlayAsAudio,
                            onAddToPlaylist = onAddToPlaylist,
                            onDetails = onShowDetails
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AudioListRow(
    item: MediaItemModel,
    highlightQuery: String = "",
    onClick: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onShowDetails: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val titleColor = if (item.isLastPlayed) LastPlayedBlue else MaterialTheme.colorScheme.onSurface
    val context = LocalContext.current

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.MusicNote,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            AsyncImage(
                model = remember(item.uriString) {
                    ImageRequest.Builder(context)
                        .data(MediaThumbnailRequest.from(item))
                        .size(180, 180)
                        .precision(Precision.INEXACT)
                        .build()
                },
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            HighlightedText(
                text = item.title,
                query = highlightQuery,
                style = MaterialTheme.typography.titleSmall,
                defaultColor = titleColor,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            val sub = listOfNotNull(
                item.artist ?: item.folderName,
                FormatUtils.formatDuration(item.durationMs)
            ).joinToString(" • ")
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Box {
            IconButton(onClick = { menuExpanded = true }) {
                Icon(
                    imageVector = Icons.Rounded.MoreVert,
                    contentDescription = "More options",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (menuExpanded) {
                MediaItemDropdownMenu(
                    expanded = true,
                    onDismiss = { menuExpanded = false },
                    isAudio = true,
                    onPlay = onClick,
                    onPlayFromStart = onClick,
                    onPlayAsAudio = onClick,
                    onAddToPlaylist = onAddToPlaylist,
                    onDetails = onShowDetails
                )
            }
        }
    }
}

@Composable
private fun SmallMetaChip(text: String) {
    if (text.isBlank()) return
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(5.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
    }
}

@Composable
private fun MediaItemDropdownMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    isAudio: Boolean,
    onPlay: () -> Unit,
    onPlayFromStart: () -> Unit,
    onPlayAsAudio: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onDetails: () -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("Play") },
            leadingIcon = { Icon(Icons.Rounded.PlayArrow, null) },
            onClick = {
                onDismiss()
                onPlay()
            }
        )
        if (!isAudio) {
            DropdownMenuItem(
                text = { Text("Play from start") },
                onClick = {
                    onDismiss()
                    onPlayFromStart()
                }
            )
            DropdownMenuItem(
                text = { Text("Play as Audio") },
                onClick = {
                    onDismiss()
                    onPlayAsAudio()
                }
            )
        }
        DropdownMenuItem(
            text = { Text("Add to Playlist") },
            onClick = {
                onDismiss()
                onAddToPlaylist()
            }
        )
        DropdownMenuItem(
            text = { Text("Details") },
            onClick = {
                onDismiss()
                onDetails()
            }
        )
    }
}
