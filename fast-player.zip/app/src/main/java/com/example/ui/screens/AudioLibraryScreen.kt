package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.MediaItemModel
import com.example.model.SortField
import com.example.model.SortOrder
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.AudioListRow
import com.example.ui.components.MediaDetailsDialog
import com.example.ui.viewmodel.LibraryUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioLibraryScreen(
    uiState: LibraryUiState,
    onRequestPermissions: () -> Unit,
    onOpenExternalPicker: () -> Unit,
    onSetSearchActive: (Boolean) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onUpdateSort: (SortField, SortOrder) -> Unit,
    onPlayAudio: (MediaItemModel, List<MediaItemModel>) -> Unit,
    onAddToPlaylist: (Long, MediaItemModel) -> Unit,
    onCreatePlaylistAndAdd: (String, MediaItemModel) -> Unit,
    modifier: Modifier = Modifier
) {
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var detailsItem by remember { mutableStateOf<MediaItemModel?>(null) }
    var playlistTargetItem by remember { mutableStateOf<MediaItemModel?>(null) }

    BackHandler(enabled = uiState.isSearchActive) {
        onSetSearchActive(false)
    }

    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                AnimatedContent(
                    targetState = uiState.isSearchActive,
                    transitionSpec = { fadeIn(tween(150)) togetherWith fadeOut(tween(110)) },
                    label = "audio_topbar_title"
                ) { searching ->
                    if (searching) {
                        OutlinedTextField(
                            value = uiState.searchQuery,
                            onValueChange = onSearchQueryChange,
                            placeholder = { Text("Search audio...", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(end = 4.dp)
                                .testTag("audio_search_input")
                        )
                    } else {
                        Text("Audio")
                    }
                }
            },
            navigationIcon = {
                if (uiState.isSearchActive) {
                    IconButton(onClick = { onSetSearchActive(false) }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Close search")
                    }
                }
            },
            actions = {
                if (uiState.isSearchActive) {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                        }
                    }
                } else {
                    IconButton(
                        onClick = { onSetSearchActive(true) },
                        modifier = Modifier.testTag("audio_search_button")
                    ) {
                        Icon(Icons.Rounded.Search, contentDescription = stringResource(R.string.action_search))
                    }
                    Box {
                        IconButton(onClick = { sortMenuExpanded = true }) {
                            Icon(Icons.AutoMirrored.Rounded.Sort, contentDescription = "Sort audio")
                        }
                        if (sortMenuExpanded) {
                            DropdownMenu(
                                expanded = true,
                                onDismissRequest = { sortMenuExpanded = false }
                            ) {
                                listOf(SortField.TITLE, SortField.DATE, SortField.LENGTH, SortField.SIZE).forEach { field ->
                                    val selected = uiState.settings.audioSortField == field
                                    DropdownMenuItem(
                                        text = { Text("Sort by ${field.label}") },
                                        trailingIcon = if (selected) {
                                            { Icon(Icons.Rounded.Check, null) }
                                        } else null,
                                        onClick = {
                                            val nextOrder = if (selected) {
                                                if (uiState.settings.audioSortOrder == SortOrder.ASCENDING) SortOrder.DESCENDING else SortOrder.ASCENDING
                                            } else {
                                                uiState.settings.audioSortOrder
                                            }
                                            onUpdateSort(field, nextOrder)
                                            sortMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        Crossfade(
            targetState = uiState.hasMediaPermission to uiState.isSearchActive,
            animationSpec = tween(120),
            label = "audio_content_nav",
            modifier = Modifier.weight(1f)
        ) { (hasPerm, searching) ->
            if (!hasPerm) {
                MediaPermissionEmptyCard(
                    onGrant = onRequestPermissions,
                    onOpenFile = onOpenExternalPicker
                )
            } else if (searching) {
            val direct = uiState.audioSearchResults.directMatches
            val related = uiState.audioSearchResults.relatedMatches
            if (uiState.searchQuery.isBlank()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "Type any part of a song or audio name",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (direct.isEmpty() && related.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "No matching audio found",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(direct, key = { "ad_${it.uriString}" }) { item ->
                        AudioListRow(
                            item = item,
                            highlightQuery = uiState.searchQuery,
                            onClick = { onPlayAudio(item, direct) },
                            onAddToPlaylist = { playlistTargetItem = item },
                            onShowDetails = { detailsItem = item }
                        )
                    }
                    if (related.isNotEmpty()) {
                        item(key = "audio_related_header") {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                            Text(
                                text = "Related",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                        items(related, key = { "ar_${it.uriString}" }) { item ->
                            AudioListRow(
                                item = item,
                                highlightQuery = uiState.searchQuery,
                                onClick = { onPlayAudio(item, related) },
                                onAddToPlaylist = { playlistTargetItem = item },
                                onShowDetails = { detailsItem = item }
                            )
                        }
                    }
                }
            }
        } else if (uiState.audioItems.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Rounded.MusicNote,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No audio files found", style = MaterialTheme.typography.titleMedium)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                items(uiState.audioItems, key = { it.uriString }) { item ->
                    AudioListRow(
                        item = item,
                        onClick = { onPlayAudio(item, uiState.audioItems) },
                        onAddToPlaylist = { playlistTargetItem = item },
                        onShowDetails = { detailsItem = item }
                    )
                }
            }
        }
        }
    }

    detailsItem?.let { item ->
        MediaDetailsDialog(item = item, onDismiss = { detailsItem = null })
    }

    playlistTargetItem?.let { item ->
        AddToPlaylistDialog(
            playlists = uiState.playlists,
            mediaTitle = item.title,
            onDismiss = { playlistTargetItem = null },
            onSelectPlaylist = { pl ->
                onAddToPlaylist(pl.id, item)
                playlistTargetItem = null
            },
            onCreateAndAdd = { name ->
                onCreatePlaylistAndAdd(name, item)
                playlistTargetItem = null
            }
        )
    }
}
