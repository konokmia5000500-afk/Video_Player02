package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AccountTree
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.LayoutMode
import com.example.model.MediaItemModel
import com.example.model.ViewMode
import com.example.model.ViewOptions
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.FolderGridCard
import com.example.ui.components.FolderListRow
import com.example.ui.components.MediaDetailsDialog
import com.example.ui.components.VideoGridCard
import com.example.ui.components.VideoListRow
import com.example.ui.components.ViewOptionsDialog
import com.example.ui.viewmodel.LibraryUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoLibraryScreen(
    uiState: LibraryUiState,
    onRequestPermissions: () -> Unit,
    onOpenExternalPicker: () -> Unit,
    onOpenFolder: (String) -> Unit,
    onNavigateFolderUp: () -> Boolean,
    onCycleViewMode: () -> Unit,
    onUpdateViewOptions: (ViewOptions) -> Unit,
    onSetSearchActive: (Boolean) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onPlayVideo: (MediaItemModel, List<MediaItemModel>, Boolean) -> Unit,
    onPlayAsAudio: (MediaItemModel, List<MediaItemModel>) -> Unit,
    onAddToPlaylist: (Long, MediaItemModel) -> Unit,
    onCreatePlaylistAndAdd: (String, MediaItemModel) -> Unit,
    modifier: Modifier = Modifier
) {
    var showViewDialog by remember { mutableStateOf(false) }
    var detailsItem by remember { mutableStateOf<MediaItemModel?>(null) }
    var playlistTargetItem by remember { mutableStateOf<MediaItemModel?>(null) }

    val viewOptions = uiState.settings.viewOptions

    BackHandler(enabled = uiState.isSearchActive || uiState.currentFolderPath != null) {
        if (uiState.isSearchActive) {
            onSetSearchActive(false)
        } else {
            onNavigateFolderUp()
        }
    }

    val topTitle = when {
        uiState.currentFolderName != null -> uiState.currentFolderName
        viewOptions.viewMode == ViewMode.FOLDERS_TREE -> "Folders"
        viewOptions.viewMode == ViewMode.ALL_FOLDERS -> "All Folders"
        else -> "Videos"
    }

    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                AnimatedContent(
                    targetState = uiState.isSearchActive,
                    transitionSpec = {
                        fadeIn(tween(150)) togetherWith fadeOut(tween(110))
                    },
                    label = "video_topbar_title"
                ) { searching ->
                    if (searching) {
                        OutlinedTextField(
                            value = uiState.searchQuery,
                            onValueChange = onSearchQueryChange,
                            placeholder = {
                                Text(
                                    text = if (uiState.currentFolderName != null) {
                                        "Search in ${uiState.currentFolderName}"
                                    } else {
                                        "Search videos..."
                                    },
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(end = 4.dp)
                                .testTag("video_search_input")
                        )
                    } else {
                        Text(
                            text = topTitle,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            },
            navigationIcon = {
                if (uiState.isSearchActive) {
                    IconButton(onClick = { onSetSearchActive(false) }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Close search")
                    }
                } else if (uiState.currentFolderPath != null) {
                    IconButton(onClick = { onNavigateFolderUp() }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                }
            },
            actions = {
                if (uiState.isSearchActive) {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                        }
                    }
                } else {
                    IconButton(
                        onClick = onCycleViewMode,
                        modifier = Modifier.testTag("switch_view_mode_button")
                    ) {
                        val icon = when (viewOptions.viewMode) {
                            ViewMode.FOLDERS_TREE -> Icons.Rounded.AccountTree
                            ViewMode.ALL_FOLDERS -> Icons.Rounded.Folder
                            ViewMode.FILES -> Icons.Rounded.VideoFile
                        }
                        Icon(icon, contentDescription = stringResource(R.string.action_switch_view))
                    }
                    IconButton(
                        onClick = { onSetSearchActive(true) },
                        modifier = Modifier.testTag("video_search_button")
                    ) {
                        Icon(Icons.Rounded.Search, contentDescription = stringResource(R.string.action_search))
                    }
                    IconButton(
                        onClick = { showViewDialog = true },
                        modifier = Modifier.testTag("video_view_options_button")
                    ) {
                        Icon(Icons.Rounded.Tune, contentDescription = stringResource(R.string.action_view_options))
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        Crossfade(
            targetState = Triple(uiState.hasMediaPermission, uiState.isSearchActive, uiState.currentFolderPath to viewOptions.viewMode),
            animationSpec = tween(120),
            label = "video_content_nav",
            modifier = Modifier.weight(1f)
        ) { (hasPerm, searching, _) ->
            if (!hasPerm) {
                MediaPermissionEmptyCard(
                    onGrant = onRequestPermissions,
                    onOpenFile = onOpenExternalPicker
                )
            } else if (searching) {
            val direct = uiState.videoSearchResults.directMatches
            val related = uiState.videoSearchResults.relatedMatches
            if (uiState.searchQuery.isBlank()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (uiState.currentFolderName != null) {
                            "Type to search inside ${uiState.currentFolderName}"
                        } else {
                            "Type any part of a video name"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (direct.isEmpty() && related.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "No matching videos found",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(direct, key = { "direct_${it.uriString}" }) { item ->
                        VideoListRow(
                            item = item,
                            fields = viewOptions.fields,
                            showNewBadge = viewOptions.showNewBadge,
                            compact = viewOptions.compactRows,
                            highlightQuery = uiState.searchQuery,
                            onClick = { onPlayVideo(item, direct, false) },
                            onPlayFromStart = { onPlayVideo(item, direct, true) },
                            onPlayAsAudio = { onPlayAsAudio(item, direct) },
                            onAddToPlaylist = { playlistTargetItem = item },
                            onShowDetails = { detailsItem = item }
                        )
                    }
                    if (related.isNotEmpty()) {
                        item(key = "related_header") {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                            Text(
                                text = "Related",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                        items(related, key = { "related_${it.uriString}" }) { item ->
                            VideoListRow(
                                item = item,
                                fields = viewOptions.fields,
                                showNewBadge = viewOptions.showNewBadge,
                                compact = viewOptions.compactRows,
                                highlightQuery = uiState.searchQuery,
                                onClick = { onPlayVideo(item, related, false) },
                                onPlayFromStart = { onPlayVideo(item, related, true) },
                                onPlayAsAudio = { onPlayAsAudio(item, related) },
                                onAddToPlaylist = { playlistTargetItem = item },
                                onShowDetails = { detailsItem = item }
                            )
                        }
                    }
                }
            }
        } else if (!uiState.isLoading && uiState.folders.isEmpty() && uiState.visibleVideos.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VideoLibrary,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No videos found",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Videos stored on your device will appear here automatically, or open one directly.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedButton(onClick = onOpenExternalPicker) {
                        Icon(Icons.Rounded.FolderOpen, null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.permission_open_file))
                    }
                }
            }
        } else {
            if (viewOptions.layoutMode == LayoutMode.GRID) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 156.dp),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(uiState.folders, key = { "fg_${it.path}" }) { folder ->
                        FolderGridCard(
                            folder = folder,
                            showNewBadge = viewOptions.showNewBadge,
                            onClick = { onOpenFolder(folder.path) }
                        )
                    }
                    if (uiState.folders.isNotEmpty() && uiState.visibleVideos.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }
                    items(uiState.visibleVideos, key = { "vg_${it.uriString}" }) { item ->
                        VideoGridCard(
                            item = item,
                            fields = viewOptions.fields,
                            showNewBadge = viewOptions.showNewBadge,
                            onClick = { onPlayVideo(item, uiState.visibleVideos, false) },
                            onPlayFromStart = { onPlayVideo(item, uiState.visibleVideos, true) },
                            onPlayAsAudio = { onPlayAsAudio(item, uiState.visibleVideos) },
                            onAddToPlaylist = { playlistTargetItem = item },
                            onShowDetails = { detailsItem = item }
                        )
                    }
                }
            } else {
                val listState = rememberLazyListState()
                LaunchedEffect(uiState.currentFolderPath, uiState.visibleVideos.size) {
                    if (uiState.settings.scrollToLastMedia && uiState.visibleVideos.isNotEmpty()) {
                        val lastIdx = uiState.visibleVideos.indexOfFirst { it.isLastPlayed }
                        if (lastIdx > 0) {
                            listState.scrollToItem(uiState.folders.size + lastIdx)
                        }
                    }
                }

                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(bottom = 96.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(uiState.folders, key = { "fl_${it.path}" }) { folder ->
                        FolderListRow(
                            folder = folder,
                            showNewBadge = viewOptions.showNewBadge,
                            compact = viewOptions.compactRows,
                            onClick = { onOpenFolder(folder.path) }
                        )
                    }
                    if (uiState.folders.isNotEmpty() && uiState.visibleVideos.isNotEmpty()) {
                        item(key = "folder_video_divider") {
                            HorizontalDivider(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                            )
                        }
                    }
                    items(uiState.visibleVideos, key = { "vl_${it.uriString}" }) { item ->
                        VideoListRow(
                            item = item,
                            fields = viewOptions.fields,
                            showNewBadge = viewOptions.showNewBadge,
                            compact = viewOptions.compactRows,
                            onClick = { onPlayVideo(item, uiState.visibleVideos, false) },
                            onPlayFromStart = { onPlayVideo(item, uiState.visibleVideos, true) },
                            onPlayAsAudio = { onPlayAsAudio(item, uiState.visibleVideos) },
                            onAddToPlaylist = { playlistTargetItem = item },
                            onShowDetails = { detailsItem = item }
                        )
                    }
                }
            }
        }
        }
    }

    if (showViewDialog) {
        ViewOptionsDialog(
            initialOptions = viewOptions,
            onDismiss = { showViewDialog = false },
            onApply = {
                showViewDialog = false
                onUpdateViewOptions(it)
            }
        )
    }

    detailsItem?.let { item ->
        MediaDetailsDialog(item = item, onDismiss = { detailsItem = null })
    }

    playlistTargetItem?.let { item ->
        AddToPlaylistDialog(
            playlists = uiState.playlists,
            mediaTitle = item.title,
            onDismiss = { playlistTargetItem = null },
            onSelectPlaylist = { pl ->
                onAddToPlaylist(pl.id, item)
                playlistTargetItem = null
            },
            onCreateAndAdd = { name ->
                onCreatePlaylistAndAdd(name, item)
                playlistTargetItem = null
            }
        )
    }
}

@Composable
fun MediaPermissionEmptyCard(
    onGrant: () -> Unit,
    onOpenFile: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            tonalElevation = 4.dp,
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Rounded.FolderOpen,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = stringResource(R.string.permission_title),
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.permission_description),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onGrant,
                        modifier = Modifier.testTag("grant_media_permission_button")
                    ) {
                        Text(stringResource(R.string.permission_grant))
                    }
                    OutlinedButton(onClick = onOpenFile) {
                        Text(stringResource(R.string.permission_open_file))
                    }
                }
            }
        }
    }
}
