package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AppSettings
import com.example.model.PlayerQuickButton
import com.example.model.ScreenOrientationMode
import com.example.model.SubtitleAppearance
import com.example.model.TrackInfo
import com.example.player.PlayerEngine
import com.example.player.PlayerPlaybackState
import com.example.ui.theme.FastBlue
import com.example.util.FormatUtils

enum class PlayerFloatingDialog {
    NONE, EQUALIZER, AUDIO_EFFECT, SPEED, SLEEP_TIMER, AB_REPEAT, CUSTOMISE
}

enum class PlayerRightPanel {
    NONE, AUDIO_TRACK, SUBTITLE, SETTINGS
}

@Composable
fun PlayerFloatingWindowHost(
    dialog: PlayerFloatingDialog,
    playbackState: PlayerPlaybackState,
    settings: AppSettings,
    engine: PlayerEngine,
    onMoveButton: (Int, Int) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (dialog == PlayerFloatingDialog.NONE) return

    Box(
        modifier = modifier
            .fillMaxSize()
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color(0xCC12161E),
            modifier = Modifier
                .widthIn(min = 280.dp, max = 360.dp)
                .heightIn(max = 390.dp)
                .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(18.dp))
                .clickable(enabled = false) {}
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                val title = when (dialog) {
                    PlayerFloatingDialog.EQUALIZER -> "Equalizer"
                    PlayerFloatingDialog.AUDIO_EFFECT -> "Audio Effect"
                    PlayerFloatingDialog.SPEED -> "Playback Speed"
                    PlayerFloatingDialog.SLEEP_TIMER -> "Sleep Timer"
                    PlayerFloatingDialog.AB_REPEAT -> "A-B Repeat"
                    PlayerFloatingDialog.CUSTOMISE -> "Customise Items"
                    PlayerFloatingDialog.NONE -> ""
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (dialog == PlayerFloatingDialog.EQUALIZER) {
                            Switch(
                                checked = playbackState.eqEnabled,
                                onCheckedChange = engine::setEqualizerEnabled,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = FastBlue
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 8.dp),
                    color = Color.White.copy(alpha = 0.14f)
                )

                when (dialog) {
                    PlayerFloatingDialog.EQUALIZER -> EqualizerFloatingContent(playbackState, engine)
                    PlayerFloatingDialog.AUDIO_EFFECT -> AudioEffectFloatingContent(playbackState, engine)
                    PlayerFloatingDialog.SPEED -> SpeedFloatingContent(playbackState, engine)
                    PlayerFloatingDialog.SLEEP_TIMER -> SleepTimerFloatingContent(playbackState, engine)
                    PlayerFloatingDialog.AB_REPEAT -> AbRepeatFloatingContent(playbackState, engine)
                    PlayerFloatingDialog.CUSTOMISE -> CustomiseItemsFloatingContent(settings.quickButtonOrder, onMoveButton)
                    PlayerFloatingDialog.NONE -> Unit
                }
            }
        }
    }
}

@Composable
private fun EqualizerFloatingContent(
    state: PlayerPlaybackState,
    engine: PlayerEngine
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            state.eqPresets.forEachIndexed { idx, name ->
                val selected = state.eqSelectedPreset == idx
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) FastBlue else Color.White.copy(alpha = 0.12f))
                        .clickable { engine.selectEqualizerPreset(idx) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = name,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 240.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(state.eqBands, key = { it.index }) { band ->
                val db = band.levelMb / 100f
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = band.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.width(56.dp)
                    )
                    Slider(
                        value = band.levelMb.toFloat(),
                        onValueChange = { engine.updateEqualizerBand(band.index, it.toInt()) },
                        valueRange = state.eqMinMb.toFloat()..state.eqMaxMb.toFloat(),
                        enabled = state.eqEnabled,
                        colors = SliderDefaults.colors(
                            thumbColor = FastBlue,
                            activeTrackColor = FastBlue,
                            inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = String.format("%+.1f dB", db),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.width(58.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AudioEffectFloatingContent(
    state: PlayerPlaybackState,
    engine: PlayerEngine
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Bass Boost: ${state.bassBoostStrength / 10}%",
            style = MaterialTheme.typography.labelLarge,
            color = Color.White
        )
        Slider(
            value = state.bassBoostStrength.toFloat(),
            onValueChange = { engine.updateAudioEffects(it.toInt(), state.loudnessGainMb) },
            valueRange = 0f..1000f,
            colors = SliderDefaults.colors(thumbColor = FastBlue, activeTrackColor = FastBlue)
        )

        Text(
            text = "Volume Boost / Preamp: +${state.loudnessGainMb / 100} dB",
            style = MaterialTheme.typography.labelLarge,
            color = Color.White
        )
        Slider(
            value = state.loudnessGainMb.toFloat(),
            onValueChange = { engine.updateAudioEffects(state.bassBoostStrength, it.toInt()) },
            valueRange = 0f..1500f,
            colors = SliderDefaults.colors(thumbColor = FastBlue, activeTrackColor = FastBlue)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SpeedFloatingContent(
    state: PlayerPlaybackState,
    engine: PlayerEngine
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Current: ${FormatUtils.formatSpeed(state.playbackSpeed)}",
            style = MaterialTheme.typography.titleMedium,
            color = FastBlue,
            fontWeight = FontWeight.Bold
        )
        Slider(
            value = state.playbackSpeed,
            onValueChange = { engine.setPlaybackSpeed((it * 20).toInt() / 20f) },
            valueRange = 0.25f..4.0f,
            colors = SliderDefaults.colors(thumbColor = FastBlue, activeTrackColor = FastBlue)
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f).forEach { spd ->
                val selected = kotlin.math.abs(state.playbackSpeed - spd) < 0.04f
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) FastBlue else Color.White.copy(alpha = 0.14f))
                        .clickable { engine.setPlaybackSpeed(spd) }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text(FormatUtils.formatSpeed(spd), color = Color.White, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SleepTimerFloatingContent(
    state: PlayerPlaybackState,
    engine: PlayerEngine
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        val rem = state.sleepTimerRemainingSec
        Text(
            text = if (rem != null) "Stopping in ${rem / 60}m ${rem % 60}s" else "Timer is off",
            style = MaterialTheme.typography.bodyMedium,
            color = if (rem != null) FastBlue else Color.White.copy(alpha = 0.8f)
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(null to "Off", 10 to "10 min", 15 to "15 min", 30 to "30 min", 45 to "45 min", 60 to "60 min").forEach { (mins, label) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.15f))
                        .clickable { engine.setSleepTimerMinutes(mins) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(label, color = Color.White, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun AbRepeatFloatingContent(
    state: PlayerPlaybackState,
    engine: PlayerEngine
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Point A: ${state.abPointAMs?.let { FormatUtils.formatDuration(it) } ?: "Not set"}",
            color = Color.White,
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            text = "Point B: ${state.abPointBMs?.let { FormatUtils.formatDuration(it) } ?: "Not set"}",
            color = Color.White,
            style = MaterialTheme.typography.bodyMedium
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { engine.setAbPointA() },
                colors = ButtonDefaults.buttonColors(containerColor = FastBlue),
                modifier = Modifier.weight(1f)
            ) { Text("Set A") }
            Button(
                onClick = { engine.setAbPointB() },
                enabled = state.abPointAMs != null,
                colors = ButtonDefaults.buttonColors(containerColor = FastBlue),
                modifier = Modifier.weight(1f)
            ) { Text("Set B") }
            OutlinedButton(
                onClick = { engine.clearAbRepeat() },
                modifier = Modifier.weight(1f)
            ) { Text("Clear", color = Color.White) }
        }
    }
}

@Composable
private fun CustomiseItemsFloatingContent(
    order: List<PlayerQuickButton>,
    onMoveButton: (Int, Int) -> Unit
) {
    Column {
        Text(
            text = "Move items up so they appear first in the collapsed row.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = 0.75f)
        )
        Spacer(modifier = Modifier.height(8.dp))
        LazyColumn(modifier = Modifier.heightIn(max = 260.dp)) {
            itemsIndexed(order, key = { _, item -> item.id }) { index, btn ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${index + 1}. ${btn.label}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { onMoveButton(index, -1) },
                        enabled = index > 0,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Rounded.ArrowUpward, "Move up", tint = Color.White)
                    }
                    IconButton(
                        onClick = { onMoveButton(index, 1) },
                        enabled = index < order.lastIndex,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Rounded.ArrowDownward, "Move down", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerRightSidePanelHost(
    panel: PlayerRightPanel,
    playbackState: PlayerPlaybackState,
    settings: AppSettings,
    engine: PlayerEngine,
    onPickExternalSubtitle: () -> Unit,
    onUpdateSubtitleAppearance: (SubtitleAppearance) -> Unit,
    onSetOrientation: (ScreenOrientationMode) -> Unit,
    onSetFastSeeking: (Boolean) -> Unit,
    onSetPlayNextAuto: (Boolean) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        if (panel != PlayerRightPanel.NONE) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(onClick = onDismiss)
            )
        }
        AnimatedVisibility(
            visible = panel != PlayerRightPanel.NONE,
            enter = slideInHorizontally { it },
            exit = slideOutHorizontally { it },
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .widthIn(min = 260.dp, max = 320.dp)
                    .background(Color(0x9910141C))
                    .padding(horizontal = 16.dp, vertical = 18.dp)
                    .clickable(enabled = false) {}
                    .verticalScroll(rememberScrollState())
            ) {
                val title = when (panel) {
                    PlayerRightPanel.AUDIO_TRACK -> "Audio Track"
                    PlayerRightPanel.SUBTITLE -> "Subtitle"
                    PlayerRightPanel.SETTINGS -> "Player Settings"
                    PlayerRightPanel.NONE -> ""
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, "Close", tint = Color.White)
                    }
                }
                HorizontalDivider(color = Color.White.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                when (panel) {
                    PlayerRightPanel.AUDIO_TRACK -> {
                        if (playbackState.audioTracks.isEmpty()) {
                            Text("Default audio track", color = Color.White.copy(alpha = 0.8f))
                        } else {
                            playbackState.audioTracks.forEach { track ->
                                TrackRow(track = track, onClick = { engine.selectAudioTrack(track) })
                            }
                        }
                    }

                    PlayerRightPanel.SUBTITLE -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Enable subtitles", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = playbackState.subtitlesEnabled,
                                onCheckedChange = engine::setSubtitlesEnabled,
                                colors = SwitchDefaults.colors(checkedTrackColor = FastBlue)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(FastBlue.copy(alpha = 0.35f))
                                .clickable(onClick = onPickExternalSubtitle)
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.FolderOpen, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = playbackState.externalSubtitleName ?: "Load external subtitle (.srt/.vtt)",
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        if (playbackState.subtitleTracks.isEmpty()) {
                            Text(
                                "No embedded subtitle tracks",
                                color = Color.White.copy(alpha = 0.7f),
                                style = MaterialTheme.typography.bodySmall
                            )
                        } else {
                            playbackState.subtitleTracks.forEach { track ->
                                TrackRow(track = track, onClick = { engine.selectSubtitleTrack(track) })
                            }
                        }
                        HorizontalDivider(
                            color = Color.White.copy(alpha = 0.18f),
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                        val sub = settings.subtitleAppearance
                        Text("Subtitle Size: ${sub.fontSizeSp.toInt()}sp", color = Color.White, style = MaterialTheme.typography.labelMedium)
                        Slider(
                            value = sub.fontSizeSp,
                            onValueChange = { onUpdateSubtitleAppearance(sub.copy(fontSizeSp = it)) },
                            valueRange = 12f..32f,
                            colors = SliderDefaults.colors(thumbColor = FastBlue, activeTrackColor = FastBlue)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Dark backdrop", color = Color.White, style = MaterialTheme.typography.bodySmall)
                            Switch(
                                checked = sub.backgroundDim,
                                onCheckedChange = { onUpdateSubtitleAppearance(sub.copy(backgroundDim = it)) },
                                colors = SwitchDefaults.colors(checkedTrackColor = FastBlue)
                            )
                        }
                    }

                    PlayerRightPanel.SETTINGS -> {
                        PanelSwitchRow("Loop current item", playbackState.loopOne) { engine.toggleLoop() }
                        PanelSwitchRow("Shuffle queue", playbackState.isShuffle) { engine.toggleShuffle() }
                        PanelSwitchRow("Fast seeking", settings.fastSeeking, onSetFastSeeking)
                        PanelSwitchRow("Play next automatically", settings.playNextAutomatically, onSetPlayNextAuto)
                        HorizontalDivider(
                            color = Color.White.copy(alpha = 0.18f),
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                        Text("Orientation", color = Color.White, style = MaterialTheme.typography.labelLarge)
                        Spacer(modifier = Modifier.height(6.dp))
                        ScreenOrientationMode.entries.forEach { mode ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSetOrientation(mode) }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = settings.screenOrientationMode == mode,
                                    onClick = { onSetOrientation(mode) },
                                    colors = RadioButtonDefaults.colors(selectedColor = FastBlue, unselectedColor = Color.White)
                                )
                                Text(mode.label, color = Color.White, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    PlayerRightPanel.NONE -> Unit
                }
            }
        }
    }
}

@Composable
private fun TrackRow(track: TrackInfo, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (track.isSelected) FastBlue.copy(alpha = 0.3f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Subtitles, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(track.label, color = Color.White, style = MaterialTheme.typography.bodyMedium)
            if (track.details.isNotEmpty()) {
                Text(track.details, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
            }
        }
        if (track.isSelected) {
            Icon(Icons.Rounded.Check, null, tint = FastBlue)
        }
    }
}

@Composable
private fun PanelSwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = FastBlue)
        )
    }
}
