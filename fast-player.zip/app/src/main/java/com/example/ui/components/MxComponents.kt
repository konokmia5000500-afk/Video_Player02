package com.example.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.FastBlue

/**
 * MX Player-authentic slim seekbar / slider:
 * - Thin progress line (2.5.dp) with rounded ends
 * - Crisp circular dot thumb (no vertical bar) that smoothly grows slightly on touch
 * - Supports both tap-to-jump and smooth horizontal drag
 */
@Composable
fun MxSeekBar(
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    trackHeight: Dp = 2.6.dp,
    thumbRadius: Dp = 6.5.dp,
    activeColor: Color = FastBlue,
    inactiveColor: Color = Color.White.copy(alpha = 0.28f),
    thumbColor: Color = FastBlue
) {
    val clampedValue = value.coerceIn(0f, 1f)
    var isPressed by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(clampedValue) }
    val currentOnChange by rememberUpdatedState(onValueChange)
    val currentOnFinished by rememberUpdatedState(onValueChangeFinished)

    val animatedRadius by animateDpAsState(
        targetValue = if (isPressed) thumbRadius + 2.5.dp else thumbRadius,
        animationSpec = tween(120),
        label = "mx_thumb_radius"
    )

    val displayFraction = if (isPressed) dragFraction else clampedValue

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(38.dp)
            .then(
                if (enabled) {
                    Modifier.pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val width = size.width.toFloat().coerceAtLeast(1f)
                            isPressed = true
                            val initial = (down.position.x / width).coerceIn(0f, 1f)
                            dragFraction = initial
                            currentOnChange(initial)

                            while (true) {
                                val event = awaitPointerEvent()
                                val ch = event.changes.firstOrNull { it.id == down.id }
                                if (ch == null || !ch.pressed) break
                                val next = (ch.position.x / width).coerceIn(0f, 1f)
                                dragFraction = next
                                currentOnChange(next)
                                ch.consume()
                            }
                            isPressed = false
                            currentOnFinished?.invoke()
                        }
                    }
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(28.dp)) {
            val trackH = trackHeight.toPx()
            val cy = size.height / 2f
            val r = animatedRadius.toPx()
            val usableW = (size.width - r * 2f).coerceAtLeast(1f)
            val startX = r
            val endX = size.width - r
            val thumbX = startX + usableW * displayFraction
            val corner = CornerRadius(trackH / 2f, trackH / 2f)

            // Inactive background thin line
            drawRoundRect(
                color = inactiveColor,
                topLeft = Offset(startX, cy - trackH / 2f),
                size = Size(endX - startX, trackH),
                cornerRadius = corner
            )

            // Active progress thin line
            if (thumbX > startX) {
                drawRoundRect(
                    color = activeColor,
                    topLeft = Offset(startX, cy - trackH / 2f),
                    size = Size(thumbX - startX, trackH),
                    cornerRadius = corner
                )
            }

            // Soft halo when dragging
            if (isPressed) {
                drawCircle(
                    color = thumbColor.copy(alpha = 0.28f),
                    radius = r * 1.9f,
                    center = Offset(thumbX, cy)
                )
            }

            // Crisp circular dot thumb (white center or solid accent dot)
            drawCircle(
                color = if (enabled) thumbColor else thumbColor.copy(alpha = 0.45f),
                radius = r,
                center = Offset(thumbX, cy)
            )
            drawCircle(
                color = Color.White,
                radius = r * 0.45f,
                center = Offset(thumbX, cy)
            )
        }
    }
}
