package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.AccountTree
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.model.LayoutMode
import com.example.model.SortField
import com.example.model.SortOrder
import com.example.model.ViewMode
import com.example.model.ViewOptions

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ViewOptionsDialog(
    initialOptions: ViewOptions,
    onDismiss: () -> Unit,
    onApply: (ViewOptions) -> Unit
) {
    var draft by remember(initialOptions) { mutableStateOf(initialOptions) }
    var fieldsExpanded by remember { mutableStateOf(false) }
    var advancedExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 620.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "View",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 10.dp)
                )

                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp)
                ) {
                    // View Mode Section
                    SectionTitle("View mode")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ViewModeOptionCard(
                            icon = Icons.Rounded.Folder,
                            label = ViewMode.ALL_FOLDERS.label,
                            selected = draft.viewMode == ViewMode.ALL_FOLDERS,
                            onClick = { draft = draft.copy(viewMode = ViewMode.ALL_FOLDERS) },
                            modifier = Modifier.weight(1f)
                        )
                        ViewModeOptionCard(
                            icon = Icons.Rounded.VideoFile,
                            label = ViewMode.FILES.label,
                            selected = draft.viewMode == ViewMode.FILES,
                            onClick = { draft = draft.copy(viewMode = ViewMode.FILES) },
                            modifier = Modifier.weight(1f)
                        )
                        ViewModeOptionCard(
                            icon = Icons.Rounded.AccountTree,
                            label = ViewMode.FOLDERS_TREE.label,
                            selected = draft.viewMode == ViewMode.FOLDERS_TREE,
                            onClick = { draft = draft.copy(viewMode = ViewMode.FOLDERS_TREE) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Layout Section
                    SectionTitle("Layout")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LayoutOptionChip(
                            icon = Icons.AutoMirrored.Rounded.FormatListBulleted,
                            label = LayoutMode.LIST.label,
                            selected = draft.layoutMode == LayoutMode.LIST,
                            onClick = { draft = draft.copy(layoutMode = LayoutMode.LIST) },
                            modifier = Modifier.weight(1f)
                        )
                        LayoutOptionChip(
                            icon = Icons.Rounded.GridView,
                            label = LayoutMode.GRID.label,
                            selected = draft.layoutMode == LayoutMode.GRID,
                            onClick = { draft = draft.copy(layoutMode = LayoutMode.GRID) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Sort By Section
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SectionTitle("Sort by")
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    val toggled = if (draft.sortOrder == SortOrder.ASCENDING) {
                                        SortOrder.DESCENDING
                                    } else {
                                        SortOrder.ASCENDING
                                    }
                                    draft = draft.copy(sortOrder = toggled)
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (draft.sortOrder == SortOrder.ASCENDING) {
                                    Icons.Rounded.ArrowUpward
                                } else {
                                    Icons.Rounded.ArrowDownward
                                },
                                contentDescription = draft.sortOrder.label,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = draft.sortOrder.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SortField.entries.forEach { field ->
                            val selected = draft.sortField == field
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (selected) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (selected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable {
                                        if (selected) {
                                            val toggled = if (draft.sortOrder == SortOrder.ASCENDING) {
                                                SortOrder.DESCENDING
                                            } else {
                                                SortOrder.ASCENDING
                                            }
                                            draft = draft.copy(sortOrder = toggled)
                                        } else {
                                            draft = draft.copy(sortField = field)
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = field.label,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                    // Expandable Fields Section
                    ExpandableHeader(
                        title = "Fields",
                        expanded = fieldsExpanded,
                        onToggle = { fieldsExpanded = !fieldsExpanded }
                    )
                    AnimatedVisibility(visible = fieldsExpanded) {
                        Column(modifier = Modifier.padding(bottom = 8.dp)) {
                            FieldCheckboxRow("Thumbnail", draft.fields.thumbnail) {
                                draft = draft.copy(fields = draft.fields.copy(thumbnail = it))
                            }
                            FieldCheckboxRow("Length", draft.fields.length) {
                                draft = draft.copy(fields = draft.fields.copy(length = it))
                            }
                            FieldCheckboxRow("Date", draft.fields.date) {
                                draft = draft.copy(fields = draft.fields.copy(date = it))
                            }
                            FieldCheckboxRow("Size", draft.fields.size) {
                                draft = draft.copy(fields = draft.fields.copy(size = it))
                            }
                            FieldCheckboxRow("Path / Folder", draft.fields.path) {
                                draft = draft.copy(fields = draft.fields.copy(path = it))
                            }
                            FieldCheckboxRow("Resolution", draft.fields.resolution) {
                                draft = draft.copy(fields = draft.fields.copy(resolution = it))
                            }
                            FieldCheckboxRow("Extension", draft.fields.extension) {
                                draft = draft.copy(fields = draft.fields.copy(extension = it))
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                    // Expandable Advanced Section
                    ExpandableHeader(
                        title = "Advanced",
                        expanded = advancedExpanded,
                        onToggle = { advancedExpanded = !advancedExpanded }
                    )
                    AnimatedVisibility(visible = advancedExpanded) {
                        Column(modifier = Modifier.padding(bottom = 8.dp)) {
                            AdvancedSwitchRow("Show hidden folders", draft.showHiddenFolders) {
                                draft = draft.copy(showHiddenFolders = it)
                            }
                            AdvancedSwitchRow("Show NEW badge", draft.showNewBadge) {
                                draft = draft.copy(showNewBadge = it)
                            }
                            AdvancedSwitchRow("Mark last played", draft.markLastPlayed) {
                                draft = draft.copy(markLastPlayed = it)
                            }
                            AdvancedSwitchRow("Compact rows", draft.compactRows) {
                                draft = draft.copy(compactRows = it)
                            }
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("view_options_cancel")
                    ) {
                        Text(stringResource(R.string.action_cancel))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = { onApply(draft) },
                        modifier = Modifier.testTag("view_options_done")
                    ) {
                        Text(
                            text = stringResource(R.string.action_done),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun ViewModeOptionCard(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val content = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = content, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
            maxLines = 1
        )
    }
}

@Composable
private fun LayoutOptionChip(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun ExpandableHeader(
    title: String,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface
        )
        Icon(
            imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun FieldCheckboxRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun AdvancedSwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
