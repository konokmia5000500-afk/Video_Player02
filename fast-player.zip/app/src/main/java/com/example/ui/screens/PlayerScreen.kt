package com.example.ui.screens

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.util.Rational
import android.view.TextureView
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AspectRatioMode
import com.example.model.PlayerQuickButton
import com.example.model.ScreenOrientationMode
import com.example.ui.theme.FastBlue
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.viewmodel.PlayerViewModel
import com.example.util.FormatUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

private enum class GestureMode {
    NONE, POTENTIAL, HOLD_SPEED, SEEK, VOLUME, BRIGHTNESS, ZOOM, PAN
}

private enum class TapZone { LEFT, CENTER, RIGHT }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlayerScreen(
    viewModel: PlayerViewModel,
    isInPipMode: Boolean,
    onExitToLibrary: () -> Unit,
    onEnterBackgroundAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.playbackState.collectAsStateWithLifecycle()
    val settings by viewModel.settingsState.collectAsStateWithLifecycle()
    val engine = viewModel.engine
    val context = LocalContext.current
    val view = LocalView.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }

    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var showUnlockButton by remember { mutableStateOf(false) }
    var floatingDialog by remember { mutableStateOf(PlayerFloatingDialog.NONE) }
    var rightPanel by remember { mutableStateOf(PlayerRightPanel.NONE) }
    var quickButtonsExpanded by remember { mutableStateOf(false) }
    var fingerDragExtraButtons by remember { mutableIntStateOf(0) }
    var fingerDragAccumPx by remember { mutableFloatStateOf(0f) }

    // Zoom & Pan state
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var showZoomBadge by remember { mutableStateOf(false) }
    var zoomHideJob by remember { mutableStateOf<Job?>(null) }

    // Gesture feedback states
    var containerSize by remember { mutableStateOf(IntSize.Zero) }
    var swipeSeekTargetMs by remember { mutableStateOf<Long?>(null) }
    var swipeSeekDeltaMs by remember { mutableLongStateOf(0L) }
    var volumeIndicatorPercent by remember { mutableStateOf<Int?>(null) }
    var brightnessIndicatorPercent by remember { mutableStateOf<Int?>(null) }
    var volumeHideJob by remember { mutableStateOf<Job?>(null) }
    var brightnessHideJob by remember { mutableStateOf<Job?>(null) }
    var holdSpeedActive by remember { mutableStateOf<Float?>(null) }
    var centerStatusLabel by remember { mutableStateOf<Pair<String, Boolean>?>(null) } // text to isPlaying
    var centerStatusJob by remember { mutableStateOf<Job?>(null) }

    // Double-tap circular seek overlay
    var doubleTapSide by remember { mutableStateOf<TapZone?>(null) }
    var doubleTapAccumSec by remember { mutableIntStateOf(0) }
    var doubleTapRippleOrigin by remember { mutableStateOf(Offset.Zero) }
    val doubleTapRippleAnim = remember { Animatable(0f) }
    var doubleTapHideJob by remember { mutableStateOf<Job?>(null) }

    // Double-tap back to close
    var lastBackPressTime by remember { mutableLongStateOf(0L) }

    // TextureView ref for real screenshot saving
    var textureViewRef by remember { mutableStateOf<TextureView?>(null) }

    // Brightness state
    var currentBrightness by remember {
        mutableFloatStateOf(
            activity?.window?.attributes?.screenBrightness?.takeIf { it in 0f..1f } ?: 0.5f
        )
    }

    // Subtitle external file picker
    val subtitlePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.loadExternalSubtitle(uri)
            Toast.makeText(context, "Subtitle loaded", Toast.LENGTH_SHORT).show()
        }
    }

    // System bars, Orientation, and Keep-Screen-On management
    val isAudioItem = state.currentItem?.isAudio == true || state.isBackgroundAudioMode
    DisposableEffect(activity, isAudioItem, settings.keepScreenOnVideo, settings.screenOrientationMode, state.videoWidth, state.videoHeight) {
        val window = activity?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            if (!isAudioItem) {
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
            if (!isAudioItem && settings.keepScreenOnVideo) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
        if (activity != null && !isAudioItem) {
            activity.requestedOrientation = when (settings.screenOrientationMode) {
                ScreenOrientationMode.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                ScreenOrientationMode.PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                ScreenOrientationMode.SENSOR -> ActivityInfo.SCREEN_ORIENTATION_SENSOR
                ScreenOrientationMode.AUTO_BY_VIDEO -> {
                    if (state.videoWidth > 0 && state.videoHeight > 0 && state.videoHeight > state.videoWidth) {
                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    }
                }
            }
        }
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (window != null) {
                WindowCompat.getInsetsController(window, view).show(WindowInsetsCompat.Type.systemBars())
            }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Auto-hide controls timer
    LaunchedEffect(controlsVisible, state.isPlaying, floatingDialog, rightPanel, quickButtonsExpanded, isLocked) {
        if (controlsVisible && state.isPlaying && floatingDialog == PlayerFloatingDialog.NONE &&
            rightPanel == PlayerRightPanel.NONE && !quickButtonsExpanded && !isLocked
        ) {
            delay(settings.controlsAutoHideSeconds * 1000L)
            controlsVisible = false
        }
    }

    // Auto-hide lock unlock pill
    LaunchedEffect(showUnlockButton) {
        if (showUnlockButton) {
            delay(2500L)
            showUnlockButton = false
        }
    }

    BackHandler {
        when {
            rightPanel != PlayerRightPanel.NONE -> rightPanel = PlayerRightPanel.NONE
            floatingDialog != PlayerFloatingDialog.NONE -> floatingDialog = PlayerFloatingDialog.NONE
            quickButtonsExpanded -> quickButtonsExpanded = false
            isLocked -> showUnlockButton = true
            settings.doubleTapBackToClose -> {
                val now = System.currentTimeMillis()
                if (now - lastBackPressTime < 2000L) {
                    engine.saveCurrentHistoryImmediate()
                    onExitToLibrary()
                } else {
                    lastBackPressTime = now
                    Toast.makeText(context, "Press back again to exit", Toast.LENGTH_SHORT).show()
                }
            }
            else -> {
                engine.saveCurrentHistoryImmediate()
                onExitToLibrary()
            }
        }
    }

    val safeMarginPx = with(density) { 28.dp.toPx() }
    val visibleVideoRect = remember(containerSize, state.videoWidth, state.videoHeight, state.aspectRatioMode) {
        computeVisibleVideoRect(
            containerW = containerSize.width.toFloat(),
            containerH = containerSize.height.toFloat(),
            videoW = state.videoWidth,
            videoH = state.videoHeight,
            mode = state.aspectRatioMode
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged { containerSize = it }
    ) {
        // Video Render Surface or Audio-Only Artwork Backdrop
        if (isAudioItem) {
            AudioNowPlayingVisual(
                title = state.currentItem?.title ?: "Audio",
                subtitle = state.currentItem?.artist ?: state.currentItem?.folderName ?: ""
            )
        } else {
            val videoW = visibleVideoRect.width.roundToInt().coerceAtLeast(1)
            val videoH = visibleVideoRect.height.roundToInt().coerceAtLeast(1)
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(
                            width = with(density) { videoW.toDp() },
                            height = with(density) { videoH.toDp() }
                        )
                        .graphicsLayer(
                            scaleX = zoomScale,
                            scaleY = zoomScale,
                            translationX = panOffset.x,
                            translationY = panOffset.y
                        )
                ) {
                    AndroidView(
                        factory = { ctx ->
                            TextureView(ctx).also { tv ->
                                textureViewRef = tv
                                engine.exoPlayer.setVideoTextureView(tv)
                            }
                        },
                        update = { tv ->
                            textureViewRef = tv
                            engine.exoPlayer.setVideoTextureView(tv)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        // Night mode warm/dim layer
        if (state.nightModeActive) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x4D140A00))
            )
        }

        // Gesture Detection Layer (disabled in PiP mode)
        if (!isInPipMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(
                        isLocked,
                        settings.quickZoomEnabled,
                        settings.doubleTapSeekSeconds,
                        visibleVideoRect,
                        containerSize,
                        isAudioItem
                    ) {
                        val touchSlop = viewConfiguration.touchSlop
                        var lastTapTime = 0L
                        var lastTapZone: TapZone? = null
                        var pendingSingleTapJob: Job? = null

                        awaitEachGesture {
                            val firstDown = awaitFirstDown(requireUnconsumed = false)
                            val downPos = firstDown.position

                            // Check safe edge margin
                            val insideSafeEdge =
                                downPos.x >= safeMarginPx &&
                                    downPos.x <= containerSize.width - safeMarginPx &&
                                    downPos.y >= safeMarginPx &&
                                    downPos.y <= containerSize.height - safeMarginPx

                            // Active area: visible video rect for video, full safe box for audio
                            val activeRect = if (isAudioItem) {
                                Rect(0f, 0f, containerSize.width.toFloat(), containerSize.height.toFloat())
                            } else {
                                visibleVideoRect
                            }
                            val insideVideoArea = insideSafeEdge && activeRect.contains(downPos)

                            if (isLocked) {
                                var moved = false
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val change = event.changes.firstOrNull { it.id == firstDown.id } ?: break
                                    if (!change.pressed) break
                                    if ((change.position - downPos).getDistance() > touchSlop) moved = true
                                }
                                if (!moved) {
                                    showUnlockButton = !showUnlockButton
                                }
                                return@awaitEachGesture
                            }

                            var mode = GestureMode.POTENTIAL
                            var holdSpeedJob: Job? = null
                            var holdStartX = downPos.x
                            var baseHoldSpeed = 2.0f
                            var seekStartMs = engine.exoPlayer.currentPosition
                            var swipeAccumDx = 0f
                            var swipeAccumDy = 0f
                            var startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                            var startBrightness = currentBrightness
                            var prevPinchSpan = 0f
                            var prevPinchCentroid = Offset.Zero

                            if (insideVideoArea) {
                                holdSpeedJob = scope.launch {
                                    delay(340L)
                                    if (mode == GestureMode.POTENTIAL) {
                                        mode = GestureMode.HOLD_SPEED
                                        pendingSingleTapJob?.cancel()
                                        baseHoldSpeed = 2.0f
                                        holdStartX = downPos.x
                                        engine.setTemporarySpeed(baseHoldSpeed)
                                        holdSpeedActive = baseHoldSpeed
                                    }
                                }
                            }

                            while (true) {
                                val event = awaitPointerEvent()
                                val pressedChanges = event.changes.filter { it.pressed }

                                if (pressedChanges.isEmpty()) {
                                    break
                                }

                                // Multi-finger pinch zoom
                                if (pressedChanges.size >= 2 && settings.quickZoomEnabled && !isAudioItem) {
                                    holdSpeedJob?.cancel()
                                    pendingSingleTapJob?.cancel()
                                    if (mode == GestureMode.HOLD_SPEED) {
                                        engine.restoreSavedSpeed()
                                        holdSpeedActive = null
                                    }
                                    val p0 = pressedChanges[0].position
                                    val p1 = pressedChanges[1].position
                                    val span = hypot(p1.x - p0.x, p1.y - p0.y).coerceAtLeast(10f)
                                    val centroid = Offset((p0.x + p1.x) / 2f, (p0.y + p1.y) / 2f)

                                    if (mode != GestureMode.ZOOM) {
                                        mode = GestureMode.ZOOM
                                        prevPinchSpan = span
                                        prevPinchCentroid = centroid
                                    } else {
                                        val rawFactor = span / prevPinchSpan
                                        // Follow fingers slightly slower for smooth, controlled feel
                                        val dampedFactor = 1f + (rawFactor - 1f) * 0.72f
                                        val oldScale = zoomScale
                                        val newScale = (oldScale * dampedFactor).coerceIn(0.25f, 5.0f)

                                        val center = Offset(containerSize.width / 2f, containerSize.height / 2f)
                                        val focusFromCenter = centroid - center - panOffset
                                        val scaleRatio = newScale / oldScale
                                        val centroidDelta = centroid - prevPinchCentroid
                                        val nextPan = panOffset + focusFromCenter * (1f - scaleRatio) + centroidDelta

                                        zoomScale = newScale
                                        panOffset = clampPan(nextPan, newScale, containerSize)
                                        showZoomBadge = true
                                        zoomHideJob?.cancel()

                                        prevPinchSpan = span
                                        prevPinchCentroid = centroid
                                    }
                                    pressedChanges.forEach { if (it.positionChanged()) it.consume() }
                                    continue
                                }

                                // Single pointer handling
                                val ch = pressedChanges.first()
                                val delta = ch.position - ch.previousPosition
                                val totalDist = (ch.position - downPos).getDistance()

                                when (mode) {
                                    GestureMode.POTENTIAL -> {
                                        if (totalDist > touchSlop) {
                                            holdSpeedJob?.cancel()
                                            if (!insideVideoArea) {
                                                mode = GestureMode.NONE
                                            } else if (zoomScale > 1.03f && !isAudioItem) {
                                                mode = GestureMode.PAN
                                            } else {
                                                val totalDx = ch.position.x - downPos.x
                                                val totalDy = ch.position.y - downPos.y
                                                if (abs(totalDx) > abs(totalDy)) {
                                                    mode = GestureMode.SEEK
                                                    seekStartMs = engine.exoPlayer.currentPosition
                                                    swipeAccumDx = totalDx
                                                } else {
                                                    val midX = activeRect.left + activeRect.width / 2f
                                                    if (downPos.x >= midX) {
                                                        mode = GestureMode.VOLUME
                                                        startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                                                    } else {
                                                        mode = GestureMode.BRIGHTNESS
                                                        startBrightness = currentBrightness
                                                    }
                                                    swipeAccumDy = totalDy
                                                }
                                            }
                                        }
                                    }

                                    GestureMode.HOLD_SPEED -> {
                                        val dxFromStart = ch.position.x - holdStartX
                                        val spd = (baseHoldSpeed + dxFromStart / 140f).coerceIn(0.25f, 4.0f)
                                        val stepped = (spd * 20).roundToInt() / 20f
                                        engine.setTemporarySpeed(stepped)
                                        holdSpeedActive = stepped
                                        ch.consume()
                                    }

                                    GestureMode.PAN -> {
                                        panOffset = clampPan(panOffset + delta, zoomScale, containerSize)
                                        ch.consume()
                                    }

                                    GestureMode.SEEK -> {
                                        swipeAccumDx += delta.x
                                        val dur = state.durationMs.coerceAtLeast(1000L)
                                        val deltaMs = ((swipeAccumDx / containerSize.width.coerceAtLeast(1)) * 90_000f).toLong()
                                        val target = (seekStartMs + deltaMs).coerceIn(0L, dur)
                                        swipeSeekTargetMs = target
                                        swipeSeekDeltaMs = target - seekStartMs
                                        if (settings.previewWhileSeeking) {
                                            engine.seekTo(target)
                                        }
                                        ch.consume()
                                    }

                                    GestureMode.VOLUME -> {
                                        swipeAccumDy += delta.y
                                        val frac = -swipeAccumDy / (containerSize.height * 0.55f).coerceAtLeast(100f)
                                        val targetVol = (startVolume + frac * maxVolume).roundToInt().coerceIn(0, maxVolume)
                                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                                        volumeIndicatorPercent = ((targetVol.toFloat() / maxVolume) * 100f).roundToInt()
                                        volumeHideJob?.cancel()
                                        ch.consume()
                                    }

                                    GestureMode.BRIGHTNESS -> {
                                        swipeAccumDy += delta.y
                                        val frac = -swipeAccumDy / (containerSize.height * 0.55f).coerceAtLeast(100f)
                                        val nextB = (startBrightness + frac).coerceIn(0.01f, 1.0f)
                                        currentBrightness = nextB
                                        activity?.window?.let { win ->
                                            val lp = win.attributes
                                            lp.screenBrightness = nextB
                                            win.attributes = lp
                                        }
                                        brightnessIndicatorPercent = (nextB * 100f).roundToInt()
                                        brightnessHideJob?.cancel()
                                        ch.consume()
                                    }

                                    GestureMode.ZOOM, GestureMode.NONE -> Unit
                                }
                            }

                            // Pointer released
                            holdSpeedJob?.cancel()

                            when (mode) {
                                GestureMode.HOLD_SPEED -> {
                                    engine.restoreSavedSpeed()
                                    holdSpeedActive = null
                                }
                                GestureMode.SEEK -> {
                                    swipeSeekTargetMs?.let { engine.seekTo(it) }
                                    swipeSeekTargetMs = null
                                }
                                GestureMode.VOLUME -> {
                                    volumeHideJob = scope.launch {
                                        delay(900L)
                                        volumeIndicatorPercent = null
                                    }
                                }
                                GestureMode.BRIGHTNESS -> {
                                    brightnessHideJob = scope.launch {
                                        delay(900L)
                                        brightnessIndicatorPercent = null
                                    }
                                }
                                GestureMode.ZOOM -> {
                                    zoomHideJob = scope.launch {
                                        delay(800L)
                                        showZoomBadge = false
                                    }
                                }
                                GestureMode.POTENTIAL -> {
                                    // Tap inside/outside
                                    if (!insideVideoArea) {
                                        controlsVisible = !controlsVisible
                                    } else {
                                        val zone = when {
                                            downPos.x < activeRect.left + activeRect.width * 0.33f -> TapZone.LEFT
                                            downPos.x > activeRect.left + activeRect.width * 0.67f -> TapZone.RIGHT
                                            else -> TapZone.CENTER
                                        }
                                        val now = System.currentTimeMillis()
                                        val isDoubleTap = (now - lastTapTime < 280L && lastTapZone == zone) ||
                                            (doubleTapSide == zone && doubleTapHideJob?.isActive == true && now - lastTapTime < 600L)

                                        if (isDoubleTap) {
                                            pendingSingleTapJob?.cancel()
                                            lastTapTime = now
                                            lastTapZone = zone
                                            val step = settings.doubleTapSeekSeconds
                                            when (zone) {
                                                TapZone.LEFT -> {
                                                    engine.seekBy(-step * 1000L)
                                                    doubleTapSide = TapZone.LEFT
                                                    doubleTapAccumSec = if (doubleTapHideJob?.isActive == true && doubleTapSide == TapZone.LEFT) {
                                                        doubleTapAccumSec + step
                                                    } else step
                                                    doubleTapRippleOrigin = downPos
                                                    scope.launch {
                                                        doubleTapRippleAnim.snapTo(0f)
                                                        doubleTapRippleAnim.animateTo(1f, tween(380))
                                                    }
                                                    doubleTapHideJob?.cancel()
                                                    doubleTapHideJob = scope.launch {
                                                        delay(700L)
                                                        doubleTapSide = null
                                                        doubleTapAccumSec = 0
                                                    }
                                                }
                                                TapZone.RIGHT -> {
                                                    engine.seekBy(step * 1000L)
                                                    doubleTapSide = TapZone.RIGHT
                                                    doubleTapAccumSec = if (doubleTapHideJob?.isActive == true && doubleTapSide == TapZone.RIGHT) {
                                                        doubleTapAccumSec + step
                                                    } else step
                                                    doubleTapRippleOrigin = downPos
                                                    scope.launch {
                                                        doubleTapRippleAnim.snapTo(0f)
                                                        doubleTapRippleAnim.animateTo(1f, tween(380))
                                                    }
                                                    doubleTapHideJob?.cancel()
                                                    doubleTapHideJob = scope.launch {
                                                        delay(700L)
                                                        doubleTapSide = null
                                                        doubleTapAccumSec = 0
                                                    }
                                                }
                                                TapZone.CENTER -> {
                                                    engine.togglePlayPause()
                                                    val nowPlaying = !state.isPlaying
                                                    centerStatusLabel = (if (nowPlaying) "Playing" else "Paused") to nowPlaying
                                                    centerStatusJob?.cancel()
                                                    centerStatusJob = scope.launch {
                                                        delay(750L)
                                                        centerStatusLabel = null
                                                    }
                                                }
                                            }
                                        } else {
                                            lastTapTime = now
                                            lastTapZone = zone
                                            pendingSingleTapJob?.cancel()
                                            pendingSingleTapJob = scope.launch {
                                                delay(260L)
                                                controlsVisible = !controlsVisible
                                            }
                                        }
                                    }
                                }
                                GestureMode.PAN, GestureMode.NONE -> Unit
                            }
                        }
                    }
            )
        }

        // Subtitle Overlay (always visible when enabled)
        if (state.subtitlesEnabled && state.cuesText.isNotEmpty() && !isAudioItem) {
            val subStyle = settings.subtitleAppearance
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(
                        start = 24.dp,
                        end = 24.dp,
                        bottom = if (controlsVisible) 118.dp else subStyle.bottomPaddingDp.dp
                    ),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                state.cuesText.forEach { line ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (subStyle.backgroundDim) Color.Black.copy(alpha = 0.62f) else Color.Transparent)
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = line,
                            color = Color(subStyle.textColorArgb),
                            fontSize = subStyle.fontSizeSp.sp,
                            fontWeight = if (subStyle.boldText) FontWeight.Bold else FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            style = TextStyle(
                                shadow = Shadow(Color.Black, Offset(1.5f, 1.5f), 4f)
                            )
                        )
                    }
                }
            }
        }

        // Double-Tap Circular Translucent Skip Overlay + Tap-Point Ripple
        doubleTapSide?.let { side ->
            DoubleTapSkipOverlay(
                side = side,
                seconds = doubleTapAccumSec,
                rippleOrigin = doubleTapRippleOrigin,
                rippleProgress = doubleTapRippleAnim.value,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Double-Tap Center Paused / Playing Pill
        centerStatusLabel?.let { (label, playing) ->
            Row(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.Black.copy(alpha = 0.58f))
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (playing) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                    contentDescription = label,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(label, color = Color.White, style = MaterialTheme.typography.labelLarge)
            }
        }

        // Press-and-Hold Speed Indicator Pill
        holdSpeedActive?.let { spd ->
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 64.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.65f))
                    .padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.FastForward, null, tint = FastBlue, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = FormatUtils.formatSpeed(spd),
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }

        // Large Zoom Percentage Overlay
        if (showZoomBadge) {
            Box(
                modifier = Modifier.align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                OutlinedBigText(text = "${(zoomScale * 100).roundToInt()}%")
            }
        }

        // Horizontal Swipe Seek Preview (Large white outlined time + [delta] + bottom thin bar)
        swipeSeekTargetMs?.let { targetMs ->
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                OutlinedBigText(text = FormatUtils.formatDuration(targetMs))
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedSmallText(text = FormatUtils.formatSignedDelta(swipeSeekDeltaMs))
            }
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 22.dp)
            ) {
                val frac = if (state.durationMs > 0L) (targetMs.toFloat() / state.durationMs.toFloat()).coerceIn(0f, 1f) else 0f
                LinearProgressIndicator(
                    progress = { frac },
                    color = FastBlue,
                    trackColor = Color.White.copy(alpha = 0.25f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(FormatUtils.formatDuration(targetMs), color = Color.White, style = MaterialTheme.typography.labelSmall)
                    Text(FormatUtils.formatDuration(state.durationMs), color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // Volume Indicator at LEFT edge (triggered by right-half vertical swipe)
        volumeIndicatorPercent?.let { pct ->
            VerticalEdgeMeter(
                percent = pct,
                icon = if (pct == 0) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 24.dp)
            )
        }

        // Brightness Indicator at RIGHT edge (triggered by left-half vertical swipe)
        brightnessIndicatorPercent?.let { pct ->
            VerticalEdgeMeter(
                percent = pct,
                icon = Icons.Rounded.WbSunny,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 24.dp)
            )
        }

        // Lock-screen Unlock Button
        AnimatedVisibility(
            visible = isLocked && showUnlockButton && !isInPipMode,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 24.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.7f),
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .clickable {
                        isLocked = false
                        showUnlockButton = false
                        controlsVisible = true
                    }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.LockOpen, "Unlock screen", tint = Color.White)
                }
            }
        }

        // Main Player Controls Overlay
        AnimatedVisibility(
            visible = controlsVisible && !isLocked && !isInPipMode,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(200)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
            ) {
                // Top Bar + Expandable/Draggable Quick-Action Buttons
                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.45f))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            engine.saveCurrentHistoryImmediate()
                            onExitToLibrary()
                        }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Color.White)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = state.currentItem?.title ?: "Fast Player",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (settings.showBatteryAndClock) {
                                val clock = remember(controlsVisible) {
                                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                                }
                                val battery = remember(controlsVisible) { readBatteryPercent(context) }
                                Text(
                                    text = if (battery != null) "$clock • $battery%" else clock,
                                    color = Color.White.copy(alpha = 0.72f),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                        IconButton(onClick = { rightPanel = PlayerRightPanel.AUDIO_TRACK }) {
                            Icon(Icons.Rounded.Audiotrack, "Audio track", tint = Color.White)
                        }
                        if (!isAudioItem) {
                            IconButton(onClick = { rightPanel = PlayerRightPanel.SUBTITLE }) {
                                Icon(Icons.Rounded.Subtitles, "Subtitles", tint = Color.White)
                            }
                        }
                        IconButton(onClick = { rightPanel = PlayerRightPanel.SETTINGS }) {
                            Icon(Icons.Rounded.MoreVert, "Player settings", tint = Color.White)
                        }
                    }

                    // Flatten Quick-Action Button Row (Collapsible + Finger-Draggable + Expandable with labels)
                    val orderedButtons = settings.quickButtonOrder
                    if (quickButtonsExpanded) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color(0xCC151A24),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    orderedButtons.forEach { btn ->
                                        QuickActionLabeledTile(
                                            button = btn,
                                            state = state,
                                            onClick = {
                                                handleQuickButtonClick(
                                                    btn = btn,
                                                    engine = engine,
                                                    onOpenDialog = {
                                                        floatingDialog = it
                                                        quickButtonsExpanded = false
                                                    },
                                                    onScreenshot = {
                                                        val bmp = textureViewRef?.bitmap
                                                        if (bmp != null) {
                                                            scope.launch {
                                                                val ok = viewModel.saveScreenshot(bmp)
                                                                Toast.makeText(
                                                                    context,
                                                                    if (ok) "Screenshot saved to Pictures/FastPlayer" else "Screenshot failed",
                                                                    Toast.LENGTH_SHORT
                                                                ).show()
                                                            }
                                                        }
                                                    },
                                                    onBackgroundPlay = {
                                                        engine.enterBackgroundAudioMode()
                                                        onEnterBackgroundAudio()
                                                    },
                                                    onCycleRotation = {
                                                        val modes = ScreenOrientationMode.entries
                                                        val next = modes[(settings.screenOrientationMode.ordinal + 1) % modes.size]
                                                        viewModel.setScreenOrientation(next)
                                                        Toast.makeText(context, next.label, Toast.LENGTH_SHORT).show()
                                                    }
                                                )
                                            }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { quickButtonsExpanded = false },
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        Icons.Rounded.KeyboardArrowUp,
                                        contentDescription = "Collapse actions",
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                    } else {
                        BoxWithConstraints(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            val baseCount = when {
                                maxWidth < 360.dp -> 4
                                maxWidth < 520.dp -> 5
                                else -> 7
                            }
                            val stepPx = with(density) { 46.dp.toPx() }
                            val visibleCount = (baseCount + fingerDragExtraButtons)
                                .coerceIn(baseCount, orderedButtons.size)
                            val shownButtons = orderedButtons.take(visibleCount)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .pointerInput(orderedButtons.size, baseCount) {
                                        detectHorizontalDragGestures(
                                            onHorizontalDrag = { _, dragAmount ->
                                                fingerDragAccumPx = (fingerDragAccumPx + dragAmount)
                                                    .coerceIn(0f, stepPx * (orderedButtons.size - baseCount))
                                                fingerDragExtraButtons = (fingerDragAccumPx / stepPx).toInt()
                                            }
                                        )
                                    },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                shownButtons.forEach { btn ->
                                    QuickActionRoundButton(
                                        button = btn,
                                        state = state,
                                        onClick = {
                                            handleQuickButtonClick(
                                                btn = btn,
                                                engine = engine,
                                                onOpenDialog = { floatingDialog = it },
                                                onScreenshot = {
                                                    val bmp = textureViewRef?.bitmap
                                                    if (bmp != null) {
                                                        scope.launch {
                                                            val ok = viewModel.saveScreenshot(bmp)
                                                            Toast.makeText(
                                                                context,
                                                                if (ok) "Screenshot saved to Pictures/FastPlayer" else "Screenshot failed",
                                                                Toast.LENGTH_SHORT
                                                            ).show()
                                                        }
                                                    }
                                                },
                                                onBackgroundPlay = {
                                                    engine.enterBackgroundAudioMode()
                                                    onEnterBackgroundAudio()
                                                },
                                                onCycleRotation = {
                                                    val modes = ScreenOrientationMode.entries
                                                    val next = modes[(settings.screenOrientationMode.ordinal + 1) % modes.size]
                                                    viewModel.setScreenOrientation(next)
                                                    Toast.makeText(context, next.label, Toast.LENGTH_SHORT).show()
                                                }
                                            )
                                        }
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.45f))
                                        .clickable { quickButtonsExpanded = true }
                                        .testTag("expand_quick_buttons_arrow"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (visibleCount < orderedButtons.size) {
                                            Icons.Rounded.KeyboardArrowRight
                                        } else {
                                            Icons.Rounded.KeyboardArrowDown
                                        },
                                        contentDescription = "Expand actions",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Bottom Seekbar & Transport Controls
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    val dur = state.durationMs.coerceAtLeast(1L)
                    var isDraggingSeek by remember { mutableStateOf(false) }
                    var sliderPos by remember { mutableFloatStateOf(0f) }
                    val displayPosMs = if (isDraggingSeek) (sliderPos * dur).toLong() else state.positionMs

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = FormatUtils.formatDuration(displayPosMs),
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.width(52.dp)
                        )
                        Slider(
                            value = if (isDraggingSeek) sliderPos else (state.positionMs.toFloat() / dur).coerceIn(0f, 1f),
                            onValueChange = { frac ->
                                isDraggingSeek = true
                                sliderPos = frac
                                if (settings.previewWhileSeeking) {
                                    engine.seekTo((frac * dur).toLong())
                                }
                            },
                            onValueChangeFinished = {
                                engine.seekTo((sliderPos * dur).toLong())
                                isDraggingSeek = false
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = FastBlue,
                                activeTrackColor = FastBlue,
                                inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = FormatUtils.formatDuration(state.durationMs),
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            textAlign = TextAlign.End,
                            modifier = Modifier.width(52.dp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(onClick = {
                            isLocked = true
                            controlsVisible = false
                            showUnlockButton = true
                        }) {
                            Icon(Icons.Rounded.Lock, "Lock screen", tint = Color.White)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { engine.playPrevious() }) {
                                Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(30.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Surface(
                                shape = CircleShape,
                                color = FastBlue,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .clickable { engine.togglePlayPause() }
                                    .testTag("player_play_pause_button")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = if (state.isPlaying) "Pause" else "Play",
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            IconButton(onClick = { engine.playNext() }) {
                                Icon(Icons.Rounded.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(30.dp))
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (!isAudioItem) {
                                IconButton(onClick = {
                                    val next = engine.cycleAspectRatio()
                                    zoomScale = 1f
                                    panOffset = Offset.Zero
                                    Toast.makeText(context, "Aspect: ${next.label}", Toast.LENGTH_SHORT).show()
                                }) {
                                    Icon(Icons.Rounded.AspectRatio, "Aspect ratio", tint = Color.White)
                                }
                                IconButton(onClick = { enterPipMode(activity, state.videoWidth, state.videoHeight) }) {
                                    Icon(Icons.Rounded.PictureInPictureAlt, "Picture in Picture", tint = Color.White)
                                }
                            } else {
                                IconButton(onClick = { floatingDialog = PlayerFloatingDialog.EQUALIZER }) {
                                    Icon(Icons.Rounded.Equalizer, "Equalizer", tint = Color.White)
                                }
                                IconButton(onClick = { floatingDialog = PlayerFloatingDialog.SPEED }) {
                                    Icon(Icons.Rounded.Speed, "Speed", tint = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Translucent Floating Windows & Right-Side Panels
        if (!isInPipMode) {
            PlayerFloatingWindowHost(
                dialog = floatingDialog,
                playbackState = state,
                settings = settings,
                engine = engine,
                onMoveButton = viewModel::moveQuickButton,
                onDismiss = { floatingDialog = PlayerFloatingDialog.NONE }
            )

            PlayerRightSidePanelHost(
                panel = rightPanel,
                playbackState = state,
                settings = settings,
                engine = engine,
                onPickExternalSubtitle = {
                    subtitlePicker.launch(arrayOf("application/x-subrip", "text/vtt", "text/plain", "*/*"))
                },
                onUpdateSubtitleAppearance = viewModel::updateSubtitleAppearance,
                onSetOrientation = viewModel::setScreenOrientation,
                onSetFastSeeking = viewModel::setFastSeeking,
                onSetPlayNextAuto = viewModel::setPlayNextAuto,
                onDismiss = { rightPanel = PlayerRightPanel.NONE }
            )
        }
    }

    // Resume Prompt (if ResumeBehavior == ASK)
    state.pendingResumePromptMs?.let { pos ->
        AlertDialog(
            onDismissRequest = { engine.confirmResumeFromPrompt(false) },
            title = { Text("Resume playback?") },
            text = { Text("Continue from ${FormatUtils.formatDuration(pos)}?") },
            confirmButton = {
                TextButton(onClick = { engine.confirmResumeFromPrompt(true) }) { Text("Resume") }
            },
            dismissButton = {
                TextButton(onClick = { engine.confirmResumeFromPrompt(false) }) { Text("Start over") }
            }
        )
    }

    // Error Dialog
    state.errorMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { engine.clearError() },
            title = { Text("Playback Error") },
            text = { Text(msg) },
            confirmButton = {
                TextButton(onClick = { engine.clearError() }) { Text("OK") }
            }
        )
    }
}

private fun handleQuickButtonClick(
    btn: PlayerQuickButton,
    engine: com.example.player.PlayerEngine,
    onOpenDialog: (PlayerFloatingDialog) -> Unit,
    onScreenshot: () -> Unit,
    onBackgroundPlay: () -> Unit,
    onCycleRotation: () -> Unit
) {
    when (btn) {
        PlayerQuickButton.NIGHT_MODE -> engine.toggleNightMode()
        PlayerQuickButton.CUSTOMISE -> onOpenDialog(PlayerFloatingDialog.CUSTOMISE)
        PlayerQuickButton.SHUFFLE -> engine.toggleShuffle()
        PlayerQuickButton.LOOP -> engine.toggleLoop()
        PlayerQuickButton.MUTE -> engine.toggleMute()
        PlayerQuickButton.SLEEP_TIMER -> onOpenDialog(PlayerFloatingDialog.SLEEP_TIMER)
        PlayerQuickButton.AB_REPEAT -> onOpenDialog(PlayerFloatingDialog.AB_REPEAT)
        PlayerQuickButton.AUDIO_EFFECT -> onOpenDialog(PlayerFloatingDialog.AUDIO_EFFECT)
        PlayerQuickButton.EQUALIZER -> onOpenDialog(PlayerFloatingDialog.EQUALIZER)
        PlayerQuickButton.SPEED -> onOpenDialog(PlayerFloatingDialog.SPEED)
        PlayerQuickButton.SCREENSHOT -> onScreenshot()
        PlayerQuickButton.BACKGROUND_PLAY -> onBackgroundPlay()
        PlayerQuickButton.ROTATION -> onCycleRotation()
    }
}

private fun quickButtonIcon(btn: PlayerQuickButton, state: com.example.player.PlayerPlaybackState): ImageVector {
    return when (btn) {
        PlayerQuickButton.NIGHT_MODE -> Icons.Rounded.DarkMode
        PlayerQuickButton.CUSTOMISE -> Icons.Rounded.Tune
        PlayerQuickButton.SHUFFLE -> Icons.Rounded.Shuffle
        PlayerQuickButton.LOOP -> if (state.loopOne) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat
        PlayerQuickButton.MUTE -> if (state.isMuted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp
        PlayerQuickButton.SLEEP_TIMER -> Icons.Rounded.Bedtime
        PlayerQuickButton.AB_REPEAT -> Icons.Rounded.Repeat
        PlayerQuickButton.AUDIO_EFFECT -> Icons.Rounded.GraphicEq
        PlayerQuickButton.EQUALIZER -> Icons.Rounded.Equalizer
        PlayerQuickButton.SPEED -> Icons.Rounded.Speed
        PlayerQuickButton.SCREENSHOT -> Icons.Rounded.CameraAlt
        PlayerQuickButton.BACKGROUND_PLAY -> Icons.Rounded.Headphones
        PlayerQuickButton.ROTATION -> Icons.Rounded.ScreenRotation
    }
}

private fun isQuickButtonActive(btn: PlayerQuickButton, state: com.example.player.PlayerPlaybackState): Boolean {
    return when (btn) {
        PlayerQuickButton.NIGHT_MODE -> state.nightModeActive
        PlayerQuickButton.SHUFFLE -> state.isShuffle
        PlayerQuickButton.LOOP -> state.loopOne
        PlayerQuickButton.MUTE -> state.isMuted
        PlayerQuickButton.SLEEP_TIMER -> state.sleepTimerRemainingSec != null
        PlayerQuickButton.AB_REPEAT -> state.abPointAMs != null
        PlayerQuickButton.EQUALIZER -> state.eqEnabled
        PlayerQuickButton.SPEED -> abs(state.playbackSpeed - 1.0f) > 0.04f
        else -> false
    }
}

@Composable
private fun QuickActionRoundButton(
    button: PlayerQuickButton,
    state: com.example.player.PlayerPlaybackState,
    onClick: () -> Unit
) {
    val active = isQuickButtonActive(button, state)
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (active) FastBlue.copy(alpha = 0.85f) else Color.Black.copy(alpha = 0.45f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = quickButtonIcon(button, state),
            contentDescription = button.label,
            tint = Color.White,
            modifier = Modifier.size(19.dp)
        )
    }
}

@Composable
private fun QuickActionLabeledTile(
    button: PlayerQuickButton,
    state: com.example.player.PlayerPlaybackState,
    onClick: () -> Unit
) {
    val active = isQuickButtonActive(button, state)
    Column(
        modifier = Modifier
            .width(72.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(if (active) FastBlue else Color.White.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = quickButtonIcon(button, state),
                contentDescription = button.label,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = button.label,
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun DoubleTapSkipOverlay(
    side: TapZone,
    seconds: Int,
    rippleOrigin: Offset,
    rippleProgress: Float,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val circleCenterX = if (side == TapZone.LEFT) -size.width * 0.08f else size.width * 1.08f
            val circleCenter = Offset(circleCenterX, size.height / 2f)
            val areaRadius = size.width * 0.48f

            drawCircle(
                color = Color.Black.copy(alpha = 0.42f),
                radius = areaRadius,
                center = circleCenter
            )

            // Tap-point spreading ripple fading into the translucent area
            val rippleRadius = (36.dp.toPx() + 110.dp.toPx() * rippleProgress)
            val rippleAlpha = (0.38f * (1f - rippleProgress)).coerceIn(0f, 1f)
            if (rippleAlpha > 0.01f) {
                drawCircle(
                    color = Color.White.copy(alpha = rippleAlpha),
                    radius = rippleRadius,
                    center = rippleOrigin
                )
            }
        }

        Column(
            modifier = Modifier
                .align(if (side == TapZone.LEFT) Alignment.CenterStart else Alignment.CenterEnd)
                .padding(horizontal = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = if (side == TapZone.LEFT) Icons.Rounded.FastRewind else Icons.Rounded.FastForward,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(30.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (side == TapZone.LEFT) "-${seconds}s" else "+${seconds}s",
                color = Color.White,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

@Composable
private fun VerticalEdgeMeter(
    percent: Int,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Color.Black.copy(alpha = 0.62f))
            .padding(horizontal = 10.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "$percent%",
            color = Color.White,
            style = MaterialTheme.typography.labelSmall
        )
        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .width(6.dp)
                .height(110.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color.White.copy(alpha = 0.25f)),
            contentAlignment = Alignment.BottomCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight((percent / 100f).coerceIn(0f, 1f))
                    .clip(RoundedCornerShape(3.dp))
                    .background(FastBlue)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun OutlinedBigText(text: String) {
    Box(contentAlignment = Alignment.Center) {
        Text(
            text = text,
            style = TextStyle(
                fontFamily = JetBrainsMonoFamily,
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black.copy(alpha = 0.85f),
                drawStyle = Stroke(width = 6f, join = StrokeJoin.Round)
            )
        )
        Text(
            text = text,
            style = TextStyle(
                fontFamily = JetBrainsMonoFamily,
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        )
    }
}

@Composable
private fun OutlinedSmallText(text: String) {
    Box(contentAlignment = Alignment.Center) {
        Text(
            text = text,
            style = TextStyle(
                fontFamily = JetBrainsMonoFamily,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.Black.copy(alpha = 0.85f),
                drawStyle = Stroke(width = 4f, join = StrokeJoin.Round)
            )
        )
        Text(
            text = text,
            style = TextStyle(
                fontFamily = JetBrainsMonoFamily,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
        )
    }
}

@Composable
private fun AudioNowPlayingVisual(
    title: String,
    subtitle: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A101A)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
                    .background(FastBlue.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.MusicNote,
                    contentDescription = null,
                    tint = FastBlue,
                    modifier = Modifier.size(72.dp)
                )
            }
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = title,
                color = Color.White,
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (subtitle.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = subtitle,
                    color = Color.White.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

private fun computeVisibleVideoRect(
    containerW: Float,
    containerH: Float,
    videoW: Int,
    videoH: Int,
    mode: AspectRatioMode
): Rect {
    if (containerW <= 0f || containerH <= 0f) return Rect.Zero
    if (mode == AspectRatioMode.STRETCH) return Rect(0f, 0f, containerW, containerH)

    val targetRatio = when (mode) {
        AspectRatioMode.RATIO_16_9 -> 16f / 9f
        AspectRatioMode.RATIO_4_3 -> 4f / 3f
        AspectRatioMode.FIT, AspectRatioMode.FILL, AspectRatioMode.CROP -> {
            if (videoW > 0 && videoH > 0) videoW.toFloat() / videoH.toFloat() else containerW / containerH
        }
        AspectRatioMode.STRETCH -> containerW / containerH
    }

    val containerRatio = containerW / containerH
    val isFill = mode == AspectRatioMode.FILL || mode == AspectRatioMode.CROP

    val w: Float
    val h: Float
    if (isFill) {
        if (targetRatio > containerRatio) {
            h = containerH
            w = h * targetRatio
        } else {
            w = containerW
            h = w / targetRatio
        }
    } else {
        if (targetRatio > containerRatio) {
            w = containerW
            h = w / targetRatio
        } else {
            h = containerH
            w = h * targetRatio
        }
    }

    val left = (containerW - w) / 2f
    val top = (containerH - h) / 2f
    return Rect(left, top, left + w, top + h)
}

private fun clampPan(pan: Offset, scale: Float, containerSize: IntSize): Offset {
    if (scale <= 1f) return Offset.Zero
    val maxPanX = (containerSize.width * (scale - 1f)) / 2f + 120f
    val maxPanY = (containerSize.height * (scale - 1f)) / 2f + 120f
    return Offset(
        x = pan.x.coerceIn(-maxPanX, maxPanX),
        y = pan.y.coerceIn(-maxPanY, maxPanY)
    )
}

private fun readBatteryPercent(context: Context): Int? {
    return try {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).takeIf { it in 0..100 }
    } catch (_: Exception) {
        null
    }
}

fun enterPipMode(activity: Activity?, videoWidth: Int, videoHeight: Int) {
    if (activity == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    try {
        val ratio = if (videoWidth > 0 && videoHeight > 0) {
            val r = videoWidth.toFloat() / videoHeight.toFloat()
            val clamped = r.coerceIn(0.45f, 2.3f)
            Rational((clamped * 100).roundToInt(), 100)
        } else {
            Rational(16, 9)
        }
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(ratio)
            .build()
        activity.enterPictureInPictureMode(params)
    } catch (_: Exception) {
    }
}
