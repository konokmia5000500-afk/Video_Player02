package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.FastPlayerApp
import com.example.data.local.MediaStoreRepository
import com.example.data.local.MediaStoreRepository.Companion.SearchResultGroup
import com.example.data.local.PlaybackHistoryEntity
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistItemEntity
import com.example.data.local.ThumbnailCacheManager
import com.example.model.AppSettings
import com.example.model.FontSizeOption
import com.example.model.LastPlayedSummary
import com.example.model.MediaFolder
import com.example.model.MediaItemModel
import com.example.model.PlaylistEntryModel
import com.example.model.PlaylistModel
import com.example.model.ResumeBehavior
import com.example.model.ScreenOrientationMode
import com.example.model.SortField
import com.example.model.SortOrder
import com.example.model.SubtitleAppearance
import com.example.model.ThemeOption
import com.example.model.ViewMode
import com.example.model.ViewOptions
import com.example.util.FormatUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class LibraryUiState(
    val isLoading: Boolean = true,
    val hasMediaPermission: Boolean = false,
    val settings: AppSettings = AppSettings(),
    val currentFolderPath: String? = null,
    val currentFolderName: String? = null,
    val folders: List<MediaFolder> = emptyList(),
    val visibleVideos: List<MediaItemModel> = emptyList(),
    val allVideosCount: Int = 0,
    val audioItems: List<MediaItemModel> = emptyList(),
    val playlists: List<PlaylistModel> = emptyList(),
    val lastPlayed: LastPlayedSummary? = null,
    val isSearchActive: Boolean = false,
    val searchQuery: String = "",
    val videoSearchResults: SearchResultGroup = SearchResultGroup(emptyList(), emptyList()),
    val audioSearchResults: SearchResultGroup = SearchResultGroup(emptyList(), emptyList()),
    val playlistSearchResults: SearchResultGroup = SearchResultGroup(emptyList(), emptyList()),
    val thumbnailCacheSizeBytes: Long = 0L,
    val discoveredFolders: List<Pair<String, Int>> = emptyList()
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as FastPlayerApp
    private val settingsRepo = app.settingsRepository
    private val mediaRepo = app.mediaStoreRepository
    private val historyDao = app.database.playbackHistoryDao()
    private val playlistDao = app.database.playlistDao()
    val playerEngine = app.playerEngine

    private val _rawVideos = MutableStateFlow<List<MediaItemModel>>(emptyList())
    private val _rawAudio = MutableStateFlow<List<MediaItemModel>>(emptyList())
    private val _isLoading = MutableStateFlow(true)
    private val _hasPermission = MutableStateFlow(FormatUtils.hasMediaPermission(application))

    // Navigation inside Video folders
    private val _currentFolderPath = MutableStateFlow<String?>(null)
    private val _folderStack = MutableStateFlow<List<String>>(emptyList())

    // Search
    private val _isSearchActive = MutableStateFlow(false)
    private val _searchQuery = MutableStateFlow("")

    // Playlist detail
    private val _selectedPlaylistId = MutableStateFlow<Long?>(null)
    val selectedPlaylistId: StateFlow<Long?> = _selectedPlaylistId.asStateFlow()

    // Discovered folders & cache info for settings
    private val _discoveredFolders = MutableStateFlow<List<Pair<String, Int>>>(emptyList())
    private val _cacheSizeBytes = MutableStateFlow(ThumbnailCacheManager.getCacheSizeBytes(application))

    val settingsState: StateFlow<AppSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val allHistoryFlow: StateFlow<List<PlaybackHistoryEntity>> = historyDao.observeAllHistory()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val selectedPlaylistEntries: StateFlow<List<PlaylistEntryModel>> = _selectedPlaylistId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else playlistDao.observePlaylistItems(id).map { list ->
                list.map {
                    PlaylistEntryModel(
                        entryId = it.entryId,
                        playlistId = it.playlistId,
                        mediaUri = it.mediaUri,
                        title = it.title,
                        folderPath = it.folderPath,
                        isAudio = it.isAudio,
                        durationMs = it.durationMs,
                        sizeBytes = it.sizeBytes,
                        artist = it.artist,
                        albumId = it.albumId,
                        positionOrder = it.positionOrder
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val playlistsFlow: StateFlow<List<PlaylistModel>> = playlistDao.observePlaylistSummaries()
        .map { rows -> rows.map { PlaylistModel(it.id, it.name, it.itemCount, it.createdAt) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val enrichedVideosFlow = combine(
        _rawVideos,
        allHistoryFlow,
        settingsState
    ) { videos, history, settings ->
        val historyMap = history.associateBy { it.mediaUri }
        val mostRecentVideo = history.firstOrNull { !it.isAudio }
        val lastPerFolder = if (settings.markLastPlayedInEachFolder) {
            history.filter { !it.isAudio }
                .groupBy { it.folderPath }
                .mapValues { (_, entries) -> entries.maxByOrNull { it.lastPlayedAt }?.mediaUri }
        } else {
            emptyMap()
        }

        videos.map { item ->
            val h = historyMap[item.uriString]
            val isLastInFolder = settings.viewOptions.markLastPlayed && (
                lastPerFolder[item.folderPath] == item.uriString ||
                    mostRecentVideo?.mediaUri == item.uriString
                )
            item.copy(
                lastPositionMs = h?.lastPositionMs ?: 0L,
                isLastPlayed = isLastInFolder
            )
        }
    }

    private val enrichedAudioFlow = combine(
        _rawAudio,
        allHistoryFlow,
        settingsState
    ) { audios, history, settings ->
        val historyMap = history.associateBy { it.mediaUri }
        val mostRecentAudio = history.firstOrNull { it.isAudio }
        audios.map { item ->
            val h = historyMap[item.uriString]
            item.copy(
                lastPositionMs = h?.lastPositionMs ?: 0L,
                isLastPlayed = settings.viewOptions.markLastPlayed && mostRecentAudio?.mediaUri == item.uriString
            )
        }
    }

    val uiState: StateFlow<LibraryUiState> = combine(
        listOf(
            _isLoading,
            _hasPermission,
            settingsState,
            _currentFolderPath,
            enrichedVideosFlow,
            enrichedAudioFlow,
            playlistsFlow,
            allHistoryFlow,
            _isSearchActive,
            _searchQuery,
            selectedPlaylistEntries,
            _cacheSizeBytes,
            _discoveredFolders
        )
    ) { values ->
        val isLoading = values[0] as Boolean
        val hasPerm = values[1] as Boolean
        val settings = values[2] as AppSettings
        val currentFolder = values[3] as String?
        @Suppress("UNCHECKED_CAST")
        val videos = values[4] as List<MediaItemModel>
        @Suppress("UNCHECKED_CAST")
        val audios = values[5] as List<MediaItemModel>
        @Suppress("UNCHECKED_CAST")
        val playlists = values[6] as List<PlaylistModel>
        @Suppress("UNCHECKED_CAST")
        val history = values[7] as List<PlaybackHistoryEntity>
        val searchActive = values[8] as Boolean
        val query = values[9] as String
        @Suppress("UNCHECKED_CAST")
        val playlistEntries = values[10] as List<PlaylistEntryModel>
        val cacheSize = values[11] as Long
        @Suppress("UNCHECKED_CAST")
        val discovered = values[12] as List<Pair<String, Int>>

        val vo = settings.viewOptions
        val lastVideoFolder = history.firstOrNull { !it.isAudio }?.folderPath
        val mostRecent = history.firstOrNull()?.let {
            LastPlayedSummary(
                mediaUri = it.mediaUri,
                title = it.title,
                folderPath = it.folderPath,
                isAudio = it.isAudio,
                positionMs = it.lastPositionMs,
                durationMs = it.durationMs
            )
        }

        val (folders, visibleVideos) = when (vo.viewMode) {
            ViewMode.FILES -> {
                emptyList<MediaFolder>() to MediaStoreRepository.sortMedia(videos, vo.sortField, vo.sortOrder)
            }
            ViewMode.ALL_FOLDERS -> {
                if (currentFolder == null) {
                    val allF = MediaStoreRepository.buildAllFolders(
                        videos = videos,
                        lastPlayedFolderPath = lastVideoFolder,
                        markLastPlayed = vo.markLastPlayed && settings.markLastPlayedInEachFolder
                    )
                    MediaStoreRepository.sortFolders(allF, vo.sortField, vo.sortOrder) to emptyList()
                } else {
                    val folderItems = videos.filter { it.folderPath == currentFolder }
                    emptyList<MediaFolder>() to MediaStoreRepository.sortMedia(folderItems, vo.sortField, vo.sortOrder)
                }
            }
            ViewMode.FOLDERS_TREE -> {
                val (childFolders, directVideos) = MediaStoreRepository.buildTreeChildren(
                    videos = videos,
                    currentTreePath = currentFolder,
                    lastPlayedFolderPath = lastVideoFolder,
                    markLastPlayed = vo.markLastPlayed && settings.markLastPlayedInEachFolder
                )
                MediaStoreRepository.sortFolders(childFolders, vo.sortField, vo.sortOrder) to
                    MediaStoreRepository.sortMedia(directVideos, vo.sortField, vo.sortOrder)
            }
        }

        val sortedAudios = MediaStoreRepository.sortMedia(audios, settings.audioSortField, settings.audioSortOrder)

        val videoSearchPool = if (currentFolder != null) {
            videos.filter {
                if (vo.viewMode == ViewMode.FOLDERS_TREE) {
                    it.folderPath == currentFolder || it.folderPath.startsWith("$currentFolder/")
                } else {
                    it.folderPath == currentFolder
                }
            }
        } else {
            videos
        }

        val videoSearchResults = if (searchActive && query.isNotBlank()) {
            MediaStoreRepository.searchMediaWithRelated(videoSearchPool, query)
        } else {
            SearchResultGroup(emptyList(), emptyList())
        }

        val audioSearchResults = if (searchActive && query.isNotBlank()) {
            MediaStoreRepository.searchMediaWithRelated(sortedAudios, query)
        } else {
            SearchResultGroup(emptyList(), emptyList())
        }

        val playlistAsMedia = playlistEntries.map { e ->
            MediaItemModel(
                id = e.entryId,
                uriString = e.mediaUri,
                title = e.title,
                displayName = e.title,
                path = e.mediaUri,
                folderPath = e.folderPath,
                folderName = e.folderPath.substringAfterLast('/'),
                durationMs = e.durationMs,
                sizeBytes = e.sizeBytes,
                dateAddedSec = 0L,
                dateModifiedSec = 0L,
                isAudio = e.isAudio,
                artist = e.artist,
                albumId = e.albumId
            )
        }
        val playlistSearchResults = if (searchActive && query.isNotBlank()) {
            MediaStoreRepository.searchMediaWithRelated(playlistAsMedia, query)
        } else {
            SearchResultGroup(emptyList(), emptyList())
        }

        val currentFolderName = currentFolder?.substringAfterLast('/')?.ifBlank { "Storage" }

        LibraryUiState(
            isLoading = isLoading,
            hasMediaPermission = hasPerm,
            settings = settings,
            currentFolderPath = currentFolder,
            currentFolderName = currentFolderName,
            folders = folders,
            visibleVideos = visibleVideos,
            allVideosCount = videos.size,
            audioItems = sortedAudios,
            playlists = playlists,
            lastPlayed = mostRecent,
            isSearchActive = searchActive,
            searchQuery = query,
            videoSearchResults = videoSearchResults,
            audioSearchResults = audioSearchResults,
            playlistSearchResults = playlistSearchResults,
            thumbnailCacheSizeBytes = cacheSize,
            discoveredFolders = discovered
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, LibraryUiState())

    init {
        refreshMedia()
    }

    fun onPermissionResult() {
        _hasPermission.value = FormatUtils.hasMediaPermission(app)
        refreshMedia()
    }

    fun refreshMedia() {
        val perm = FormatUtils.hasMediaPermission(app)
        _hasPermission.value = perm
        if (!perm) {
            _isLoading.value = false
            return
        }
        viewModelScope.launch {
            val s = settingsRepo.settingsFlow.first()
            val videos = mediaRepo.scanVideos(
                newBadgeDays = s.newBadgeDays,
                showHiddenFolders = s.viewOptions.showHiddenFolders,
                excludedFolders = s.excludedFolders
            )
            _rawVideos.value = videos
            _isLoading.value = false

            val audios = mediaRepo.scanAudio(
                newBadgeDays = s.newBadgeDays,
                showHiddenFolders = s.viewOptions.showHiddenFolders,
                excludedFolders = s.excludedFolders
            )
            _rawAudio.value = audios
            _cacheSizeBytes.value = ThumbnailCacheManager.getCacheSizeBytes(app)
        }
    }

    fun loadDiscoveredFolders() {
        viewModelScope.launch {
            val s = settingsState.value
            _discoveredFolders.value = mediaRepo.discoverAllVideoFolders(s.viewOptions.showHiddenFolders)
        }
    }

    fun openFolder(folderPath: String) {
        _folderStack.update { stack ->
            val cur = _currentFolderPath.value
            if (cur != null) stack + cur else stack
        }
        _currentFolderPath.value = folderPath
    }

    fun navigateFolderUp(): Boolean {
        val cur = _currentFolderPath.value ?: return false
        val stack = _folderStack.value
        if (stack.isNotEmpty()) {
            _currentFolderPath.value = stack.last()
            _folderStack.value = stack.dropLast(1)
        } else {
            _currentFolderPath.value = null
        }
        return true
    }

    fun resetFolderNavigation() {
        _currentFolderPath.value = null
        _folderStack.value = emptyList()
    }

    fun cycleViewMode() {
        val current = settingsState.value.viewOptions
        val nextMode = when (current.viewMode) {
            ViewMode.FOLDERS_TREE -> ViewMode.ALL_FOLDERS
            ViewMode.ALL_FOLDERS -> ViewMode.FILES
            ViewMode.FILES -> ViewMode.FOLDERS_TREE
        }
        resetFolderNavigation()
        viewModelScope.launch {
            settingsRepo.updateViewOptions(current.copy(viewMode = nextMode))
        }
    }

    fun updateViewOptions(options: ViewOptions) {
        val prev = settingsState.value.viewOptions
        if (prev.viewMode != options.viewMode) {
            resetFolderNavigation()
        }
        viewModelScope.launch {
            settingsRepo.updateViewOptions(options)
            if (prev.showHiddenFolders != options.showHiddenFolders) {
                refreshMedia()
            }
        }
    }

    fun updateAudioSort(field: SortField, order: SortOrder) {
        viewModelScope.launch { settingsRepo.updateAudioSort(field, order) }
    }

    // Search
    fun setSearchActive(active: Boolean) {
        _isSearchActive.value = active
        if (!active) _searchQuery.value = ""
    }

    fun updateSearchQuery(q: String) {
        _searchQuery.value = q
    }

    // Playback triggers
    fun playVideoItem(item: MediaItemModel, list: List<MediaItemModel>, forceStartFromZero: Boolean = false) {
        val idx = list.indexOfFirst { it.uriString == item.uriString }.coerceAtLeast(0)
        playerEngine.playQueue(
            items = list,
            startIndex = idx,
            backgroundAudioOnly = false,
            forceStartFromZero = forceStartFromZero
        )
    }

    fun playVideoAsAudio(item: MediaItemModel, list: List<MediaItemModel>) {
        val idx = list.indexOfFirst { it.uriString == item.uriString }.coerceAtLeast(0)
        playerEngine.playQueue(
            items = list,
            startIndex = idx,
            backgroundAudioOnly = true,
            forceStartFromZero = false
        )
    }

    fun playAudioItem(item: MediaItemModel, list: List<MediaItemModel>) {
        val idx = list.indexOfFirst { it.uriString == item.uriString }.coerceAtLeast(0)
        playerEngine.playQueue(
            items = list,
            startIndex = idx,
            backgroundAudioOnly = true,
            forceStartFromZero = false
        )
    }

    fun openExternalUri(uri: Uri): Boolean {
        val item = mediaRepo.resolveExternalUri(uri)
        playerEngine.playQueue(
            items = listOf(item),
            startIndex = 0,
            backgroundAudioOnly = item.isAudio,
            forceStartFromZero = false
        )
        return item.isAudio
    }

    fun resumeLastPlayed(): Boolean {
        val last = uiState.value.lastPlayed
        if (last != null) {
            val allPool = _rawVideos.value + _rawAudio.value
            val found = allPool.firstOrNull { it.uriString == last.mediaUri }
            if (found != null) {
                val queue = if (found.isAudio) {
                    uiState.value.audioItems.ifEmpty { listOf(found) }
                } else {
                    _rawVideos.value.filter { it.folderPath == found.folderPath }.ifEmpty { listOf(found) }
                }
                val idx = queue.indexOfFirst { it.uriString == found.uriString }.coerceAtLeast(0)
                playerEngine.playQueue(queue, idx, backgroundAudioOnly = found.isAudio)
                return !found.isAudio
            } else {
                val fallback = MediaItemModel(
                    id = last.mediaUri.hashCode().toLong(),
                    uriString = last.mediaUri,
                    title = last.title,
                    displayName = last.title,
                    path = last.mediaUri,
                    folderPath = last.folderPath,
                    folderName = last.folderPath.substringAfterLast('/'),
                    durationMs = last.durationMs,
                    sizeBytes = 0L,
                    dateAddedSec = 0L,
                    dateModifiedSec = 0L,
                    isAudio = last.isAudio
                )
                playerEngine.playQueue(listOf(fallback), 0, backgroundAudioOnly = last.isAudio)
                return !last.isAudio
            }
        }
        val firstVideo = _rawVideos.value.firstOrNull()
        if (firstVideo != null) {
            playVideoItem(firstVideo, _rawVideos.value)
            return true
        }
        val firstAudio = _rawAudio.value.firstOrNull()
        if (firstAudio != null) {
            playAudioItem(firstAudio, _rawAudio.value)
            return false
        }
        return false
    }

    // Playlists
    fun selectPlaylist(playlistId: Long?) {
        _selectedPlaylistId.value = playlistId
    }

    fun createPlaylist(name: String, initialMedia: MediaItemModel? = null) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val id = playlistDao.insertPlaylist(PlaylistEntity(name = trimmed))
            if (initialMedia != null) {
                addItemToPlaylistInternal(id, initialMedia)
            }
        }
    }

    fun renamePlaylist(playlistId: Long, newName: String) {
        val trimmed = newName.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            playlistDao.renamePlaylist(playlistId, trimmed)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            playlistDao.deletePlaylist(playlistId)
            if (_selectedPlaylistId.value == playlistId) {
                _selectedPlaylistId.value = null
            }
        }
    }

    fun addItemToPlaylist(playlistId: Long, item: MediaItemModel) {
        viewModelScope.launch(Dispatchers.IO) {
            addItemToPlaylistInternal(playlistId, item)
        }
    }

    private suspend fun addItemToPlaylistInternal(playlistId: Long, item: MediaItemModel) {
        val nextOrder = playlistDao.nextOrder(playlistId)
        playlistDao.insertPlaylistItem(
            PlaylistItemEntity(
                playlistId = playlistId,
                mediaUri = item.uriString,
                title = item.title,
                folderPath = item.folderPath,
                isAudio = item.isAudio,
                durationMs = item.durationMs,
                sizeBytes = item.sizeBytes,
                artist = item.artist,
                albumId = item.albumId,
                positionOrder = nextOrder
            )
        )
    }

    fun removePlaylistEntry(entryId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            playlistDao.deletePlaylistItem(entryId)
        }
    }

    fun playPlaylistEntries(entries: List<PlaylistEntryModel>, startIndex: Int, shuffle: Boolean = false): Boolean {
        if (entries.isEmpty()) return false
        val items = entries.map { e ->
            MediaItemModel(
                id = e.entryId,
                uriString = e.mediaUri,
                title = e.title,
                displayName = e.title,
                path = e.mediaUri,
                folderPath = e.folderPath,
                folderName = e.folderPath.substringAfterLast('/'),
                durationMs = e.durationMs,
                sizeBytes = e.sizeBytes,
                dateAddedSec = 0L,
                dateModifiedSec = 0L,
                isAudio = e.isAudio,
                artist = e.artist,
                albumId = e.albumId
            )
        }
        val playList = if (shuffle) items.shuffled() else items
        val start = if (shuffle) 0 else startIndex.coerceIn(0, playList.lastIndex)
        val allAudio = playList.all { it.isAudio }
        playerEngine.playQueue(playList, start, backgroundAudioOnly = allAudio)
        return !playList[start].isAudio
    }

    // Settings Actions
    fun setTheme(theme: ThemeOption) = viewModelScope.launch { settingsRepo.updateTheme(theme) }
    fun setFontSize(size: FontSizeOption) = viewModelScope.launch { settingsRepo.updateFontSize(size) }
    fun setDoubleTapSeekSeconds(sec: Int) = viewModelScope.launch { settingsRepo.updateDoubleTapSeekSeconds(sec) }
    fun setShowFloatingResume(v: Boolean) = viewModelScope.launch { settingsRepo.setShowFloatingResume(v) }
    fun setRememberPosition(v: Boolean) = viewModelScope.launch { settingsRepo.setRememberPosition(v) }
    fun setResumeBehavior(v: ResumeBehavior) = viewModelScope.launch { settingsRepo.setResumeBehavior(v) }
    fun setMarkLastPlayedFolder(v: Boolean) = viewModelScope.launch { settingsRepo.setMarkLastPlayedFolder(v) }
    fun setScrollToLastMedia(v: Boolean) = viewModelScope.launch { settingsRepo.setScrollToLastMedia(v) }
    fun setNewBadgeDays(days: Int) = viewModelScope.launch {
        settingsRepo.setNewBadgeDays(days)
        refreshMedia()
    }
    fun toggleFolderExcluded(folderPath: String) = viewModelScope.launch {
        val current = settingsState.value.excludedFolders.toMutableSet()
        if (!current.add(folderPath)) current.remove(folderPath)
        settingsRepo.setExcludedFolders(current)
        refreshMedia()
    }
    fun setShowHiddenFolders(v: Boolean) = viewModelScope.launch {
        settingsRepo.setShowHiddenFolders(v)
        refreshMedia()
    }
    fun setControlsAutoHideSeconds(sec: Int) = viewModelScope.launch { settingsRepo.setControlsAutoHideSeconds(sec) }
    fun setShowBatteryAndClock(v: Boolean) = viewModelScope.launch { settingsRepo.setShowBatteryAndClock(v) }
    fun setScreenOrientation(mode: ScreenOrientationMode) = viewModelScope.launch { settingsRepo.setScreenOrientation(mode) }
    fun setDoubleTapBackToClose(v: Boolean) = viewModelScope.launch { settingsRepo.setDoubleTapBackToClose(v) }
    fun setQuickZoomEnabled(v: Boolean) = viewModelScope.launch { settingsRepo.setQuickZoomEnabled(v) }
    fun setKeepScreenOnVideo(v: Boolean) = viewModelScope.launch { settingsRepo.setKeepScreenOnVideo(v) }
    fun setDefaultSpeed(speed: Float) = viewModelScope.launch { settingsRepo.setDefaultSpeed(speed) }
    fun setRememberTrackSelections(v: Boolean) = viewModelScope.launch { settingsRepo.setRememberTrackSelections(v) }
    fun setPlayNextAutomatically(v: Boolean) = viewModelScope.launch { settingsRepo.setPlayNextAutomatically(v) }
    fun setPreviewWhileSeeking(v: Boolean) = viewModelScope.launch { settingsRepo.setPreviewWhileSeeking(v) }
    fun setFastSeeking(v: Boolean) = viewModelScope.launch { settingsRepo.setFastSeeking(v) }
    fun setSmartPrevious(v: Boolean) = viewModelScope.launch { settingsRepo.setSmartPrevious(v) }
    fun setSuppressErrors(v: Boolean) = viewModelScope.launch { settingsRepo.setSuppressErrors(v) }
    fun setAutoEnterPip(v: Boolean) = viewModelScope.launch { settingsRepo.setAutoEnterPip(v) }
    fun setAudioOffload(v: Boolean) = viewModelScope.launch { settingsRepo.setAudioOffload(v) }
    fun setPauseOnAudioFocusLoss(v: Boolean) = viewModelScope.launch { settingsRepo.setPauseOnAudioFocusLoss(v) }
    fun setMuteOnStart(v: Boolean) = viewModelScope.launch { settingsRepo.setMuteOnStart(v) }
    fun setThumbnailCacheEnabled(v: Boolean) = viewModelScope.launch {
        settingsRepo.setThumbnailCacheEnabled(v)
        app.rebuildImageLoader(v)
    }
    fun updateSubtitleAppearance(appearance: SubtitleAppearance) = viewModelScope.launch {
        settingsRepo.updateSubtitleAppearance(appearance)
    }

    fun clearPlaybackHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            historyDao.clearAll()
        }
    }

    fun clearThumbnailCache() {
        viewModelScope.launch(Dispatchers.IO) {
            ThumbnailCacheManager.clearCache(app, app.currentImageLoader())
            _cacheSizeBytes.value = ThumbnailCacheManager.getCacheSizeBytes(app)
        }
    }

    fun resetAllSettings() {
        viewModelScope.launch {
            settingsRepo.resetAllSettings()
            refreshMedia()
        }
    }
}
