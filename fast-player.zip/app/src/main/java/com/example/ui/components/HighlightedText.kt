package com.example.ui.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import com.example.ui.theme.FastBlue

@Composable
fun HighlightedText(
    text: String,
    query: String,
    modifier: Modifier = Modifier,
    style: TextStyle = MaterialTheme.typography.titleSmall,
    defaultColor: Color = MaterialTheme.colorScheme.onSurface,
    highlightColor: Color = FastBlue,
    maxLines: Int = 2
) {
    val annotated = remember(text, query, highlightColor) {
        buildAnnotatedString {
            append(text)
            val q = query.trim()
            if (q.isNotEmpty()) {
                val lowerText = text.lowercase()
                val lowerQuery = q.lowercase()
                var startIndex = 0
                while (startIndex < lowerText.length) {
                    val found = lowerText.indexOf(lowerQuery, startIndex)
                    if (found < 0) break
                    addStyle(
                        style = SpanStyle(
                            color = highlightColor,
                            fontWeight = FontWeight.Bold
                        ),
                        start = found,
                        end = found + lowerQuery.length
                    )
                    startIndex = found + lowerQuery.length
                }
            }
        }
    }

    Text(
        text = annotated,
        modifier = modifier,
        style = style,
        color = defaultColor,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}
