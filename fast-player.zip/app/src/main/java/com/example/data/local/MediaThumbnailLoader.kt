package com.example.data.local

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import androidx.core.graphics.drawable.toDrawable
import coil.ImageLoader
import coil.decode.DataSource
import coil.disk.DiskCache
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.memory.MemoryCache
import coil.request.Options
import com.example.model.MediaItemModel
import kotlinx.coroutines.Dispatchers
import java.io.File

data class MediaThumbnailRequest(
    val uriString: String,
    val isAudio: Boolean,
    val albumId: Long = 0L,
    val filePath: String = ""
) {
    companion object {
        fun from(item: MediaItemModel) = MediaThumbnailRequest(
            uriString = item.uriString,
            isAudio = item.isAudio,
            albumId = item.albumId,
            filePath = item.path
        )
    }
}

class MediaThumbnailFetcher(
    private val context: Context,
    private val data: MediaThumbnailRequest,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? {
        val bitmap: Bitmap? = if (data.isAudio) {
            loadAlbumArt(data.albumId, data.uriString)
        } else {
            loadVideoThumbnail(data.uriString, data.filePath)
        }
        return bitmap?.let {
            DrawableResult(
                drawable = it.toDrawable(context.resources),
                isSampled = true,
                dataSource = DataSource.DISK
            )
        }
    }

    private fun loadVideoThumbnail(uriString: String, filePath: String): Bitmap? {
        val uri = Uri.parse(uriString)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                return context.contentResolver.loadThumbnail(uri, Size(256, 160), null)
            } catch (_: Exception) {
            }
        }
        val retriever = MediaMetadataRetriever()
        return try {
            if (filePath.isNotBlank() && File(filePath).exists()) {
                retriever.setDataSource(filePath)
            } else {
                retriever.setDataSource(context, uri)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                retriever.getScaledFrameAtTime(
                    1_000_000L,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                    256,
                    160
                )
            } else {
                val raw = retriever.getFrameAtTime(
                    1_000_000L,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                ) ?: return null
                downscaleAndRecycle(raw, 256, 160)
            }
        } catch (_: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun loadAlbumArt(albumId: Long, uriString: String): Bitmap? {
        if (albumId > 0L) {
            val artUri = ContentUris.withAppendedId(
                Uri.parse("content://media/external/audio/albumart"),
                albumId
            )
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    return context.contentResolver.loadThumbnail(artUri, Size(180, 180), null)
                }
            } catch (_: Exception) {
            }
        }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, Uri.parse(uriString))
            val bytes = retriever.embeddedPicture ?: return null
            decodeSampledBitmap(bytes, 180, 180)
        } catch (_: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun downscaleAndRecycle(src: Bitmap, reqW: Int, reqH: Int): Bitmap {
        if (src.width <= reqW && src.height <= reqH) return src
        val ratio = minOf(reqW.toFloat() / src.width, reqH.toFloat() / src.height)
        val w = (src.width * ratio).toInt().coerceAtLeast(1)
        val h = (src.height * ratio).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(src, w, h, true)
        if (scaled !== src) src.recycle()
        return scaled
    }

    private fun decodeSampledBitmap(bytes: ByteArray, reqW: Int, reqH: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var inSampleSize = 1
        val halfH = bounds.outHeight / 2
        val halfW = bounds.outWidth / 2
        while (halfH / inSampleSize >= reqH && halfW / inSampleSize >= reqW) {
            inSampleSize *= 2
        }
        val opts = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    class Factory(private val context: Context) : Fetcher.Factory<MediaThumbnailRequest> {
        override fun create(
            data: MediaThumbnailRequest,
            options: Options,
            imageLoader: ImageLoader
        ): Fetcher = MediaThumbnailFetcher(context, data, options)
    }
}

object ThumbnailCacheManager {
    private const val CACHE_DIR_NAME = "fast_player_thumbs"

    fun buildImageLoader(context: Context, diskCacheEnabled: Boolean): ImageLoader {
        val builder = ImageLoader.Builder(context)
            .components {
                add(MediaThumbnailFetcher.Factory(context.applicationContext))
            }
            .bitmapConfig(Bitmap.Config.RGB_565)
            .allowRgb565(true)
            .fetcherDispatcher(Dispatchers.IO.limitedParallelism(3))
            .memoryCache {
                MemoryCache.Builder(context)
                    .maxSizePercent(0.08)
                    .build()
            }
            .crossfade(80)

        if (diskCacheEnabled) {
            builder.diskCache {
                DiskCache.Builder()
                    .directory(File(context.cacheDir, CACHE_DIR_NAME))
                    .maxSizeBytes(32L * 1024L * 1024L)
                    .build()
            }
        } else {
            builder.diskCache(null)
        }
        return builder.build()
    }

    fun getCacheSizeBytes(context: Context): Long {
        val dir = File(context.cacheDir, CACHE_DIR_NAME)
        if (!dir.exists()) return 0L
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    fun clearCache(context: Context, imageLoader: ImageLoader?) {
        imageLoader?.memoryCache?.clear()
        val dir = File(context.cacheDir, CACHE_DIR_NAME)
        if (dir.exists()) {
            dir.deleteRecursively()
        }
    }
}
