package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppSettings
import com.example.model.EqualizerPresetState
import com.example.model.FieldVisibility
import com.example.model.FontSizeOption
import com.example.model.LayoutMode
import com.example.model.PlayerQuickButton
import com.example.model.ResumeBehavior
import com.example.model.ScreenOrientationMode
import com.example.model.SortField
import com.example.model.SortOrder
import com.example.model.SubtitleAppearance
import com.example.model.ThemeOption
import com.example.model.ViewMode
import com.example.model.ViewOptions
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "fast_player_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme_option")
        val FONT_SIZE = stringPreferencesKey("font_size_option")
        val VIEW_MODE = stringPreferencesKey("view_mode")
        val LAYOUT_MODE = stringPreferencesKey("layout_mode")
        val SORT_FIELD = stringPreferencesKey("sort_field")
        val SORT_ORDER = stringPreferencesKey("sort_order")
        val FIELD_THUMB = booleanPreferencesKey("field_thumbnail")
        val FIELD_LENGTH = booleanPreferencesKey("field_length")
        val FIELD_DATE = booleanPreferencesKey("field_date")
        val FIELD_SIZE = booleanPreferencesKey("field_size")
        val FIELD_PATH = booleanPreferencesKey("field_path")
        val FIELD_RES = booleanPreferencesKey("field_resolution")
        val FIELD_EXT = booleanPreferencesKey("field_extension")
        val SHOW_HIDDEN = booleanPreferencesKey("show_hidden_folders")
        val SHOW_NEW_BADGE = booleanPreferencesKey("show_new_badge")
        val MARK_LAST_PLAYED = booleanPreferencesKey("mark_last_played")
        val COMPACT_ROWS = booleanPreferencesKey("compact_rows")

        val AUDIO_SORT_FIELD = stringPreferencesKey("audio_sort_field")
        val AUDIO_SORT_ORDER = stringPreferencesKey("audio_sort_order")

        val DOUBLE_TAP_SEEK = intPreferencesKey("double_tap_seek_seconds")
        val FLOATING_RESUME = booleanPreferencesKey("show_floating_resume")
        val REMEMBER_POSITION = booleanPreferencesKey("remember_position")
        val RESUME_BEHAVIOR = stringPreferencesKey("resume_behavior")
        val MARK_LAST_FOLDER = booleanPreferencesKey("mark_last_played_folder")
        val SCROLL_TO_LAST = booleanPreferencesKey("scroll_to_last_media")
        val NEW_BADGE_DAYS = intPreferencesKey("new_badge_days")
        val EXCLUDED_FOLDERS = stringSetPreferencesKey("excluded_folders")

        val CONTROLS_HIDE_SEC = intPreferencesKey("controls_auto_hide_sec")
        val SHOW_BATTERY_CLOCK = booleanPreferencesKey("show_battery_clock")
        val SCREEN_ORIENTATION = stringPreferencesKey("screen_orientation")
        val DOUBLE_TAP_BACK = booleanPreferencesKey("double_tap_back_close")
        val QUICK_ZOOM = booleanPreferencesKey("quick_zoom")
        val KEEP_SCREEN_ON_VIDEO = booleanPreferencesKey("keep_screen_on_video")
        val DEFAULT_SPEED = floatPreferencesKey("default_speed")
        val REMEMBER_SELECTIONS = booleanPreferencesKey("remember_track_selections")
        val PLAY_NEXT_AUTO = booleanPreferencesKey("play_next_auto")
        val PREVIEW_SEEK = booleanPreferencesKey("preview_while_seeking")
        val FAST_SEEKING = booleanPreferencesKey("fast_seeking")
        val SMART_PREV = booleanPreferencesKey("smart_previous")
        val SUPPRESS_ERRORS = booleanPreferencesKey("suppress_errors")
        val AUTO_PIP = booleanPreferencesKey("auto_pip")
        val AUDIO_OFFLOAD = booleanPreferencesKey("audio_offload")
        val PAUSE_FOCUS_LOSS = booleanPreferencesKey("pause_audio_focus_loss")
        val MUTE_ON_START = booleanPreferencesKey("mute_on_start")
        val THUMB_CACHE = booleanPreferencesKey("thumbnail_cache_enabled")

        val SUB_ENABLED = booleanPreferencesKey("sub_enabled")
        val SUB_FONT_SIZE = floatPreferencesKey("sub_font_size")
        val SUB_COLOR = longPreferencesKey("sub_color")
        val SUB_BG_DIM = booleanPreferencesKey("sub_bg_dim")
        val SUB_BOLD = booleanPreferencesKey("sub_bold")
        val SUB_PADDING = floatPreferencesKey("sub_padding")

        val QUICK_BUTTON_ORDER = stringPreferencesKey("quick_button_order")
        val EQ_ENABLED = booleanPreferencesKey("eq_enabled")
        val EQ_PRESET = intPreferencesKey("eq_preset")
        val EQ_BANDS = stringPreferencesKey("eq_bands")
        val EQ_BASS = intPreferencesKey("eq_bass")
        val EQ_LOUDNESS = intPreferencesKey("eq_loudness")
    }

    val settingsFlow: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        val viewOptions = ViewOptions(
            viewMode = enumValueOrDefault(prefs[Keys.VIEW_MODE], ViewMode.FOLDERS_TREE),
            layoutMode = enumValueOrDefault(prefs[Keys.LAYOUT_MODE], LayoutMode.LIST),
            sortField = enumValueOrDefault(prefs[Keys.SORT_FIELD], SortField.TITLE),
            sortOrder = enumValueOrDefault(prefs[Keys.SORT_ORDER], SortOrder.ASCENDING),
            fields = FieldVisibility(
                thumbnail = prefs[Keys.FIELD_THUMB] ?: true,
                length = prefs[Keys.FIELD_LENGTH] ?: true,
                date = prefs[Keys.FIELD_DATE] ?: true,
                size = prefs[Keys.FIELD_SIZE] ?: false,
                path = prefs[Keys.FIELD_PATH] ?: false,
                resolution = prefs[Keys.FIELD_RES] ?: false,
                extension = prefs[Keys.FIELD_EXT] ?: false
            ),
            showHiddenFolders = prefs[Keys.SHOW_HIDDEN] ?: false,
            showNewBadge = prefs[Keys.SHOW_NEW_BADGE] ?: true,
            markLastPlayed = prefs[Keys.MARK_LAST_PLAYED] ?: true,
            compactRows = prefs[Keys.COMPACT_ROWS] ?: false
        )

        val buttonIds = prefs[Keys.QUICK_BUTTON_ORDER]
            ?.split(',')
            ?.filter { it.isNotBlank() }
            ?: emptyList()

        val eqBands = prefs[Keys.EQ_BANDS]
            ?.split(',')
            ?.mapNotNull { it.toIntOrNull() }
            ?: emptyList()

        AppSettings(
            themeOption = enumValueOrDefault(prefs[Keys.THEME], ThemeOption.SYSTEM),
            fontSizeOption = enumValueOrDefault(prefs[Keys.FONT_SIZE], FontSizeOption.NORMAL),
            viewOptions = viewOptions,
            audioSortField = enumValueOrDefault(prefs[Keys.AUDIO_SORT_FIELD], SortField.TITLE),
            audioSortOrder = enumValueOrDefault(prefs[Keys.AUDIO_SORT_ORDER], SortOrder.ASCENDING),
            doubleTapSeekSeconds = (prefs[Keys.DOUBLE_TAP_SEEK] ?: 10).coerceIn(1, 300),
            showFloatingResumeButton = prefs[Keys.FLOATING_RESUME] ?: true,
            rememberPosition = prefs[Keys.REMEMBER_POSITION] ?: true,
            resumeBehavior = enumValueOrDefault(prefs[Keys.RESUME_BEHAVIOR], ResumeBehavior.ALWAYS_RESUME),
            markLastPlayedInEachFolder = prefs[Keys.MARK_LAST_FOLDER] ?: true,
            scrollToLastMedia = prefs[Keys.SCROLL_TO_LAST] ?: true,
            newBadgeDays = (prefs[Keys.NEW_BADGE_DAYS] ?: 7).coerceIn(1, 90),
            excludedFolders = prefs[Keys.EXCLUDED_FOLDERS] ?: emptySet(),
            controlsAutoHideSeconds = (prefs[Keys.CONTROLS_HIDE_SEC] ?: 4).coerceIn(2, 15),
            showBatteryAndClock = prefs[Keys.SHOW_BATTERY_CLOCK] ?: true,
            screenOrientationMode = enumValueOrDefault(prefs[Keys.SCREEN_ORIENTATION], ScreenOrientationMode.AUTO_BY_VIDEO),
            doubleTapBackToClose = prefs[Keys.DOUBLE_TAP_BACK] ?: false,
            quickZoomEnabled = prefs[Keys.QUICK_ZOOM] ?: true,
            keepScreenOnVideo = prefs[Keys.KEEP_SCREEN_ON_VIDEO] ?: true,
            defaultPlaybackSpeed = (prefs[Keys.DEFAULT_SPEED] ?: 1.0f).coerceIn(0.25f, 4.0f),
            rememberTrackSelections = prefs[Keys.REMEMBER_SELECTIONS] ?: true,
            playNextAutomatically = prefs[Keys.PLAY_NEXT_AUTO] ?: true,
            previewWhileSeeking = prefs[Keys.PREVIEW_SEEK] ?: true,
            fastSeeking = prefs[Keys.FAST_SEEKING] ?: true,
            smartPreviousButton = prefs[Keys.SMART_PREV] ?: true,
            suppressErrorMessages = prefs[Keys.SUPPRESS_ERRORS] ?: false,
            autoEnterPip = prefs[Keys.AUTO_PIP] ?: true,
            audioOffload = prefs[Keys.AUDIO_OFFLOAD] ?: false,
            pauseOnAudioFocusLoss = prefs[Keys.PAUSE_FOCUS_LOSS] ?: true,
            muteOnStart = prefs[Keys.MUTE_ON_START] ?: false,
            thumbnailCacheEnabled = prefs[Keys.THUMB_CACHE] ?: true,
            subtitleAppearance = SubtitleAppearance(
                enabledByDefault = prefs[Keys.SUB_ENABLED] ?: true,
                fontSizeSp = (prefs[Keys.SUB_FONT_SIZE] ?: 18f).coerceIn(12f, 34f),
                textColorArgb = prefs[Keys.SUB_COLOR] ?: 0xFFFFFFFF,
                backgroundDim = prefs[Keys.SUB_BG_DIM] ?: true,
                boldText = prefs[Keys.SUB_BOLD] ?: false,
                bottomPaddingDp = (prefs[Keys.SUB_PADDING] ?: 36f).coerceIn(12f, 120f)
            ),
            quickButtonOrder = if (buttonIds.isEmpty()) PlayerQuickButton.defaultOrder else PlayerQuickButton.fromIds(buttonIds),
            equalizerState = EqualizerPresetState(
                enabled = prefs[Keys.EQ_ENABLED] ?: false,
                selectedPresetIndex = prefs[Keys.EQ_PRESET] ?: 0,
                bandLevelsMb = eqBands,
                bassBoostStrength = prefs[Keys.EQ_BASS] ?: 0,
                loudnessGainMb = prefs[Keys.EQ_LOUDNESS] ?: 0
            )
        )
    }

    suspend fun updateViewOptions(options: ViewOptions) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.VIEW_MODE] = options.viewMode.name
            prefs[Keys.LAYOUT_MODE] = options.layoutMode.name
            prefs[Keys.SORT_FIELD] = options.sortField.name
            prefs[Keys.SORT_ORDER] = options.sortOrder.name
            prefs[Keys.FIELD_THUMB] = options.fields.thumbnail
            prefs[Keys.FIELD_LENGTH] = options.fields.length
            prefs[Keys.FIELD_DATE] = options.fields.date
            prefs[Keys.FIELD_SIZE] = options.fields.size
            prefs[Keys.FIELD_PATH] = options.fields.path
            prefs[Keys.FIELD_RES] = options.fields.resolution
            prefs[Keys.FIELD_EXT] = options.fields.extension
            prefs[Keys.SHOW_HIDDEN] = options.showHiddenFolders
            prefs[Keys.SHOW_NEW_BADGE] = options.showNewBadge
            prefs[Keys.MARK_LAST_PLAYED] = options.markLastPlayed
            prefs[Keys.COMPACT_ROWS] = options.compactRows
        }
    }

    suspend fun updateTheme(theme: ThemeOption) {
        context.settingsDataStore.edit { it[Keys.THEME] = theme.name }
    }

    suspend fun updateFontSize(size: FontSizeOption) {
        context.settingsDataStore.edit { it[Keys.FONT_SIZE] = size.name }
    }

    suspend fun updateAudioSort(field: SortField, order: SortOrder) {
        context.settingsDataStore.edit {
            it[Keys.AUDIO_SORT_FIELD] = field.name
            it[Keys.AUDIO_SORT_ORDER] = order.name
        }
    }

    suspend fun updateDoubleTapSeekSeconds(seconds: Int) {
        context.settingsDataStore.edit { it[Keys.DOUBLE_TAP_SEEK] = seconds.coerceIn(1, 300) }
    }

    suspend fun updateQuickSetting(block: suspend (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.settingsDataStore.edit { block(it) }
    }

    suspend fun setBoolean(key: Preferences.Key<Boolean>, value: Boolean) {
        context.settingsDataStore.edit { it[key] = value }
    }

    suspend fun setShowFloatingResume(value: Boolean) = setBoolean(Keys.FLOATING_RESUME, value)
    suspend fun setRememberPosition(value: Boolean) = setBoolean(Keys.REMEMBER_POSITION, value)
    suspend fun setResumeBehavior(value: ResumeBehavior) {
        context.settingsDataStore.edit { it[Keys.RESUME_BEHAVIOR] = value.name }
    }
    suspend fun setMarkLastPlayedFolder(value: Boolean) = setBoolean(Keys.MARK_LAST_FOLDER, value)
    suspend fun setScrollToLastMedia(value: Boolean) = setBoolean(Keys.SCROLL_TO_LAST, value)
    suspend fun setNewBadgeDays(days: Int) {
        context.settingsDataStore.edit { it[Keys.NEW_BADGE_DAYS] = days.coerceIn(1, 90) }
    }
    suspend fun setExcludedFolders(folders: Set<String>) {
        context.settingsDataStore.edit { it[Keys.EXCLUDED_FOLDERS] = folders }
    }
    suspend fun setShowHiddenFolders(value: Boolean) = setBoolean(Keys.SHOW_HIDDEN, value)
    suspend fun setControlsAutoHideSeconds(sec: Int) {
        context.settingsDataStore.edit { it[Keys.CONTROLS_HIDE_SEC] = sec.coerceIn(2, 15) }
    }
    suspend fun setShowBatteryAndClock(value: Boolean) = setBoolean(Keys.SHOW_BATTERY_CLOCK, value)
    suspend fun setScreenOrientation(mode: ScreenOrientationMode) {
        context.settingsDataStore.edit { it[Keys.SCREEN_ORIENTATION] = mode.name }
    }
    suspend fun setDoubleTapBackToClose(value: Boolean) = setBoolean(Keys.DOUBLE_TAP_BACK, value)
    suspend fun setQuickZoomEnabled(value: Boolean) = setBoolean(Keys.QUICK_ZOOM, value)
    suspend fun setKeepScreenOnVideo(value: Boolean) = setBoolean(Keys.KEEP_SCREEN_ON_VIDEO, value)
    suspend fun setDefaultSpeed(speed: Float) {
        context.settingsDataStore.edit { it[Keys.DEFAULT_SPEED] = speed.coerceIn(0.25f, 4.0f) }
    }
    suspend fun setRememberTrackSelections(value: Boolean) = setBoolean(Keys.REMEMBER_SELECTIONS, value)
    suspend fun setPlayNextAutomatically(value: Boolean) = setBoolean(Keys.PLAY_NEXT_AUTO, value)
    suspend fun setPreviewWhileSeeking(value: Boolean) = setBoolean(Keys.PREVIEW_SEEK, value)
    suspend fun setFastSeeking(value: Boolean) = setBoolean(Keys.FAST_SEEKING, value)
    suspend fun setSmartPrevious(value: Boolean) = setBoolean(Keys.SMART_PREV, value)
    suspend fun setSuppressErrors(value: Boolean) = setBoolean(Keys.SUPPRESS_ERRORS, value)
    suspend fun setAutoEnterPip(value: Boolean) = setBoolean(Keys.AUTO_PIP, value)
    suspend fun setAudioOffload(value: Boolean) = setBoolean(Keys.AUDIO_OFFLOAD, value)
    suspend fun setPauseOnAudioFocusLoss(value: Boolean) = setBoolean(Keys.PAUSE_FOCUS_LOSS, value)
    suspend fun setMuteOnStart(value: Boolean) = setBoolean(Keys.MUTE_ON_START, value)
    suspend fun setThumbnailCacheEnabled(value: Boolean) = setBoolean(Keys.THUMB_CACHE, value)

    suspend fun updateSubtitleAppearance(appearance: SubtitleAppearance) {
        context.settingsDataStore.edit {
            it[Keys.SUB_ENABLED] = appearance.enabledByDefault
            it[Keys.SUB_FONT_SIZE] = appearance.fontSizeSp
            it[Keys.SUB_COLOR] = appearance.textColorArgb
            it[Keys.SUB_BG_DIM] = appearance.backgroundDim
            it[Keys.SUB_BOLD] = appearance.boldText
            it[Keys.SUB_PADDING] = appearance.bottomPaddingDp
        }
    }

    suspend fun updateQuickButtonOrder(order: List<PlayerQuickButton>) {
        context.settingsDataStore.edit {
            it[Keys.QUICK_BUTTON_ORDER] = order.joinToString(",") { btn -> btn.id }
        }
    }

    suspend fun updateEqualizerState(state: EqualizerPresetState) {
        context.settingsDataStore.edit {
            it[Keys.EQ_ENABLED] = state.enabled
            it[Keys.EQ_PRESET] = state.selectedPresetIndex
            it[Keys.EQ_BANDS] = state.bandLevelsMb.joinToString(",")
            it[Keys.EQ_BASS] = state.bassBoostStrength
            it[Keys.EQ_LOUDNESS] = state.loudnessGainMb
        }
    }

    suspend fun resetAllSettings() {
        context.settingsDataStore.edit { it.clear() }
    }

    private inline fun <reified T : Enum<T>> enumValueOrDefault(raw: String?, default: T): T {
        if (raw.isNullOrBlank()) return default
        return enumValues<T>().firstOrNull { it.name == raw } ?: default
    }
}
