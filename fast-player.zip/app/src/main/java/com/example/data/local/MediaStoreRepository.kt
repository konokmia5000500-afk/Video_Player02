package com.example.data.local

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.model.MediaFolder
import com.example.model.MediaItemModel
import com.example.model.SortField
import com.example.model.SortOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MediaStoreRepository(private val context: Context) {

    suspend fun scanVideos(
        newBadgeDays: Int,
        showHiddenFolders: Boolean,
        excludedFolders: Set<String>
    ): List<MediaItemModel> = withContext(Dispatchers.IO) {
        val result = ArrayList<MediaItemModel>(128)
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.MIME_TYPE
        )

        val nowSec = System.currentTimeMillis() / 1000L
        val newThresholdSec = nowSec - (newBadgeDays * 86400L)

        try {
            context.contentResolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val modCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val wCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val hCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val path = cursor.getString(dataCol) ?: continue
                    val file = File(path)
                    val folderPath = file.parent ?: "/storage/emulated/0"
                    val folderName = file.parentFile?.name?.ifBlank { "Internal Storage" } ?: "Internal Storage"

                    if (!showHiddenFolders && isHiddenPath(path)) continue
                    if (folderPath in excludedFolders) continue

                    val displayName = cursor.getString(nameCol) ?: file.name
                    val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                        ?: displayName.substringBeforeLast('.')
                    val uri = ContentUris.withAppendedId(collection, id).toString()
                    val dateAdded = cursor.getLong(addedCol)

                    result.add(
                        MediaItemModel(
                            id = id,
                            uriString = uri,
                            title = title,
                            displayName = displayName,
                            path = path,
                            folderPath = folderPath,
                            folderName = folderName,
                            durationMs = cursor.getLong(durCol).coerceAtLeast(0L),
                            sizeBytes = cursor.getLong(sizeCol).coerceAtLeast(0L),
                            dateAddedSec = dateAdded,
                            dateModifiedSec = cursor.getLong(modCol),
                            width = cursor.getInt(wCol),
                            height = cursor.getInt(hCol),
                            mimeType = cursor.getString(mimeCol) ?: "video/*",
                            isAudio = false,
                            isNew = dateAdded >= newThresholdSec
                        )
                    )
                }
            }
        } catch (_: SecurityException) {
            // Permission not granted yet
        } catch (_: Exception) {
            // Ignore malformed rows
        }
        result
    }

    suspend fun scanAudio(
        newBadgeDays: Int,
        showHiddenFolders: Boolean,
        excludedFolders: Set<String>
    ): List<MediaItemModel> = withContext(Dispatchers.IO) {
        val result = ArrayList<MediaItemModel>(128)
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID
        )

        val nowSec = System.currentTimeMillis() / 1000L
        val newThresholdSec = nowSec - (newBadgeDays * 86400L)

        try {
            context.contentResolver.query(
                collection,
                projection,
                "${MediaStore.Audio.Media.IS_MUSIC} != 0 OR ${MediaStore.Audio.Media.DURATION} > 5000",
                null,
                "${MediaStore.Audio.Media.TITLE} ASC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val modCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val path = cursor.getString(dataCol) ?: continue
                    val file = File(path)
                    val folderPath = file.parent ?: "/storage/emulated/0"
                    val folderName = file.parentFile?.name?.ifBlank { "Music" } ?: "Music"

                    if (!showHiddenFolders && isHiddenPath(path)) continue
                    if (folderPath in excludedFolders) continue

                    val displayName = cursor.getString(nameCol) ?: file.name
                    val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                        ?: displayName.substringBeforeLast('.')
                    val uri = ContentUris.withAppendedId(collection, id).toString()
                    val dateAdded = cursor.getLong(addedCol)

                    result.add(
                        MediaItemModel(
                            id = id,
                            uriString = uri,
                            title = title,
                            displayName = displayName,
                            path = path,
                            folderPath = folderPath,
                            folderName = folderName,
                            durationMs = cursor.getLong(durCol).coerceAtLeast(0L),
                            sizeBytes = cursor.getLong(sizeCol).coerceAtLeast(0L),
                            dateAddedSec = dateAdded,
                            dateModifiedSec = cursor.getLong(modCol),
                            mimeType = cursor.getString(mimeCol) ?: "audio/*",
                            isAudio = true,
                            artist = cursor.getString(artistCol)?.takeUnless { it == "<unknown>" },
                            album = cursor.getString(albumCol)?.takeUnless { it == "<unknown>" },
                            albumId = cursor.getLong(albumIdCol),
                            isNew = dateAdded >= newThresholdSec
                        )
                    )
                }
            }
        } catch (_: SecurityException) {
            // Permission not granted yet
        } catch (_: Exception) {
            // Ignore malformed rows
        }
        result
    }

    suspend fun discoverAllVideoFolders(showHiddenFolders: Boolean): List<Pair<String, Int>> =
        withContext(Dispatchers.IO) {
            val counts = linkedMapOf<String, Int>()
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }
            try {
                context.contentResolver.query(
                    collection,
                    arrayOf(MediaStore.Video.Media.DATA),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                    while (cursor.moveToNext()) {
                        val path = cursor.getString(dataCol) ?: continue
                        if (!showHiddenFolders && isHiddenPath(path)) continue
                        val folder = File(path).parent ?: continue
                        counts[folder] = (counts[folder] ?: 0) + 1
                    }
                }
            } catch (_: Exception) {
            }
            counts.entries.sortedBy { it.key.lowercase() }.map { it.key to it.value }
        }

    fun resolveExternalUri(uri: Uri): MediaItemModel {
        val resolver = context.contentResolver
        var displayName = uri.lastPathSegment ?: "External Media"
        var size = 0L
        var duration = 0L
        val mime = resolver.getType(uri) ?: ""
        try {
            resolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val nameIdx = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                    if (nameIdx >= 0) displayName = c.getString(nameIdx) ?: displayName
                    val sizeIdx = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
                    if (sizeIdx >= 0) size = c.getLong(sizeIdx)
                    val durIdx = c.getColumnIndex("duration")
                    if (durIdx >= 0) duration = c.getLong(durIdx)
                }
            }
        } catch (_: Exception) {
        }
        val isAudio = mime.startsWith("audio/")
        return MediaItemModel(
            id = uri.toString().hashCode().toLong(),
            uriString = uri.toString(),
            title = displayName.substringBeforeLast('.'),
            displayName = displayName,
            path = uri.path ?: displayName,
            folderPath = "External",
            folderName = "External",
            durationMs = duration,
            sizeBytes = size,
            dateAddedSec = System.currentTimeMillis() / 1000L,
            dateModifiedSec = System.currentTimeMillis() / 1000L,
            mimeType = mime.ifBlank { if (isAudio) "audio/*" else "video/*" },
            isAudio = isAudio
        )
    }

    private fun isHiddenPath(path: String): Boolean {
        val segments = path.split('/')
        return segments.any { it.startsWith(".") && it.length > 1 }
    }

    companion object {
        fun sortMedia(
            items: List<MediaItemModel>,
            field: SortField,
            order: SortOrder
        ): List<MediaItemModel> {
            val comparator = when (field) {
                SortField.TITLE -> compareBy<MediaItemModel> { it.title.lowercase() }
                SortField.DATE -> compareBy<MediaItemModel> { it.dateAddedSec }
                SortField.SIZE -> compareBy<MediaItemModel> { it.sizeBytes }
                SortField.LENGTH -> compareBy<MediaItemModel> { it.durationMs }
                SortField.PATH -> compareBy<MediaItemModel> { it.path.lowercase() }
                SortField.TYPE -> compareBy<MediaItemModel> { it.extension.lowercase() }.thenBy { it.title.lowercase() }
            }
            val sorted = items.sortedWith(comparator)
            return if (order == SortOrder.DESCENDING) sorted.reversed() else sorted
        }

        fun sortFolders(
            folders: List<MediaFolder>,
            field: SortField,
            order: SortOrder
        ): List<MediaFolder> {
            val comparator = when (field) {
                SortField.TITLE, SortField.TYPE -> compareBy<MediaFolder> { it.name.lowercase() }
                SortField.DATE -> compareBy<MediaFolder> { it.latestDateAddedSec }
                SortField.SIZE -> compareBy<MediaFolder> { it.totalSizeBytes }
                SortField.LENGTH -> compareBy<MediaFolder> { it.videoCount }
                SortField.PATH -> compareBy<MediaFolder> { it.path.lowercase() }
            }
            val sorted = folders.sortedWith(comparator)
            return if (order == SortOrder.DESCENDING) sorted.reversed() else sorted
        }

        fun buildAllFolders(
            videos: List<MediaItemModel>,
            lastPlayedFolderPath: String?,
            markLastPlayed: Boolean
        ): List<MediaFolder> {
            return videos.groupBy { it.folderPath }.map { (folderPath, items) ->
                val sample = items.first()
                MediaFolder(
                    path = folderPath,
                    name = sample.folderName,
                    parentPath = File(folderPath).parent ?: "",
                    videoCount = items.size,
                    subfolderCount = 0,
                    latestDateAddedSec = items.maxOf { it.dateAddedSec },
                    hasNewMedia = items.any { it.isNew },
                    isLastPlayedFolder = markLastPlayed && folderPath == lastPlayedFolderPath,
                    totalSizeBytes = items.sumOf { it.sizeBytes }
                )
            }
        }

        fun buildTreeChildren(
            videos: List<MediaItemModel>,
            currentTreePath: String?,
            lastPlayedFolderPath: String?,
            markLastPlayed: Boolean
        ): Pair<List<MediaFolder>, List<MediaItemModel>> {
            if (videos.isEmpty()) return emptyList<MediaFolder>() to emptyList()

            val baseRoot = currentTreePath ?: findCommonStorageRoot(videos)
            val normalizedRoot = baseRoot.trimEnd('/')

            val directVideos = videos.filter { it.folderPath.trimEnd('/') == normalizedRoot }
            val descendantVideos = videos.filter {
                val fp = it.folderPath.trimEnd('/')
                fp.startsWith("$normalizedRoot/")
            }

            val childBuckets = linkedMapOf<String, MutableList<MediaItemModel>>()
            for (v in descendantVideos) {
                val fp = v.folderPath.trimEnd('/')
                val rel = fp.removePrefix("$normalizedRoot/")
                val nextSeg = rel.substringBefore('/')
                val childPath = "$normalizedRoot/$nextSeg"
                childBuckets.getOrPut(childPath) { mutableListOf() }.add(v)
            }

            val childFolders = childBuckets.map { (childPath, items) ->
                val directSubfolders = items
                    .map { it.folderPath.trimEnd('/') }
                    .filter { it != childPath && it.startsWith("$childPath/") }
                    .map { it.removePrefix("$childPath/").substringBefore('/') }
                    .distinct()
                    .size

                MediaFolder(
                    path = childPath,
                    name = File(childPath).name.ifBlank { childPath },
                    parentPath = normalizedRoot,
                    videoCount = items.size,
                    subfolderCount = directSubfolders,
                    latestDateAddedSec = items.maxOf { it.dateAddedSec },
                    hasNewMedia = items.any { it.isNew },
                    isLastPlayedFolder = markLastPlayed && (
                        lastPlayedFolderPath?.trimEnd('/') == childPath ||
                            lastPlayedFolderPath?.trimEnd('/')?.startsWith("$childPath/") == true
                        ),
                    totalSizeBytes = items.sumOf { it.sizeBytes }
                )
            }

            return childFolders to directVideos
        }

        fun findCommonStorageRoot(videos: List<MediaItemModel>): String {
            val paths = videos.map { it.folderPath.trimEnd('/') }.distinct()
            if (paths.isEmpty()) return "/storage/emulated/0"
            if (paths.size == 1) {
                return File(paths.first()).parent ?: paths.first()
            }
            val splitPaths = paths.map { it.split('/').filter { seg -> seg.isNotEmpty() } }
            val minLen = splitPaths.minOf { it.size }
            val common = mutableListOf<String>()
            for (i in 0 until minLen) {
                val candidate = splitPaths[0][i]
                if (splitPaths.all { it[i] == candidate }) {
                    common.add(candidate)
                } else {
                    break
                }
            }
            return if (common.isEmpty()) "/storage/emulated/0" else "/" + common.joinToString("/")
        }

        data class SearchResultGroup(
            val directMatches: List<MediaItemModel>,
            val relatedMatches: List<MediaItemModel>
        )

        fun searchMediaWithRelated(
            pool: List<MediaItemModel>,
            query: String
        ): SearchResultGroup {
            val trimmed = query.trim()
            if (trimmed.isEmpty()) return SearchResultGroup(emptyList(), emptyList())
            val qLower = trimmed.lowercase()

            val direct = pool.filter {
                it.title.lowercase().contains(qLower) ||
                    it.displayName.lowercase().contains(qLower)
            }
            val directUris = direct.mapTo(HashSet()) { it.uriString }

            val tokens = qLower.split(Regex("\\s+")).filter { it.length >= 2 }
            val directFolders = direct.mapTo(HashSet()) { it.folderPath }
            val directArtists = direct.mapNotNullTo(HashSet()) { it.artist?.lowercase() }

            val related = pool.filter { item ->
                if (item.uriString in directUris) return@filter false
                val titleLower = item.title.lowercase()
                val tokenHit = tokens.any { tok -> titleLower.contains(tok) }
                val folderHit = item.folderPath in directFolders
                val artistHit = item.artist?.lowercase() in directArtists ||
                    (item.artist?.lowercase()?.contains(qLower) == true)
                tokenHit || folderHit || artistHit
            }

            return SearchResultGroup(directMatches = direct, relatedMatches = related)
        }
    }
}
