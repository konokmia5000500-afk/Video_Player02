package com.example.model

import androidx.compose.runtime.Immutable

@Immutable
data class MediaItemModel(
    val id: Long,
    val uriString: String,
    val title: String,
    val displayName: String,
    val path: String,
    val folderPath: String,
    val folderName: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAddedSec: Long,
    val dateModifiedSec: Long,
    val width: Int = 0,
    val height: Int = 0,
    val mimeType: String = "",
    val isAudio: Boolean = false,
    val artist: String? = null,
    val album: String? = null,
    val albumId: Long = 0L,
    val isNew: Boolean = false,
    val isLastPlayed: Boolean = false,
    val lastPositionMs: Long = 0L
) {
    val extension: String
        get() = displayName.substringAfterLast('.', "").uppercase()

    val resolutionLabel: String
        get() = if (width > 0 && height > 0) "${width}×${height}" else ""
}

@Immutable
data class MediaFolder(
    val path: String,
    val name: String,
    val parentPath: String,
    val videoCount: Int,
    val subfolderCount: Int = 0,
    val latestDateAddedSec: Long = 0L,
    val hasNewMedia: Boolean = false,
    val isLastPlayedFolder: Boolean = false,
    val totalSizeBytes: Long = 0L
)

@Immutable
data class PlaylistModel(
    val id: Long,
    val name: String,
    val itemCount: Int,
    val createdAt: Long
)

@Immutable
data class PlaylistEntryModel(
    val entryId: Long,
    val playlistId: Long,
    val mediaUri: String,
    val title: String,
    val folderPath: String,
    val isAudio: Boolean,
    val durationMs: Long,
    val sizeBytes: Long,
    val artist: String?,
    val albumId: Long,
    val positionOrder: Int
)

enum class MainTab {
    VIDEO, AUDIO, PLAYLIST, ME
}

enum class ViewMode(val label: String) {
    ALL_FOLDERS("All folders"),
    FILES("Files"),
    FOLDERS_TREE("Folders tree")
}

enum class LayoutMode(val label: String) {
    LIST("List"),
    GRID("Grid")
}

enum class SortField(val label: String) {
    TITLE("Title"),
    DATE("Date"),
    SIZE("Size"),
    LENGTH("Length"),
    PATH("Path"),
    TYPE("Type")
}

enum class SortOrder(val label: String) {
    ASCENDING("Ascending"),
    DESCENDING("Descending")
}

@Immutable
data class FieldVisibility(
    val thumbnail: Boolean = true,
    val length: Boolean = true,
    val date: Boolean = true,
    val size: Boolean = false,
    val path: Boolean = false,
    val resolution: Boolean = false,
    val extension: Boolean = false
)

@Immutable
data class ViewOptions(
    val viewMode: ViewMode = ViewMode.FOLDERS_TREE,
    val layoutMode: LayoutMode = LayoutMode.LIST,
    val sortField: SortField = SortField.TITLE,
    val sortOrder: SortOrder = SortOrder.ASCENDING,
    val fields: FieldVisibility = FieldVisibility(),
    val showHiddenFolders: Boolean = false,
    val showNewBadge: Boolean = true,
    val markLastPlayed: Boolean = true,
    val compactRows: Boolean = false
)

enum class ThemeOption(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark"),
    PURE_BLACK("Pure Black"),
    OCEAN_BLUE("Ocean Blue")
}

enum class FontSizeOption(val label: String, val scale: Float) {
    SMALL("Small", 0.88f),
    NORMAL("Normal", 1.0f),
    LARGE("Large", 1.14f),
    EXTRA_LARGE("Extra Large", 1.28f)
}

enum class ResumeBehavior(val label: String) {
    ALWAYS_RESUME("Always resume"),
    ASK("Ask before resuming"),
    START_OVER("Always start from beginning")
}

enum class ScreenOrientationMode(val label: String) {
    AUTO_BY_VIDEO("Auto (based on video size)"),
    SENSOR("Auto-rotate (sensor)"),
    LANDSCAPE("Landscape"),
    PORTRAIT("Portrait")
}

enum class AspectRatioMode(val label: String) {
    FIT("Fit"),
    FILL("Fill"),
    CROP("Crop"),
    RATIO_16_9("16:9"),
    RATIO_4_3("4:3"),
    STRETCH("Stretch")
}

enum class PlayerQuickButton(val id: String, val label: String) {
    NIGHT_MODE("night_mode", "Night mode"),
    CUSTOMISE("customise", "Customise items"),
    SHUFFLE("shuffle", "Shuffle"),
    LOOP("loop", "Loop"),
    MUTE("mute", "Mute"),
    SLEEP_TIMER("sleep_timer", "Sleep timer"),
    AB_REPEAT("ab_repeat", "A-B repeat"),
    AUDIO_EFFECT("audio_effect", "Audio effect"),
    EQUALIZER("equalizer", "Equalizer"),
    SPEED("speed", "Speed"),
    SCREENSHOT("screenshot", "Screenshot"),
    BACKGROUND_PLAY("background_play", "Background play"),
    ROTATION("rotation", "Screen rotation");

    companion object {
        val defaultOrder: List<PlayerQuickButton> = entries.toList()
        fun fromIds(ids: List<String>): List<PlayerQuickButton> {
            val mapped = ids.mapNotNull { id -> entries.find { it.id == id } }
            val missing = entries.filter { it !in mapped }
            return mapped + missing
        }
    }
}

@Immutable
data class SubtitleAppearance(
    val enabledByDefault: Boolean = true,
    val fontSizeSp: Float = 18f,
    val textColorArgb: Long = 0xFFFFFFFF,
    val backgroundDim: Boolean = true,
    val boldText: Boolean = false,
    val bottomPaddingDp: Float = 36f
)

@Immutable
data class EqualizerPresetState(
    val enabled: Boolean = false,
    val selectedPresetIndex: Int = 0,
    val bandLevelsMb: List<Int> = emptyList(),
    val bassBoostStrength: Int = 0,
    val loudnessGainMb: Int = 0
)

@Immutable
data class AppSettings(
    val themeOption: ThemeOption = ThemeOption.SYSTEM,
    val fontSizeOption: FontSizeOption = FontSizeOption.NORMAL,
    val viewOptions: ViewOptions = ViewOptions(),
    val audioSortField: SortField = SortField.TITLE,
    val audioSortOrder: SortOrder = SortOrder.ASCENDING,
    val doubleTapSeekSeconds: Int = 10,
    val showFloatingResumeButton: Boolean = true,
    val rememberPosition: Boolean = true,
    val resumeBehavior: ResumeBehavior = ResumeBehavior.ALWAYS_RESUME,
    val markLastPlayedInEachFolder: Boolean = true,
    val scrollToLastMedia: Boolean = true,
    val newBadgeDays: Int = 7,
    val excludedFolders: Set<String> = emptySet(),
    val controlsAutoHideSeconds: Int = 4,
    val showBatteryAndClock: Boolean = true,
    val screenOrientationMode: ScreenOrientationMode = ScreenOrientationMode.AUTO_BY_VIDEO,
    val doubleTapBackToClose: Boolean = false,
    val quickZoomEnabled: Boolean = true,
    val keepScreenOnVideo: Boolean = true,
    val defaultPlaybackSpeed: Float = 1.0f,
    val rememberTrackSelections: Boolean = true,
    val playNextAutomatically: Boolean = true,
    val previewWhileSeeking: Boolean = true,
    val fastSeeking: Boolean = true,
    val smartPreviousButton: Boolean = true,
    val suppressErrorMessages: Boolean = false,
    val autoEnterPip: Boolean = true,
    val audioOffload: Boolean = false,
    val pauseOnAudioFocusLoss: Boolean = true,
    val muteOnStart: Boolean = false,
    val thumbnailCacheEnabled: Boolean = true,
    val subtitleAppearance: SubtitleAppearance = SubtitleAppearance(),
    val quickButtonOrder: List<PlayerQuickButton> = PlayerQuickButton.defaultOrder,
    val equalizerState: EqualizerPresetState = EqualizerPresetState()
)

@Immutable
data class TrackInfo(
    val groupIndex: Int,
    val trackIndex: Int,
    val label: String,
    val language: String?,
    val isSelected: Boolean,
    val details: String = ""
)

@Immutable
data class LastPlayedSummary(
    val mediaUri: String,
    val title: String,
    val folderPath: String,
    val isAudio: Boolean,
    val positionMs: Long,
    val durationMs: Long
)
