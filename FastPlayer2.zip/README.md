# Fast Player v1.2 (MX Player-style) - Kotlin + Jetpack Compose + Media3
Upload FastPlayer2.zip to GitHub, add .github/workflows/build.yml, run the workflow, download the single APK from Releases.
