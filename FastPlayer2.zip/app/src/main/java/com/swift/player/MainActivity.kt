package com.swift.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Root() }
            }
        }
    }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    fun ok() = perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }
    var granted by remember { mutableStateOf(ok()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = ok() }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(perms) }
    LaunchedEffect(granted) {
        if (granted && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    if (granted) Home() else Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Storage permission is needed to find your videos and audio.")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { launcher.launch(perms) }) { Text("Grant permission") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Home() {
    val ctx = LocalContext.current
    val act = ctx as ComponentActivity
    var tab by remember { mutableIntStateOf(0) }
    var videos by remember { mutableStateOf<List<Media>>(emptyList()) }
    var audios by remember { mutableStateOf<List<Media>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    val vNav = remember { LibNav() }
    val aNav = remember { LibNav() }
    var plOpen by remember { mutableStateOf<String?>(null) }
    var settingsPage by remember { mutableStateOf<String?>(null) }
    var createDlg by remember { mutableStateOf(false) }
    var viewDlg by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val loader = remember {
        ImageLoader.Builder(ctx)
            .components { add(VideoFrameDecoder.Factory()) }
            .memoryCache { MemoryCache.Builder(ctx).maxSizePercent(0.12).build() }
            .diskCache { DiskCache.Builder().directory(ctx.cacheDir.resolve("thumbs")).maxSizeBytes(40L * 1024 * 1024).build() }
            .build().also { Img.loader = it }
    }

    DisposableEffect(Unit) {
        val skip = booleanArrayOf(true)
        val o = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) { if (skip[0]) skip[0] = false else reload++ }
        }
        act.lifecycle.addObserver(o)
        onDispose { act.lifecycle.removeObserver(o) }
    }
    LaunchedEffect(reload) {
        withContext(Dispatchers.IO) {
            videos = MediaRepo.load(ctx, false)
            audios = MediaRepo.load(ctx, true)
        }
        LibCache.paths = (videos + audios).map { it.path }.distinct().sorted()
        loaded = true
    }
    LaunchedEffect(tab, vNav.key(), aNav.key(), plOpen, settingsPage) { searching = false; query = "" }
    LaunchedEffect(Prefs.viewMode) { vNav.reset(); aNav.reset() }

    val nav = if (tab == 0) vNav else aNav
    val inFolder = (tab < 2 && nav.inside()) || (tab == 2 && plOpen != null) || (tab == 3 && settingsPage != null)
    fun goBack() {
        when (tab) {
            0, 1 -> nav.back()
            2 -> plOpen = null
            else -> settingsPage = if (settingsPage == "main") null else "main"
        }
    }
    BackHandler(enabled = searching || inFolder) {
        if (searching) { searching = false; query = "" } else goBack()
    }
    val rootName = if (Prefs.viewMode == "all") "Folders" else if (tab == 0) "Videos" else "Audio"
    val title = when (tab) {
        0, 1 -> nav.open?.let { leafName(it) } ?: nav.tree.lastOrNull() ?: rootName
        2 -> plOpen ?: "Playlists"
        else -> when (settingsPage) {
            null -> "Me"; "main" -> "Settings"; "list" -> "List"; "player" -> "Player"
            "audio" -> "Audio"; "subtitle" -> "Subtitle"; else -> "General"
        }
    }
    val navKey = "$tab|${vNav.key()}|${aNav.key()}|$plOpen|$settingsPage|${Prefs.viewMode}|${Prefs.layout}"

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (searching) SearchField(query) { query = it }
                    else Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = {
                    if (searching) IconButton(onClick = { searching = false; query = "" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Close search") }
                    else if (inFolder) IconButton(onClick = { goBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                actions = {
                    if (searching) {
                        if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, "Clear") }
                    } else {
                        if (tab < 2) IconButton(onClick = {
                            Prefs.viewMode = when (Prefs.viewMode) { "folders" -> "all"; "all" -> "files"; else -> "folders" }
                            Prefs.save()
                        }) {
                            Icon(
                                when (Prefs.viewMode) { "all" -> Icons.Default.FolderOpen; "files" -> Icons.Default.Description; else -> Icons.Default.Folder },
                                "View mode"
                            )
                        }
                        if (tab != 3) IconButton(onClick = { searching = true }) { Icon(Icons.Default.Search, "Search") }
                        if (tab < 2) IconButton(onClick = { viewDlg = true }) { Icon(Icons.Default.Dashboard, "View options") }
                        if (tab == 2 && plOpen == null) IconButton(onClick = { createDlg = true }) { Icon(Icons.Default.Add, "New playlist") }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf("Video" to Icons.Default.Folder, "Audio" to Icons.Default.MusicNote,
                    "Playlist" to Icons.Default.QueueMusic, "Me" to Icons.Default.Person
                ).forEachIndexed { i, (l, ic) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, l) }, label = { Text(l) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(
                targetState = navKey,
                transitionSpec = { (fadeIn(tween(160)) + slideInHorizontally(tween(180)) { it / 10 }) togetherWith fadeOut(tween(90)) },
                label = "nav"
            ) { _ ->
                when (tab) {
                    0 -> Library(videos, vNav, loader, query, loaded, false)
                    1 -> Library(audios, aNav, loader, query, loaded, true)
                    2 -> PlaylistScreen(plOpen, query) { plOpen = it }
                    else -> SettingsHost(settingsPage) { settingsPage = it }
                }
            }
            AnimatedVisibility(
                visible = tab != 3 && Prefs.floatBtn && Prefs.lastUri.isNotEmpty(),
                modifier = Modifier.align(Alignment.BottomEnd),
                enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()
            ) {
                Box(
                    Modifier.padding(16.dp).size(64.dp)
                        .shadow(8.dp, CircleShape).clip(CircleShape)
                        .clickable { launchPlayer(ctx, listOf(QItem(Prefs.lastUri, Prefs.lastTitle, Prefs.lastAudio)), 0) }
                ) {
                    Image(painterResource(R.drawable.resume_logo), "Resume last", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
            }
        }
    }
    if (viewDlg) ViewDialog { viewDlg = false }
    if (createDlg) NameDialog("New playlist", { createDlg = false }) { Prefs.plCreate(it) }
}

@Composable
fun SearchField(q: String, onChange: (String) -> Unit) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    TextField(
        value = q, onValueChange = onChange, singleLine = true,
        placeholder = { Text("Search by name") },
        modifier = Modifier.fillMaxWidth().focusRequester(fr),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
        )
    )
}

@Composable
fun NameDialog(title: String, onClose: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose, title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, singleLine = true, label = { Text("Name") }) },
        confirmButton = { TextButton(onClick = { onOk(t); onClose() }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun Empty(msg: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant) }
}

@Composable
fun AddToPlaylistDialog(m: Media, onClose: () -> Unit) {
    val tick = Prefs.playlistTick
    val names = remember(tick) { Prefs.plNames() }
    var nn by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Add to playlist") },
        text = {
            Column {
                names.forEach { n ->
                    Text(n, Modifier.fillMaxWidth().clickable { Prefs.plAdd(n, m.uri.toString(), m.title); onClose() }.padding(vertical = 12.dp))
                }
                OutlinedTextField(nn, { nn = it }, singleLine = true, label = { Text("New playlist") })
            }
        },
        confirmButton = {
            TextButton(onClick = { if (nn.isNotBlank()) { Prefs.plCreate(nn); Prefs.plAdd(nn.trim(), m.uri.toString(), m.title) }; onClose() }) { Text("Create & add") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun PlaylistScreen(open: String?, query: String, onOpen: (String?) -> Unit) {
    val ctx = LocalContext.current
    val tick = Prefs.playlistTick
    val q = query.trim()
    if (open == null) {
        val names = remember(tick, q) { Prefs.plNames().filter { q.isEmpty() || it.contains(q, ignoreCase = true) } }
        if (names.isEmpty()) { Empty(if (q.isEmpty()) "No playlists yet. Tap + to create one." else "No results for \"$q\""); return }
        LazyColumn(Modifier.fillMaxSize()) {
            items(names, key = { it }) { n ->
                ListItem(
                    headlineContent = { Text(n) },
                    supportingContent = { Text("${Prefs.plItems(n).size} items") },
                    leadingContent = { Icon(Icons.Default.QueueMusic, null, tint = MaterialTheme.colorScheme.primary) },
                    trailingContent = { IconButton(onClick = { Prefs.plDelete(n) }) { Icon(Icons.Default.Delete, "Delete") } },
                    modifier = Modifier.clickable { onOpen(n) }
                )
            }
        }
    } else {
        val all = remember(tick, open) { Prefs.plItems(open) }
        val its = remember(all, q) { if (q.isEmpty()) all else all.filter { it.second.contains(q, ignoreCase = true) } }
        if (its.isEmpty()) { Empty(if (q.isEmpty()) "Empty playlist. Use ⋮ on a video/audio to add." else "No results for \"$q\""); return }
        val queue = remember(its) { its.map { QItem(it.first, it.second, it.first.contains("/audio/")) } }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
            itemsIndexed(its) { i, (_, t) ->
                ListItem(
                    headlineContent = {
                        Text(
                            if (q.isNotEmpty()) highlight(t, q, Color(0xFF2F6BFF)) else AnnotatedString(t),
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    },
                    leadingContent = { Icon(if (queue[i].audio) Icons.Default.MusicNote else Icons.Default.PlayCircle, null) },
                    modifier = Modifier.clickable { launchPlayer(ctx, queue, i) }
                )
            }
        }
    }
}
