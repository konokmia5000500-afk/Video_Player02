package com.swift.player

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*

object Prefs {
    private lateinit var sp: SharedPreferences
    private var ready = false

    // appearance
    var theme by mutableStateOf("system")
    var fontScale by mutableFloatStateOf(1f)
    // player
    var seekSec by mutableIntStateOf(10)
    var resume by mutableStateOf(true)
    var autoNext by mutableStateOf(true)
    var loop by mutableStateOf(false)
    var swipe by mutableStateOf(true)
    var doubleTap by mutableStateOf(true)
    var keepOn by mutableStateOf(true)
    var bgMode by mutableStateOf("pause")          // pause | audio | pip
    var orient by mutableStateOf("auto")
    var holdSpeed by mutableFloatStateOf(2f)
    var defSpeed by mutableFloatStateOf(1f)
    var doubleBack by mutableStateOf(false)
    var smartPrev by mutableStateOf(true)
    var suppressErr by mutableStateOf(false)
    var backToList by mutableStateOf(false)
    var fastSeek by mutableStateOf(true)
    var loadingAnim by mutableStateOf(true)
    var playAlone by mutableStateOf(true)
    var noisy by mutableStateOf(true)
    var btnTop by mutableStateOf("eq,speed,shot,audio,rotate")
    // subtitles
    var subSize by mutableFloatStateOf(1f)
    var subColor by mutableStateOf("white")
    var subBg by mutableStateOf("none")
    // list / library
    var viewMode by mutableStateOf("folders")       // folders | all | files
    var layout by mutableStateOf("list")            // list | grid
    var sortBy by mutableStateOf("date")
    var sortAsc by mutableStateOf(false)
    var fields by mutableStateOf("thumb,len,date")
    var lenOver by mutableStateOf(true)
    var showHidden by mutableStateOf(false)
    var lastMark by mutableStateOf(true)
    var scrollLast by mutableStateOf(false)
    var floatBtn by mutableStateOf(true)
    var newDays by mutableIntStateOf(1)
    var excluded by mutableStateOf("")
    var cacheThumb by mutableStateOf(true)
    // last played
    var lastUri by mutableStateOf("")
    var lastTitle by mutableStateOf("")
    var lastAudio by mutableStateOf(false)
    var playlistTick by mutableIntStateOf(0)

    fun init(c: Context) {
        if (ready) return
        sp = c.getSharedPreferences("swift", Context.MODE_PRIVATE)
        load()
        ready = true
    }

    private fun load() {
        theme = sp.getString("theme", "system")!!
        fontScale = sp.getFloat("font", 1f)
        seekSec = sp.getInt("seek", 10)
        resume = sp.getBoolean("resume", true)
        autoNext = sp.getBoolean("autoNext", true)
        loop = sp.getBoolean("loop", false)
        swipe = sp.getBoolean("swipe", true)
        doubleTap = sp.getBoolean("dtap", true)
        keepOn = sp.getBoolean("keepOn", true)
        bgMode = sp.getString("bgMode", "pause")!!
        orient = sp.getString("orient", "auto")!!
        holdSpeed = sp.getFloat("hold", 2f)
        defSpeed = sp.getFloat("defSpeed", 1f)
        doubleBack = sp.getBoolean("doubleBack", false)
        smartPrev = sp.getBoolean("smartPrev", true)
        suppressErr = sp.getBoolean("suppressErr", false)
        backToList = sp.getBoolean("backToList", false)
        fastSeek = sp.getBoolean("fastSeek", true)
        loadingAnim = sp.getBoolean("loadingAnim", true)
        playAlone = sp.getBoolean("playAlone", true)
        noisy = sp.getBoolean("noisy", true)
        btnTop = sp.getString("btnTop", "eq,speed,shot,audio,rotate")!!
        subSize = sp.getFloat("subSize", 1f)
        subColor = sp.getString("subColor", "white")!!
        subBg = sp.getString("subBg", "none")!!
        viewMode = sp.getString("viewMode", "folders")!!
        layout = sp.getString("layout", "list")!!
        sortBy = sp.getString("sortBy", "date")!!
        sortAsc = sp.getBoolean("sortAsc", false)
        fields = sp.getString("fields", "thumb,len,date")!!
        lenOver = sp.getBoolean("lenOver", true)
        showHidden = sp.getBoolean("showHidden", false)
        lastMark = sp.getBoolean("lastMark", true)
        scrollLast = sp.getBoolean("scrollLast", false)
        floatBtn = sp.getBoolean("floatBtn", true)
        newDays = sp.getInt("newDays", 1)
        excluded = sp.getString("excluded", "")!!
        cacheThumb = sp.getBoolean("cacheThumb", true)
        lastUri = sp.getString("lastUri", "")!!
        lastTitle = sp.getString("lastTitle", "")!!
        lastAudio = sp.getBoolean("lastAudio", false)
    }

    fun save() {
        sp.edit()
            .putString("theme", theme).putFloat("font", fontScale).putInt("seek", seekSec)
            .putBoolean("resume", resume).putBoolean("autoNext", autoNext).putBoolean("loop", loop)
            .putBoolean("swipe", swipe).putBoolean("dtap", doubleTap).putBoolean("keepOn", keepOn)
            .putString("bgMode", bgMode).putString("orient", orient).putFloat("hold", holdSpeed)
            .putFloat("defSpeed", defSpeed).putBoolean("doubleBack", doubleBack).putBoolean("smartPrev", smartPrev)
            .putBoolean("suppressErr", suppressErr).putBoolean("backToList", backToList)
            .putBoolean("fastSeek", fastSeek).putBoolean("loadingAnim", loadingAnim)
            .putBoolean("playAlone", playAlone).putBoolean("noisy", noisy).putString("btnTop", btnTop)
            .putFloat("subSize", subSize).putString("subColor", subColor).putString("subBg", subBg)
            .putString("viewMode", viewMode).putString("layout", layout).putString("sortBy", sortBy)
            .putBoolean("sortAsc", sortAsc).putString("fields", fields).putBoolean("lenOver", lenOver)
            .putBoolean("showHidden", showHidden).putBoolean("lastMark", lastMark)
            .putBoolean("scrollLast", scrollLast).putBoolean("floatBtn", floatBtn).putInt("newDays", newDays)
            .putString("excluded", excluded).putBoolean("cacheThumb", cacheThumb)
            .putString("lastUri", lastUri).putString("lastTitle", lastTitle).putBoolean("lastAudio", lastAudio)
            .apply()
    }

    fun resetSettings() {
        val keep = { k: String -> k.startsWith("p_") || k.startsWith("t_") || k.startsWith("pl_") || k.startsWith("last") || k.startsWith("eq") }
        val e = sp.edit()
        sp.all.keys.filter { !keep(it) }.forEach { e.remove(it) }
        e.apply()
        load()
    }

    fun clearHistory() {
        val e = sp.edit()
        sp.all.keys.filter { it.startsWith("p_") || it.startsWith("t_") }.forEach { e.remove(it) }
        e.apply()
        lastUri = ""; lastTitle = ""; lastAudio = false
        save()
    }

    fun hasField(k: String) = fields.split(",").contains(k)
    fun toggleField(s: String, k: String): String {
        val l = s.split(",").filter { it.isNotEmpty() }.toMutableList()
        if (l.contains(k)) l.remove(k) else l.add(k)
        return l.joinToString(",")
    }
    fun excludedSet(): Set<String> = excluded.split("\n").filter { it.isNotEmpty() }.toSet()
    fun toggleExcluded(p: String) {
        val s = excludedSet().toMutableSet()
        if (!s.remove(p)) s.add(p)
        excluded = s.joinToString("\n"); save()
    }

    fun pos(uri: String): Long = sp.getLong("p_$uri", 0L)
    fun setPos(uri: String, ms: Long) { sp.edit().putLong("p_$uri", ms).putLong("t_$uri", System.currentTimeMillis()).apply() }
    fun played(uri: String): Long = sp.getLong("t_$uri", 0L)

    // ---- Playlists (stored as text: name list + "uri<TAB>title" lines) ----
    fun plNames(): List<String> = sp.getString("pl_names", "")!!.split("\n").filter { it.isNotBlank() }
    fun plItems(n: String): List<Pair<String, String>> =
        sp.getString("pl_$n", "")!!.split("\n").filter { it.isNotBlank() }.map {
            val a = it.split("\t"); a[0] to a.getOrElse(1) { a[0] }
        }
    fun plCreate(n: String) {
        val name = n.trim(); if (name.isEmpty() || plNames().contains(name)) return
        sp.edit().putString("pl_names", (plNames() + name).joinToString("\n")).apply(); playlistTick++
    }
    fun plAdd(n: String, uri: String, title: String) {
        val cur = plItems(n)
        if (cur.any { it.first == uri }) return
        sp.edit().putString("pl_$n", (cur + (uri to title)).joinToString("\n") { it.first + "\t" + it.second }).apply()
        playlistTick++
    }
    fun plDelete(n: String) {
        sp.edit().putString("pl_names", plNames().filter { it != n }.joinToString("\n")).remove("pl_$n").apply(); playlistTick++
    }

    // ---- Equalizer (15 bands, dB) ----
    fun eqLoad(): FloatArray {
        val l = sp.getString("eq", "")!!.split(",").mapNotNull { it.toFloatOrNull() }
        return if (l.size == EqProcessor.N) l.toFloatArray() else FloatArray(EqProcessor.N)
    }
    fun eqOn(): Boolean = sp.getBoolean("eqOn", true)
    fun eqSave(g: FloatArray, on: Boolean) { sp.edit().putString("eq", g.joinToString(",")).putBoolean("eqOn", on).apply() }
}
