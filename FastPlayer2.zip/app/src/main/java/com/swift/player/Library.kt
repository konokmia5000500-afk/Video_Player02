package com.swift.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest

private val BLUE = Color(0xFF2F6BFF)

class LibNav {
    var open by mutableStateOf<String?>(null)     // "All folders" mode: the opened folder path
    val tree = mutableStateListOf<String>()       // "Folders" mode: path segments
    fun inside(): Boolean = open != null || tree.isNotEmpty()
    fun back() { if (open != null) open = null else if (tree.isNotEmpty()) tree.removeAt(tree.size - 1) }
    fun reset() { open = null; tree.clear() }
    fun key(): String = (open ?: "") + "|" + tree.joinToString("/")
}

data class FolderEntry(val key: String, val name: String, val videos: Int, val folders: Int, val fresh: Int, val isLast: Boolean)

fun leafName(path: String) = path.trimEnd('/').substringAfterLast('/').ifEmpty { "Internal" }

fun freshCount(l: List<Media>, now: Long): Int {
    val d = Prefs.newDays
    if (d <= 0) return 0
    val lim = now - d * 86_400_000L
    return l.count { it.added * 1000 > lim }
}

fun visibleItems(all: List<Media>): List<Media> {
    val ex = Prefs.excludedSet()
    val hidden = Prefs.showHidden
    return all.filter { m ->
        m.path !in ex && (hidden || !m.path.split('/').any { it.length > 1 && it.startsWith(".") })
    }
}

fun statusOf(m: Media): Int {
    val p = Prefs.pos(m.key)
    return if (p <= 0) 0 else if (m.durationMs > 0 && p > m.durationMs - 5000) 2 else 1
}

fun sortMedia(l: List<Media>, by: String, asc: Boolean): List<Media> {
    val s = when (by) {
        "title" -> l.sortedBy { it.title.lowercase() }
        "played" -> l.sortedBy { Prefs.played(it.key) }
        "status" -> l.sortedBy { statusOf(it) }
        "length" -> l.sortedBy { it.durationMs }
        "size" -> l.sortedBy { it.size }
        "resolution" -> l.sortedBy { it.w.toLong() * it.h }
        "path" -> l.sortedBy { it.path.lowercase() + it.title.lowercase() }
        "type" -> l.sortedBy { it.ext }
        else -> l.sortedBy { it.added }
    }
    return if (asc) s else s.reversed()
}

fun allFolders(items: List<Media>, lastPath: String?, now: Long): List<FolderEntry> =
    items.groupBy { it.path }
        .map { (p, l) -> FolderEntry(p, leafName(p), l.size, 0, freshCount(l, now), p == lastPath) }
        .sortedBy { it.name.lowercase() }

fun treeLevel(items: List<Media>, cur: List<String>, lastPath: String?, now: Long): Pair<List<FolderEntry>, List<Media>> {
    val prefix = cur.joinToString("") { "$it/" }
    val kids = LinkedHashMap<String, MutableList<Media>>()
    val direct = ArrayList<Media>()
    for (m in items) {
        if (!m.path.startsWith(prefix)) continue
        val rest = m.path.substring(prefix.length)
        if (rest.isEmpty()) direct.add(m) else kids.getOrPut(rest.substringBefore('/')) { ArrayList() }.add(m)
    }
    val entries = kids.map { (seg, l) ->
        val sub = l.map { it.path.substring(prefix.length + seg.length + 1) }
            .filter { it.isNotEmpty() }.map { it.substringBefore('/') }.distinct().size
        FolderEntry(seg, seg, l.size, sub, freshCount(l, now), lastPath != null && lastPath.startsWith(prefix + seg + "/"))
    }.sortedBy { it.name.lowercase() }
    return entries to direct
}

@Composable
fun Thumb(m: Media, loader: ImageLoader, modifier: Modifier) {
    val ctx = LocalContext.current
    val cache = Prefs.cacheThumb
    val req = remember(m.id, cache) {
        ImageRequest.Builder(ctx).data(m.uri)
            .diskCachePolicy(if (cache) CachePolicy.ENABLED else CachePolicy.DISABLED).build()
    }
    AsyncImage(model = req, imageLoader = loader, contentDescription = null, contentScale = ContentScale.Crop, modifier = modifier)
}

private fun infoText(m: Media, lenInInfo: Boolean): String {
    val parts = ArrayList<String>()
    if (lenInInfo) parts.add(fmt(m.durationMs))
    if (Prefs.hasField("size")) parts.add(sizeText(m.size))
    if (Prefs.hasField("res") && m.w > 0) parts.add("${m.w}×${m.h}")
    if (Prefs.hasField("ext") && m.ext.isNotEmpty()) parts.add(m.ext)
    if (Prefs.hasField("played")) { val p = Prefs.pos(m.key); if (p > 0) parts.add("▶ " + fmt(p)) }
    if (Prefs.hasField("path")) parts.add(m.path.trimEnd('/'))
    return parts.joinToString(" · ")
}

@Composable
fun DateChip(m: Media) {
    Text(
        dateText(m.added), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 1.dp)
    )
}

@Composable
fun MediaRow(m: Media, loader: ImageLoader, query: String, onClick: () -> Unit, onAdd: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val showThumb = m.audio || Prefs.hasField("thumb")
    val over = Prefs.lenOver && Prefs.hasField("len") && showThumb
    val lenInInfo = Prefs.hasField("len") && !over
    val isLast = Prefs.lastMark && m.key == Prefs.lastUri
    val info = infoText(m, lenInInfo)
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showThumb) Box(
            Modifier.size(width = 104.dp, height = 60.dp).clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            if (m.audio) Icon(Icons.Default.MusicNote, null, Modifier.align(Alignment.Center))
            else Thumb(m, loader, Modifier.fillMaxSize())
            if (over) Text(
                fmt(m.durationMs), fontSize = 11.sp, color = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).background(Color(0x99000000)).padding(horizontal = 4.dp)
            )
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                if (query.isNotEmpty()) highlight(m.title, query, BLUE) else AnnotatedString(m.title),
                color = if (isLast) BLUE else Color.Unspecified,
                maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium
            )
            if (info.isNotEmpty()) Text(
                info, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (Prefs.hasField("date")) { Spacer(Modifier.height(2.dp)); DateChip(m) }
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { menu = false; onAdd() })
            }
        }
    }
}

@Composable
fun MediaCell(m: Media, loader: ImageLoader, query: String, onClick: () -> Unit) {
    val isLast = Prefs.lastMark && m.key == Prefs.lastUri
    Column(Modifier.clickable(onClick = onClick).padding(6.dp)) {
        Box(
            Modifier.fillMaxWidth().aspectRatioBox().clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            if (m.audio) Icon(Icons.Default.MusicNote, null, Modifier.align(Alignment.Center).size(36.dp))
            else Thumb(m, loader, Modifier.fillMaxSize())
            if (Prefs.hasField("len")) Text(
                fmt(m.durationMs), fontSize = 11.sp, color = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).background(Color(0x99000000)).padding(horizontal = 4.dp)
            )
        }
        Text(
            if (query.isNotEmpty()) highlight(m.title, query, BLUE) else AnnotatedString(m.title),
            color = if (isLast) BLUE else Color.Unspecified,
            maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
        )
        if (Prefs.hasField("date")) DateChip(m)
    }
}

private fun Modifier.aspectRatioBox(): Modifier = this.then(Modifier.aspectRatio(16f / 9f))

@Composable
fun FolderIcon(f: FolderEntry, size: Int) {
    Box(Modifier.size(width = size.dp, height = (size * 0.8f).dp)) {
        Icon(Icons.Default.Folder, null, Modifier.fillMaxSize(), tint = MaterialTheme.colorScheme.surfaceVariant)
        if (f.fresh > 0) Box(
            Modifier.align(Alignment.TopEnd).size(22.dp).background(Color(0xFFF2385A), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text("${f.fresh}", color = Color.White, fontSize = 11.sp) }
    }
}

private fun folderSub(f: FolderEntry, audio: Boolean): String =
    if (f.folders > 0) "${f.folders} folder${if (f.folders > 1) "s" else ""}"
    else "${f.videos} ${if (audio) "track" else "video"}${if (f.videos > 1) "s" else ""}"

@Composable
fun FolderRow(f: FolderEntry, audio: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FolderIcon(f, 64)
        Column(Modifier.padding(start = 14.dp)) {
            Text(
                f.name, color = if (f.isLast && Prefs.lastMark) BLUE else Color.Unspecified,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Text(folderSub(f, audio), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun FolderCell(f: FolderEntry, audio: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        FolderIcon(f, 72)
        Text(
            f.name, color = if (f.isLast && Prefs.lastMark) BLUE else Color.Unspecified,
            maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp
        )
        Text(folderSub(f, audio), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun Library(items: List<Media>, nav: LibNav, loader: ImageLoader, query: String, loaded: Boolean, audio: Boolean) {
    val ctx = LocalContext.current
    var addTarget by remember { mutableStateOf<Media?>(null) }
    if (!loaded) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val vis = remember(items, Prefs.excluded, Prefs.showHidden) { visibleItems(items) }
    if (vis.isEmpty()) { Empty("No media found"); return }
    val now = remember(vis) { System.currentTimeMillis() }
    val lastPath = remember(vis, Prefs.lastUri) { vis.firstOrNull { it.key == Prefs.lastUri }?.path }
    val q = query.trim()
    val mode = Prefs.viewMode
    val navKey = nav.key()
    val sortBy = Prefs.sortBy
    val asc = Prefs.sortAsc

    val shown = remember(vis, navKey, mode, q, sortBy, asc, lastPath) {
        var folders: List<FolderEntry> = emptyList()
        var files: List<Media> = emptyList()
        if (q.isNotEmpty()) {
            val pool = when {
                nav.open != null -> vis.filter { it.path == nav.open }
                nav.tree.isNotEmpty() -> {
                    val pfx = nav.tree.joinToString("") { "$it/" }
                    vis.filter { it.path.startsWith(pfx) }
                }
                else -> vis
            }
            files = searchMedia(pool, q)
        } else when (mode) {
            "files" -> files = sortMedia(vis, sortBy, asc)
            "all" -> if (nav.open == null) folders = allFolders(vis, lastPath, now)
                     else files = sortMedia(vis.filter { it.path == nav.open }, sortBy, asc)
            else -> {
                val (f, d) = treeLevel(vis, nav.tree.toList(), lastPath, now)
                folders = f; files = sortMedia(d, sortBy, asc)
            }
        }
        folders to files
    }
    val folders = shown.first
    val files = shown.second
    if (folders.isEmpty() && files.isEmpty()) {
        Empty(if (q.isNotEmpty()) "No results for \"$q\"" else "Nothing here"); return
    }
    val queue = remember(files) { files.map { QItem(it.key, it.title, it.audio) } }
    fun openFolder(f: FolderEntry) { if (mode == "all") nav.open = f.key else nav.tree.add(f.key) }

    if (Prefs.layout != "grid") {
        val ls = rememberLazyListState()
        LaunchedEffect(files, q) {
            if (q.isEmpty() && Prefs.scrollLast) {
                val i = files.indexOfFirst { it.key == Prefs.lastUri }
                if (i >= 0) ls.scrollToItem(folders.size + i)
            }
        }
        LazyColumn(Modifier.fillMaxSize(), state = ls, contentPadding = PaddingValues(bottom = 90.dp)) {
            items(folders, key = { "f:" + it.key }) { f -> FolderRow(f, audio) { openFolder(f) } }
            itemsIndexed(files, key = { _, m -> m.id }) { i, m ->
                MediaRow(m, loader, q, { launchPlayer(ctx, queue, i) }, { addTarget = m })
            }
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(if (files.isEmpty()) 110.dp else 150.dp),
            modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 6.dp, end = 6.dp, bottom = 90.dp)
        ) {
            gridItems(folders, key = { "f:" + it.key }) { f -> FolderCell(f, audio) { openFolder(f) } }
            gridItemsIndexed(files, key = { _, m -> m.id }) { i, m ->
                MediaCell(m, loader, q) { launchPlayer(ctx, queue, i) }
            }
        }
    }
    addTarget?.let { m -> AddToPlaylistDialog(m) { addTarget = null } }
}

// ---------------------------------------------------------------- View / Sort / Fields dialog

@Composable
private fun Opt(icon: ImageVector, label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = if (selected) BLUE else MaterialTheme.colorScheme.onSurfaceVariant
    Column(modifier.clickable(onClick = onClick).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = c, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = c, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun Chk(label: String, checked: Boolean, modifier: Modifier = Modifier, onToggle: () -> Unit) {
    Row(modifier.clickable(onClick = onToggle), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = null)
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
fun ViewDialog(onClose: () -> Unit) {
    var mode by remember { mutableStateOf(Prefs.viewMode) }
    var layout by remember { mutableStateOf(Prefs.layout) }
    var sort by remember { mutableStateOf(Prefs.sortBy) }
    var asc by remember { mutableStateOf(Prefs.sortAsc) }
    var fields by remember { mutableStateOf(Prefs.fields) }
    var over by remember { mutableStateOf(Prefs.lenOver) }
    var hidden by remember { mutableStateOf(Prefs.showHidden) }
    var fOpen by remember { mutableStateOf(false) }
    var aOpen by remember { mutableStateOf(false) }
    val sorts = listOf(
        Triple("title", "Title", Icons.Default.SortByAlpha), Triple("date", "Date", Icons.Default.DateRange),
        Triple("played", "Played time", Icons.Default.History), Triple("status", "Status", Icons.Default.CheckCircle),
        Triple("length", "Length", Icons.Default.Timer), Triple("size", "Size", Icons.Default.Storage),
        Triple("resolution", "Resolution", Icons.Default.HighQuality), Triple("path", "Path", Icons.Default.LocationOn),
        Triple("type", "Type", Icons.Default.Category)
    )
    val fieldList = listOf(
        "thumb" to "Thumbnail", "len" to "Length", "ext" to "File extension", "played" to "Played time",
        "res" to "Resolution", "path" to "Path", "size" to "Size", "date" to "Date"
    )
    val timeSort = sort == "date" || sort == "played"
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.92f).fillMaxHeight(0.88f), shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Row {
                        Column(Modifier.weight(3f)) {
                            Text("View Mode", style = MaterialTheme.typography.titleMedium)
                            Row {
                                Opt(Icons.Default.FolderOpen, "All folders", mode == "all", Modifier.weight(1f)) { mode = "all" }
                                Opt(Icons.Default.Description, "Files", mode == "files", Modifier.weight(1f)) { mode = "files" }
                                Opt(Icons.Default.Folder, "Folders", mode == "folders", Modifier.weight(1f)) { mode = "folders" }
                            }
                        }
                        Column(Modifier.weight(2f)) {
                            Text("Layout", style = MaterialTheme.typography.titleMedium)
                            Row {
                                Opt(Icons.Default.ViewList, "List", layout == "list", Modifier.weight(1f)) { layout = "list" }
                                Opt(Icons.Default.GridView, "Grid", layout == "grid", Modifier.weight(1f)) { layout = "grid" }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Sort", style = MaterialTheme.typography.titleMedium)
                    sorts.chunked(5).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { (k, l, ic) -> Opt(ic, l, sort == k, Modifier.weight(1f)) { sort = k } }
                            repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth()) {
                        listOf(true to (if (timeSort) "↑ Oldest" else "↑ Ascending"), false to (if (timeSort) "↓ Newest" else "↓ Descending"))
                            .forEach { (v, l) ->
                                val sel = asc == v
                                Box(
                                    Modifier.weight(1f).border(1.dp, if (sel) BLUE else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(6.dp))
                                        .background(if (sel) BLUE.copy(alpha = 0.1f) else Color.Transparent, RoundedCornerShape(6.dp))
                                        .clickable { asc = v }.padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) { Text(l, color = if (sel) BLUE else MaterialTheme.colorScheme.onSurfaceVariant) }
                            }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth().clickable { fOpen = !fOpen }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Fields", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        Icon(if (fOpen) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null)
                    }
                    if (fOpen) fieldList.chunked(3).forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                            row.forEach { (k, l) ->
                                Chk(l, fields.split(",").contains(k), Modifier.weight(1f)) { fields = Prefs.toggleField(fields, k) }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().clickable { aOpen = !aOpen }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Advanced", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        Icon(if (aOpen) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null)
                    }
                    if (aOpen) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Display length over thumbnail", Modifier.weight(1f)); Switch(over, { over = it })
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Show hidden files and folders", Modifier.weight(1f)); Switch(hidden, { hidden = it })
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onClose) { Text("Cancel") }
                    TextButton(onClick = {
                        Prefs.viewMode = mode; Prefs.layout = layout; Prefs.sortBy = sort; Prefs.sortAsc = asc
                        Prefs.fields = fields; Prefs.lenOver = over; Prefs.showHidden = hidden; Prefs.save()
                        onClose()
                    }) { Text("Done") }
                }
            }
        }
    }
}
