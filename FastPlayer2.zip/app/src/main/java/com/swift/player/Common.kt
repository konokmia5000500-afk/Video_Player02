package com.swift.player

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Density

data class Media(
    val id: Long, val uri: Uri, val title: String, val folder: String, val path: String,
    val durationMs: Long, val size: Long, val added: Long, val audio: Boolean, val w: Int, val h: Int
) {
    val ext: String get() = title.substringAfterLast('.', "").uppercase()
    val key: String get() = uri.toString()
}

/** Set by the library screen so Settings can list folders / clear thumbnails. */
object LibCache { var paths: List<String> = emptyList() }
object Img { var loader: coil.ImageLoader? = null }

private val dateFmt = java.text.SimpleDateFormat("MMM d", java.util.Locale.getDefault())
fun dateText(addedSec: Long): String = dateFmt.format(java.util.Date(addedSec * 1000))

/** "+00:50" style difference for swipe seeking. */
fun fmtDelta(ms: Long): String {
    val s = kotlin.math.abs(ms) / 1000
    val body = if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60) else "%02d:%02d".format(s / 60, s % 60)
    return (if (ms < 0) "-" else "+") + body
}

data class QItem(val uri: String, val title: String, val audio: Boolean)

/** Process-wide play queue: avoids Intent size limits for big folders. */
object PlayQueue { var items: List<QItem> = emptyList() }

fun launchPlayer(ctx: Context, list: List<QItem>, index: Int) {
    PlayQueue.items = list
    ctx.startActivity(Intent(ctx, PlayerActivity::class.java).putExtra("index", index))
    (ctx as? android.app.Activity)?.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

fun sizeText(b: Long) = if (b >= 1_073_741_824L) "%.2f GB".format(b / 1073741824.0) else "%.1f MB".format(b / 1048576.0)

object MediaRepo {
    fun load(ctx: Context, audio: Boolean): List<Media> {
        val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val base = listOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME, MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.DURATION, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED
        )
        val proj = (if (audio) base else base + listOf(MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT)).toTypedArray()
        val out = ArrayList<Media>()
        try {
            ctx.contentResolver.query(coll, proj, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    out.add(Media(id, ContentUris.withAppendedId(coll, id), c.getString(1) ?: "",
                        c.getString(2) ?: "Internal", c.getString(3) ?: "", c.getLong(4), c.getLong(5), c.getLong(6), audio,
                        if (audio) 0 else c.getInt(7), if (audio) 0 else c.getInt(8)))
                }
            }
        } catch (_: Exception) {}
        return out
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    val darkBase = darkColorScheme(primary = Color(0xFF6FA0FF))
    val scheme = when (Prefs.theme) {
        "light" -> lightColorScheme(primary = Color(0xFF1E5BFF))
        "dark" -> darkBase
        "amoled" -> darkColorScheme(primary = Color(0xFF6FA0FF), background = Color.Black, surface = Color.Black)
        "blue" -> darkColorScheme(primary = Color(0xFF4FC3F7), background = Color(0xFF0A1A4A), surface = Color(0xFF10246B))
        else -> if (sys) darkBase else lightColorScheme(primary = Color(0xFF1E5BFF))
    }
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * Prefs.fontScale)) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** Exact substring matches first (earliest match first), then "related" matches (any word matches). */
fun searchMedia(pool: List<Media>, q: String): List<Media> {
    val ql = q.trim().lowercase()
    val toks = ql.split(" ", "_", "-", ".").filter { it.length >= 2 }.distinct()
    val exact = ArrayList<Pair<Int, Media>>()
    val related = ArrayList<Media>()
    for (m in pool) {
        val t = m.title.lowercase()
        val i = t.indexOf(ql)
        if (i >= 0) exact.add(i to m) else if (toks.any { t.contains(it) }) related.add(m)
    }
    return exact.sortedBy { it.first }.map { it.second } +
        related.sortedByDescending { r -> toks.count { r.title.lowercase().contains(it) } }
}

fun highlight(text: String, q: String, color: Color): AnnotatedString {
    val tl = text.lowercase()
    if (tl.length != text.length || q.isBlank()) return AnnotatedString(text)
    val ql = q.trim().lowercase()
    val terms = (listOf(ql) + ql.split(" ", "_", "-", ".").filter { it.length >= 2 }).distinct()
    val marks = BooleanArray(text.length)
    for (term in terms) {
        var i = tl.indexOf(term)
        while (i >= 0) {
            for (k in i until i + term.length) marks[k] = true
            i = tl.indexOf(term, i + term.length)
        }
    }
    return buildAnnotatedString {
        var k = 0
        while (k < text.length) {
            val on = marks[k]
            var j = k
            while (j < text.length && marks[j] == on) j++
            if (on) withStyle(SpanStyle(color = color, fontWeight = FontWeight.Bold)) { append(text.substring(k, j)) }
            else append(text.substring(k, j))
            k = j
        }
    }
}
