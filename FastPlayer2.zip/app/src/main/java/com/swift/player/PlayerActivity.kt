@file:OptIn(UnstableApi::class)

package com.swift.player

import android.app.PictureInPictureParams
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Rational
import android.view.LayoutInflater
import android.view.TextureView
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.PlayerMessage
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt

class PlayerActivity : ComponentActivity() {
    lateinit var player: ExoPlayer
    lateinit var queue: List<QItem>
    private var ready = false
    private var listener: Player.Listener? = null
    private val handler = Handler(Looper.getMainLooper())
    private val sleepRun = Runnable { if (ready) player.pause(); sleepMin = 0 }
    private var lastBack = 0L
    private var bgAudio = false
    private var le: LoudnessEnhancer? = null
    private var abMsg: PlayerMessage? = null
    var inPip by mutableStateOf(false)
    var audioOnly by mutableStateOf(false)
    var sleepMin by mutableIntStateOf(0)
    var boostDb by mutableIntStateOf(0)
    var abA by mutableLongStateOf(-1L)
    var abB by mutableLongStateOf(-1L)
    private var bright = -1f
    private var volF = -1f
    private val am by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)

        val d = intent?.data
        val attach = intent?.getBooleanExtra("attach", false) == true && PlayerHolder.player != null
        queue = if (!attach && d != null)
            listOf(QItem(d.toString(), d.lastPathSegment ?: "Media", intent.type?.startsWith("audio") == true))
        else PlayQueue.items
        if (queue.isEmpty()) { finish(); return }
        if (!attach && d != null) PlayQueue.items = queue
        val start = if (attach || d != null) 0 else intent.getIntExtra("index", 0).coerceIn(0, queue.size - 1)
        ready = true
        PlayerHolder.alive++

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).run {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        requestedOrientation = when (Prefs.orient) {
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            "system" -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val now = SystemClock.uptimeMillis()
                if (!Prefs.doubleBack || now - lastBack < 2000) finish()
                else { lastBack = now; Toast.makeText(this@PlayerActivity, "Press back again to exit", Toast.LENGTH_SHORT).show() }
            }
        })

        player = PlayerHolder.get(this)
        player.setAudioAttributes(AudioAttributes.DEFAULT, Prefs.playAlone)
        player.setHandleAudioBecomingNoisy(Prefs.noisy)
        player.setSeekParameters(if (Prefs.fastSeek) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)

        val l = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                saveLast()
                clearAB()
                updateKeep()
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && !Prefs.autoNext) player.pause()
                if (isAudioNow()) ensureService()
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (Prefs.orient == "video" && videoSize.width > 0) requestedOrientation =
                    if (videoSize.width >= videoSize.height) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
            override fun onPlayerError(error: PlaybackException) {
                if (Prefs.suppressErr && player.hasNextMediaItem()) {
                    player.seekToNextMediaItem(); player.prepare(); player.play()
                } else Toast.makeText(applicationContext, "Can't play this file", Toast.LENGTH_SHORT).show()
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && Prefs.backToList && !player.hasNextMediaItem() &&
                    player.repeatMode == Player.REPEAT_MODE_OFF
                ) finish()
            }
        }
        listener = l
        player.addListener(l)

        if (attach) {
            audioOnly = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_VIDEO)
        } else {
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().clearOverrides()
                .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
            player.setPlaybackSpeed(Prefs.defSpeed)
            player.volume = 1f
            player.shuffleModeEnabled = false
            player.repeatMode = if (Prefs.loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            val items = queue.map {
                MediaItem.Builder().setUri(it.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).build()).build()
            }
            val sp = if (Prefs.resume) Prefs.pos(queue[start].uri) else 0L
            player.setMediaItems(items, start, if (sp > 0) sp else C.TIME_UNSET)
            player.prepare()
            player.playWhenReady = true
        }
        updateKeep()
        if (isAudioNow()) ensureService()
        setContent { AppTheme { PlayerScreen(this) } }
    }

    fun isAudioNow(): Boolean = audioOnly || queue.getOrNull(player.currentMediaItemIndex)?.audio == true

    /** Keep the screen on only while a VIDEO is on screen. Audio never forces the screen on. */
    fun updateKeep() {
        if (!ready) return
        if (Prefs.keepOn && !isAudioNow()) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun ensureService() {
        try { ContextCompat.startForegroundService(this, Intent(this, AudioService::class.java)) } catch (_: Exception) {}
    }
    private fun stopSvc() { try { stopService(Intent(this, AudioService::class.java)) } catch (_: Exception) {} }

    fun saveLast() {
        if (!ready) return
        val q = queue.getOrNull(player.currentMediaItemIndex) ?: return
        val dur = player.duration; val p = player.currentPosition
        Prefs.setPos(q.uri, if (dur > 0 && p > dur - 3000) 0 else p)
        Prefs.lastUri = q.uri; Prefs.lastTitle = q.title; Prefs.lastAudio = q.audio; Prefs.save()
    }

    override fun onStart() {
        super.onStart()
        if (ready && bgAudio) { bgAudio = false; applyAudioOnly(false) }
    }

    override fun onStop() {
        super.onStop()
        if (!ready) return
        saveLast()
        if (Prefs.bgMode == "audio" && !inPip && !isAudioNow() && player.isPlaying) { bgAudio = true; applyAudioOnly(true) }
        if (PlayerHolder.alive <= 1 && !isInPictureInPictureMode && !isAudioNow()) player.pause()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!ready || !player.isPlaying || isAudioNow()) return
        if (Prefs.bgMode == "pip") enterPip()
        else if (Prefs.bgMode == "audio") { bgAudio = true; applyAudioOnly(true) }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        if (!ready) return
        listener?.let { player.removeListener(it) }
        saveLast()
        clearAB()
        try { le?.release() } catch (_: Exception) {}
        PlayerHolder.alive--
        // Audio keeps playing in the background (notification); video stops and frees memory.
        val keep = player.isPlaying && isAudioNow()
        if (!keep && PlayerHolder.alive == 0) { stopSvc(); PlayerHolder.release() }
    }

    fun enterPip() {
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        } catch (_: Exception) {}
    }

    /** Headphone button: play as audio only (screen can be turned off, playback continues). */
    fun applyAudioOnly(v: Boolean) {
        audioOnly = v
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, v).build()
        if (v) ensureService() else if (!isAudioNow()) stopSvc()
        updateKeep()
    }

    fun setSleep(min: Int) {
        handler.removeCallbacks(sleepRun)
        sleepMin = min
        if (min > 0) handler.postDelayed(sleepRun, min * 60_000L)
    }

    fun setBoost(db: Int) {
        boostDb = db
        try {
            if (le == null) le = LoudnessEnhancer(player.audioSessionId)
            le?.setTargetGain(db * 100)
            le?.setEnabled(db > 0)
        } catch (_: Exception) {}
    }

    /** A-B repeat: 1st tap sets A, 2nd sets B and loops A..B, 3rd clears. */
    fun cycleAB(): String {
        if (abA < 0) { abA = player.currentPosition; return "A set" }
        if (abB < 0) {
            val b = player.currentPosition
            if (b <= abA + 500) return "B must be after A"
            abB = b
            val a = abA
            abMsg = player.createMessage { _, _ -> player.seekTo(a) }
                .setLooper(Looper.getMainLooper()).setPosition(b).setDeleteAfterDelivery(false).send()
            return "A-B repeat on"
        }
        clearAB()
        return "A-B repeat off"
    }
    fun clearAB() {
        abMsg?.cancel(); abMsg = null
        abA = -1L; abB = -1L
    }

    fun addSubtitle(u: Uri) {
        val name = (u.lastPathSegment ?: "").lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val i = player.currentMediaItemIndex
        val cur = player.currentMediaItem ?: return
        val pos = player.currentPosition
        val sub = MediaItem.SubtitleConfiguration.Builder(u).setMimeType(mime).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        player.replaceMediaItem(i, cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build())
        player.seekTo(i, pos)
    }

    // ---- System brightness (window) / system media volume ----
    fun addBright(f: Float): Int {
        if (bright < 0) bright = try {
            android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Exception) { 0.5f }
        bright = (bright + f).coerceIn(0.01f, 1f)
        window.attributes = window.attributes.also { it.screenBrightness = bright }
        return (bright * 100).roundToInt()
    }
    fun syncVol() { volF = -1f }
    fun addVolume(f: Float): Int {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (volF < 0) volF = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
        volF = (volF + f).coerceIn(0f, 1f)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (volF * max).roundToInt(), 0)
        return (volF * 100).roundToInt()
    }
}

// ------------------------------------------------------------------ small UI pieces

private val DARK_BTN = Color(0x99303030)
private val BLUE_BTN = Color(0xFF2F6BFF)
private val SHADOW = Shadow(Color(0xCC000000), Offset(0f, 2f), 8f)

class Btn(
    val key: String, val icon: ImageVector?, val label: String, val active: Boolean = false,
    val text: String? = null, val onClick: () -> Unit
)

@Composable
fun RoundBtn(b: Btn, withLabel: Boolean) {
    Column(
        Modifier.padding(horizontal = if (withLabel) 4.dp else 10.dp).width(if (withLabel) 74.dp else 44.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(44.dp).background(if (b.active) BLUE_BTN else DARK_BTN, CircleShape).clickable(onClick = b.onClick),
            contentAlignment = Alignment.Center
        ) {
            if (b.text != null) Text(b.text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            else if (b.icon != null) Icon(b.icon, b.label, tint = Color.White)
        }
        if (withLabel) Text(b.label, color = Color.White, fontSize = 11.sp, maxLines = 2, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun SmallIcon(icon: ImageVector, desc: String, onClick: () -> Unit) {
    IconButton(onClick = onClick) { Icon(icon, desc, tint = Color.White) }
}

@Composable
fun Pill(text: String, icon: ImageVector? = null, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color(0x73000000), shape = RoundedCornerShape(50)) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
            Text(text, color = Color.White, fontSize = 15.sp)
        }
    }
}

@Composable
fun VBar(pct: Int, icon: ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier.width(52.dp).height(210.dp), color = Color(0x73000000), shape = RoundedCornerShape(50)) {
        Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$pct%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier.weight(1f).width(4.dp).background(Color(0x55FFFFFF), RoundedCornerShape(2.dp)),
                contentAlignment = Alignment.BottomCenter
            ) {
                Box(Modifier.fillMaxWidth().fillMaxHeight((pct / 100f).coerceIn(0f, 1f)).background(Color(0xFF4F8DFF), RoundedCornerShape(2.dp)))
            }
            Spacer(Modifier.height(8.dp))
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun PLabel(t: String) {
    Text(t, Modifier.padding(top = 14.dp, bottom = 4.dp), color = Color(0xFF8FB3FF), style = MaterialTheme.typography.labelLarge)
}

@Composable
fun PChoice(name: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(10.dp))
        Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun PSwitch(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

fun trackName(g: Tracks.Group, i: Int): String {
    val f = g.getTrackFormat(0)
    val lang = f.language?.takeIf { it != "und" }?.let { Locale(it).displayLanguage }
    return listOfNotNull(f.label, lang).distinct().joinToString(" · ").ifEmpty { "Track ${i + 1}" }
}

@Composable
fun TrackSection(title: String, p: ExoPlayer, tracks: Tracks, type: Int, offOption: Boolean) {
    val groups = tracks.groups.filter { it.type == type && it.length > 0 }
    PLabel(title)
    if (groups.isEmpty()) {
        Text(if (type == C.TRACK_TYPE_TEXT) "No subtitles in this file" else "Only one track", color = Color(0x99FFFFFF), fontSize = 13.sp)
        return
    }
    var sel by remember { mutableIntStateOf(groups.indexOfFirst { it.isSelected }) }
    if (offOption) PChoice("Off", sel == -1) {
        sel = -1
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(type, true).build()
    }
    groups.forEachIndexed { i, g ->
        PChoice(trackName(g, i), sel == i) {
            sel = i
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(type, false)
                .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
        }
    }
}

@Composable
fun BoxScope.SidePanel(visible: Boolean, width: Dp, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AnimatedVisibility(visible, enter = fadeIn(), exit = fadeOut()) {
        Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose))
    }
    AnimatedVisibility(
        visible, modifier = Modifier.align(Alignment.CenterEnd),
        enter = slideInHorizontally { it } + fadeIn(), exit = slideOutHorizontally { it } + fadeOut()
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF6FA0FF))) {
            Surface(Modifier.fillMaxHeight().width(width), color = Color(0xB3121212), contentColor = Color.White) {
                Column(Modifier.displayCutoutPadding().verticalScroll(rememberScrollState()).padding(16.dp), content = content)
            }
        }
    }
}

@Composable
fun BoxScope.CenterPanel(visible: Boolean, wFrac: Float, hFrac: Float, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AnimatedVisibility(visible, enter = fadeIn(), exit = fadeOut()) {
        Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose))
    }
    AnimatedVisibility(
        visible, modifier = Modifier.align(Alignment.Center),
        enter = scaleIn(initialScale = 0.92f) + fadeIn(), exit = scaleOut(targetScale = 0.92f) + fadeOut()
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF6FA0FF))) {
            Surface(
                Modifier.fillMaxWidth(wFrac).fillMaxHeight(hFrac),
                color = Color(0xB3121212), contentColor = Color.White, shape = RoundedCornerShape(18.dp)
            ) { Column(Modifier.padding(14.dp), content = content) }
        }
    }
}

val EQ_PRESETS = listOf(
    "Flat" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Bass" to floatArrayOf(7f, 7f, 6f, 5f, 3f, 1f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Treble" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 2f, 3f, 4f, 5f, 6f, 6f),
    "Vocal" to floatArrayOf(-2f, -2f, -1f, 0f, 0f, 1f, 2f, 3f, 4f, 4f, 3f, 2f, 0f, -1f, -2f),
    "Rock" to floatArrayOf(5f, 4f, 3f, 2f, 0f, -1f, -2f, -1f, 1f, 2f, 3f, 4f, 4f, 4f, 3f),
    "Pop" to floatArrayOf(-1f, 0f, 1f, 2f, 3f, 3f, 2f, 0f, -1f, -1f, 0f, 1f, 2f, 2f, 1f),
    "Classical" to floatArrayOf(4f, 3f, 3f, 2f, 2f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 2f, 3f, 3f),
    "Loudness" to floatArrayOf(6f, 5f, 4f, 2f, 0f, 0f, -1f, 0f, 0f, 0f, 0f, 1f, 3f, 4f, 4f)
)

@Composable
fun ColumnScope.PanelTitle(t: String, onClose: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(t, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close") }
    }
}

@Composable
fun ColumnScope.EqPanel(onClose: () -> Unit) {
    val eqp = PlayerHolder.eq
    var on by remember { mutableStateOf(eqp.enabled) }
    val gains = remember { mutableStateListOf<Float>().apply { addAll(eqp.gains.toList()) } }
    fun push() { eqp.set(gains.toFloatArray(), on) }
    fun save() { Prefs.eqSave(gains.toFloatArray(), on) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Equalizer", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        Switch(checked = on, onCheckedChange = { on = it; push(); save() })
        IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close") }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        EQ_PRESETS.forEach { (n, g) ->
            FilterChip(selected = false, onClick = { g.forEachIndexed { i, v -> gains[i] = v }; push(); save() }, label = { Text(n) })
        }
    }
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        EqProcessor.LABELS.forEachIndexed { i, label ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, Modifier.width(58.dp), fontSize = 12.sp)
                Slider(
                    value = gains[i], onValueChange = { gains[i] = it; push() }, onValueChangeFinished = { save() },
                    valueRange = -12f..12f, modifier = Modifier.weight(1f)
                )
                Text("%+d dB".format(gains[i].roundToInt()), Modifier.width(54.dp), fontSize = 12.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ Player screen

@Composable
fun PlayerScreen(a: PlayerActivity) {
    val p = a.player
    val ctx = LocalContext.current
    val cfg = LocalConfiguration.current
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(true) }
    var title by remember { mutableStateOf("") }
    var idx by remember { mutableIntStateOf(0) }
    var rate by remember { mutableFloatStateOf(1f) }
    var controls by remember { mutableStateOf(true) }
    var expanded by remember { mutableStateOf(false) }
    var locked by remember { mutableStateOf(false) }
    var showUnlock by remember { mutableStateOf(false) }
    var night by remember { mutableStateOf(false) }
    var muted by remember { mutableStateOf(p.volume == 0f) }
    var shuffle by remember { mutableStateOf(p.shuffleModeEnabled) }
    var repeat by remember { mutableIntStateOf(p.repeatMode) }
    var seeking by remember { mutableStateOf(false) }
    var seekVal by remember { mutableFloatStateOf(0f) }
    var swipeFrac by remember { mutableFloatStateOf(-1f) }
    var hudText by remember { mutableStateOf("") }
    var hudSub by remember { mutableStateOf("") }
    var hudKind by remember { mutableIntStateOf(0) }
    var hudIcon by remember { mutableStateOf<ImageVector?>(null) }
    var hudKey by remember { mutableIntStateOf(0) }
    var indKind by remember { mutableIntStateOf(0) }
    var indPct by remember { mutableIntStateOf(0) }
    var indKey by remember { mutableIntStateOf(0) }
    var holdHud by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf("") }
    var lastDlg by remember { mutableStateOf("more") }
    var resize by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var scale by remember { mutableFloatStateOf(1f) }
    var tx by remember { mutableFloatStateOf(0f) }
    var ty by remember { mutableFloatStateOf(0f) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    var vw by remember { mutableFloatStateOf(0f) }
    var vh by remember { mutableFloatStateOf(0f) }
    var side by remember { mutableIntStateOf(0) }
    var drawSide by remember { mutableIntStateOf(1) }
    var acc by remember { mutableIntStateOf(0) }
    var sideKey by remember { mutableIntStateOf(0) }
    var rippleAt by remember { mutableStateOf(Offset.Zero) }
    var rippleKey by remember { mutableIntStateOf(0) }
    var tapKey by remember { mutableIntStateOf(0) }
    var tracks by remember { mutableStateOf(p.currentTracks) }
    val ripple = remember { Animatable(1f) }
    val pvRef = remember { arrayOfNulls<PlayerView>(1) }
    val pinching = remember { BooleanArray(1) }
    val hold = remember { BooleanArray(1) }
    val pendingToggle = remember { BooleanArray(1) }
    val lastTap = remember { LongArray(1) }
    val lastZone = remember { IntArray(1) { 9 } }
    val seriesUntil = remember { LongArray(1) }
    val seriesSide = remember { IntArray(1) { 9 } }

    DisposableEffect(Unit) {
        val l = object : Player.Listener { override fun onTracksChanged(t: Tracks) { tracks = t } }
        p.addListener(l)
        onDispose { p.removeListener(l) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            pos = p.currentPosition; dur = p.duration.coerceAtLeast(0L); playing = p.isPlaying
            title = p.mediaMetadata.title?.toString() ?: ""; idx = p.currentMediaItemIndex
            rate = p.playbackParameters.speed
            val vs = p.videoSize
            var w = vs.width * vs.pixelWidthHeightRatio; var h = vs.height.toFloat()
            if (vs.unappliedRotationDegrees % 180 != 0) { val t = w; w = h; h = t }
            vw = w; vh = h
            delay(if (controls || seeking) 250L else 1000L)
        }
    }
    LaunchedEffect(controls, playing, seeking, dlg) {
        if (controls && playing && !seeking && dlg == "") { delay(3500); controls = false }
    }
    LaunchedEffect(hudKey) { if (hudText.isNotEmpty()) { delay(if (hudKind == 2) 600L else 800L); hudText = "" } }
    LaunchedEffect(indKey) { if (indKind != 0) { delay(800); indKind = 0 } }
    LaunchedEffect(sideKey) { if (side != 0) { delay(650); side = 0 } }
    LaunchedEffect(rippleKey) { if (rippleKey > 0) { ripple.snapTo(0f); ripple.animateTo(1f, tween(480)) } }
    LaunchedEffect(showUnlock) { if (showUnlock) { delay(2000); showUnlock = false } }
    LaunchedEffect(dlg) { if (dlg != "") lastDlg = dlg }
    LaunchedEffect(a.audioOnly, idx) { a.updateKeep() }
    LaunchedEffect(tapKey) {
        if (tapKey > 0) { delay(280); if (pendingToggle[0]) { pendingToggle[0] = false; controls = !controls } }
    }
    BackHandler(enabled = dlg != "" || locked) { if (!locked) dlg = "" }
    val subLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) a.addSubtitle(u) }
    val bubbleAlpha by animateFloatAsState(if (side != 0) 1f else 0f, tween(if (side != 0) 90 else 320), label = "bubble")

    fun flash(s: String, icon: ImageVector? = null) { hudKind = 0; hudText = s; hudIcon = icon; hudKey++ }
    fun flashZoom(pct: Int) { hudKind = 1; hudText = "$pct%"; hudKey++ }
    fun flashSeek(t: String, d: String) { hudKind = 2; hudText = t; hudSub = d; hudKey++ }
    fun indicate(kind: Int, pct: Int) { indKind = kind; indPct = pct; indKey++ }
    fun toggle() {
        if (p.isPlaying) { p.pause(); flash("Paused", Icons.Default.Pause) }
        else { if (p.playbackState == Player.STATE_ENDED) p.seekTo(0); p.play(); flash("Playing", Icons.Default.PlayArrow) }
    }
    /** Skip by [sec]; consecutive skips on the same side add up inside the translucent bubble. */
    fun seek(sec: Int, at: Offset?) {
        val d = p.duration
        p.seekTo((p.currentPosition + sec * 1000L).coerceIn(0L, if (d > 0) d else Long.MAX_VALUE))
        val s = if (sec > 0) 1 else -1
        acc = if (side == s) acc + abs(sec) else abs(sec)
        side = s; drawSide = s; sideKey++
        if (at != null) { rippleAt = at; rippleKey++ }
    }
    /** The rectangle where the video is really visible (fit + user zoom). Gestures only work inside it. */
    fun rect(): Rect {
        val w = box.width.toFloat(); val h = box.height.toFloat()
        if (w <= 0f || h <= 0f) return Rect.Zero
        var l = 0f; var t = 0f; var r = w; var b = h
        val logo = a.audioOnly || a.queue.getOrNull(p.currentMediaItemIndex)?.audio == true
        if (!logo && vw > 0f && vh > 0f && resize == AspectRatioFrameLayout.RESIZE_MODE_FIT) {
            val s = minOf(w / vw, h / vh)
            val vWidth = vw * s; val vHeight = vh * s
            l = (w - vWidth) / 2f; t = (h - vHeight) / 2f; r = l + vWidth; b = t + vHeight
        }
        val cx = w / 2f; val cy = h / 2f
        return Rect(
            maxOf(0f, cx + tx + scale * (l - cx)), maxOf(0f, cy + ty + scale * (t - cy)),
            minOf(w, cx + tx + scale * (r - cx)), minOf(h, cy + ty + scale * (b - cy))
        )
    }
    /** -1 = left zone, 1 = right zone, 0 = center, 9 = outside / dead zone. */
    fun zoneOf(o: Offset): Int {
        val r = rect()
        if (r.width <= 0f || !r.contains(o)) return 9
        val fx = (o.x - r.left) / r.width; val fy = (o.y - r.top) / r.height
        if (fy < 0.1f || fy > 0.9f) return 9
        return if (fx in 0.04f..0.4f) -1 else if (fx in 0.6f..0.96f) 1 else if (fx in 0.4f..0.6f) 0 else 9
    }
    /** Pinch zoom, deliberately damped: the video follows about 80% of the finger movement. */
    fun zoomBy(c: Offset, zRaw: Float, panRaw: Offset) {
        val w = box.width.toFloat(); val h = box.height.toFloat()
        val z = zRaw.toDouble().pow(0.8).toFloat()
        val ns = (scale * z).coerceIn(0.25f, 6f)
        val k = ns / scale
        val ox = c.x - w / 2f; val oy = c.y - h / 2f
        val nx = ox - k * (ox - tx) + panRaw.x * 0.8f
        val ny = oy - k * (oy - ty) + panRaw.y * 0.8f
        val mx = maxOf(0f, w * (ns - 1f) / 2f); val my = maxOf(0f, h * (ns - 1f) / 2f)
        tx = nx.coerceIn(-mx, mx); ty = ny.coerceIn(-my, my); scale = ns
        flashZoom((ns * 100).roundToInt())
    }
    fun resetZoom() { scale = 1f; tx = 0f; ty = 0f }
    fun shot() {
        val bmp = (pvRef[0]?.videoSurfaceView as? TextureView)?.bitmap
        if (bmp == null) { flash("Screenshot unavailable"); return }
        Thread {
            var ok = false
            try {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "FastPlayer_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FastPlayer")
                }
                val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                if (u != null) {
                    ctx.contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    ok = true
                }
            } catch (_: Exception) {}
            a.runOnUiThread { flash(if (ok) "Screenshot saved" else "Screenshot failed") }
        }.start()
    }

    val showLogo = a.audioOnly || a.queue.getOrNull(idx)?.audio == true

    Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { box = it }) {
        AndroidView(
            factory = { c ->
                (LayoutInflater.from(c).inflate(R.layout.player_view, null) as PlayerView).also { it.player = p; pvRef[0] = it }
            },
            update = { v ->
                v.resizeMode = resize
                v.setShowBuffering(if (Prefs.loadingAnim) PlayerView.SHOW_BUFFERING_WHEN_PLAYING else PlayerView.SHOW_BUFFERING_NEVER)
                v.subtitleView?.let { sv ->
                    sv.setFractionalTextSize(0.0533f * Prefs.subSize)
                    sv.setStyle(
                        CaptionStyleCompat(
                            when (Prefs.subColor) { "yellow" -> android.graphics.Color.YELLOW; "cyan" -> android.graphics.Color.CYAN; else -> android.graphics.Color.WHITE },
                            if (Prefs.subBg == "black") 0xAA000000.toInt() else android.graphics.Color.TRANSPARENT,
                            android.graphics.Color.TRANSPARENT, CaptionStyleCompat.EDGE_TYPE_OUTLINE, android.graphics.Color.BLACK, null
                        )
                    )
                }
            },
            modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = tx; translationY = ty }
        )
        if (showLogo) Box(Modifier.fillMaxSize().background(Color(0xFF0A1A4A)), contentAlignment = Alignment.Center) {
            Image(painterResource(R.drawable.resume_logo), null, Modifier.size(140.dp))
        }
        if (night) Box(Modifier.fillMaxSize().background(Color(0x77000000)))

        if (locked) {
            Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { showUnlock = true } }) {
                AnimatedVisibility(showUnlock, Modifier.align(Alignment.CenterStart).padding(28.dp), enter = fadeIn(), exit = fadeOut()) {
                    IconButton(onClick = { locked = false }, modifier = Modifier.size(54.dp).background(Color(0x66000000), CircleShape)) {
                        Icon(Icons.Default.LockOpen, "Unlock", tint = Color.White)
                    }
                }
            }
        } else {
            // ---- gesture layer: everything works only on the visible video area ----
            Box(
                Modifier.fillMaxSize()
                    // two-finger pinch zoom + pan, anchored at the fingers
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val ev = awaitPointerEvent()
                                if (ev.changes.count { it.pressed } >= 2) {
                                    pinching[0] = true
                                    val z = ev.calculateZoom(); val pan = ev.calculatePan(); val c = ev.calculateCentroid(useCurrent = true)
                                    if (z != 1f || pan != Offset.Zero) {
                                        zoomBy(c, z, pan)
                                        ev.changes.forEach { if (it.positionChanged()) it.consume() }
                                    }
                                }
                            } while (ev.changes.any { it.pressed })
                            pinching[0] = false
                        }
                    }
                    // press & hold = fast speed; slide left/right while holding to change it
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            var cancelled = false
                            val r = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    if (c == null || !c.pressed || ev.changes.size > 1 ||
                                        (c.position - down.position).getDistance() > viewConfiguration.touchSlop
                                    ) { cancelled = true; break }
                                }
                            }
                            if (r == null && !cancelled && !pinching[0] && rect().contains(down.position)) {
                                hold[0] = true
                                val base = p.playbackParameters.speed
                                var cur = Prefs.holdSpeed
                                p.setPlaybackSpeed(cur)
                                holdHud = "%.2fx".format(cur)
                                var accX = 0f
                                val step = 30.dp.toPx()
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    if (c == null || !c.pressed) { c?.consume(); break }
                                    accX += c.positionChange().x
                                    val ns = (Prefs.holdSpeed + (accX / step).toInt() * 0.25f).coerceIn(0.25f, 4f)
                                    if (ns != cur) { cur = ns; p.setPlaybackSpeed(cur); holdHud = "%.2fx".format(cur) }
                                    c.consume()
                                }
                                p.setPlaybackSpeed(base)
                                holdHud = ""
                                hold[0] = false
                            }
                        }
                    }
                    // taps: single = show/hide controls, double = skip / pause, more taps keep skipping
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val up = waitForUpOrCancellation()
                            if (up != null && !pinching[0] && !hold[0] &&
                                up.uptimeMillis - down.uptimeMillis < viewConfiguration.longPressTimeoutMillis
                            ) {
                                val now = SystemClock.uptimeMillis()
                                val z = zoneOf(up.position)
                                if (Prefs.doubleTap && z != 9 && z != 0 && now < seriesUntil[0] && z == seriesSide[0]) {
                                    pendingToggle[0] = false
                                    seek(z * Prefs.seekSec, up.position); seriesUntil[0] = now + 600
                                } else if (Prefs.doubleTap && z != 9 && now - lastTap[0] < 300 && z == lastZone[0]) {
                                    pendingToggle[0] = false; lastTap[0] = 0L
                                    if (z == 0) toggle() else { seek(z * Prefs.seekSec, up.position); seriesSide[0] = z; seriesUntil[0] = now + 600 }
                                } else {
                                    lastTap[0] = now; lastZone[0] = z
                                    if (Prefs.doubleTap) { pendingToggle[0] = true; tapKey++ } else controls = !controls
                                }
                            }
                        }
                    }
                    // vertical swipe: left half = brightness (bar shows on the right), right half = volume (bar shows on the left)
                    .pointerInput(Unit) {
                        var mode = 0
                        detectVerticalDragGestures(
                            onDragStart = { o ->
                                val r = rect()
                                val inner = r.deflate(40.dp.toPx())
                                mode = if (!Prefs.swipe || pinching[0] || hold[0] || r.width <= 0f ||
                                    (if (inner.width > 0f && inner.height > 0f) !inner.contains(o) else !r.contains(o))
                                ) 0 else if (o.x < r.center.x) 1 else 2
                                a.syncVol()
                            },
                            onDragEnd = { mode = 0 }, onDragCancel = { mode = 0 },
                            onVerticalDrag = { change, dy ->
                                if (mode != 0 && !pinching[0]) {
                                    change.consume()
                                    val f = -dy / rect().height.coerceAtLeast(1f) * 1.2f
                                    if (mode == 1) indicate(1, a.addBright(f)) else indicate(2, a.addVolume(f))
                                }
                            }
                        )
                    }
                    // horizontal swipe: seek, shows the new time and the difference like [+00:50]
                    .pointerInput(Unit) {
                        var ok = false; var accX = 0f; var base = 0L; var target = 0L
                        detectHorizontalDragGestures(
                            onDragStart = { o ->
                                val r = rect()
                                val inner = r.deflate(40.dp.toPx())
                                ok = Prefs.swipe && !pinching[0] && !hold[0] && r.width > 0f &&
                                    (if (inner.width > 0f && inner.height > 0f) inner.contains(o) else r.contains(o))
                                accX = 0f; base = p.currentPosition; target = base
                            },
                            onDragEnd = { if (ok) p.seekTo(target); ok = false; swipeFrac = -1f },
                            onDragCancel = { ok = false; swipeFrac = -1f },
                            onHorizontalDrag = { change, dx ->
                                if (ok && !pinching[0]) {
                                    change.consume(); accX += dx
                                    val d = p.duration
                                    target = (base + (accX / rect().width.coerceAtLeast(1f) * 90000).toLong())
                                        .coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
                                    flashSeek(fmt(target), "[" + fmtDelta(target - base) + "]")
                                    swipeFrac = if (d > 0) (target.toFloat() / d).coerceIn(0f, 1f) else 0f
                                }
                            }
                        )
                    }
            )

            // double-tap bubble: big translucent circle on the tapped side + ripple that fades from the tap point
            if (bubbleAlpha > 0.01f) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = size.width; val h = size.height
                    val r = h * 1.9f
                    val frac = 0.34f
                    val cx = if (drawSide < 0) frac * w - r else w - frac * w + r
                    val circle = Path().apply { addOval(Rect(Offset(cx, h / 2f), r)) }
                    clipPath(circle) {
                        drawRect(Color.Black.copy(alpha = 0.22f * bubbleAlpha))
                        val pr = ripple.value
                        if (pr < 1f) drawCircle(
                            Color.Black.copy(alpha = 0.28f * (1f - pr)),
                            radius = pr * w * 0.45f, center = rippleAt
                        )
                    }
                }
                Box(
                    Modifier.fillMaxSize().graphicsLayer { alpha = bubbleAlpha }
                ) {
                    Column(
                        Modifier.align(if (drawSide < 0) Alignment.CenterStart else Alignment.CenterEnd)
                            .fillMaxWidth(0.34f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            if (drawSide < 0) Icons.Default.FastRewind else Icons.Default.FastForward,
                            null, tint = Color.White, modifier = Modifier.size(26.dp)
                        )
                        Text("${acc}s", color = Color.White, fontSize = 15.sp)
                    }
                }
            }

            // HUD: zoom %, seek time, paused/playing
            if (hudText.isNotEmpty()) when (hudKind) {
                1 -> Text(
                    hudText, Modifier.align(Alignment.Center), color = Color.White, fontSize = 44.sp,
                    fontWeight = FontWeight.Bold, style = TextStyle(shadow = SHADOW)
                )
                2 -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(hudText, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold, style = TextStyle(shadow = SHADOW))
                    Text(hudSub, color = Color.White, fontSize = 17.sp, style = TextStyle(shadow = SHADOW))
                }
                else -> Pill(hudText, hudIcon, Modifier.align(Alignment.Center))
            }
            if (holdHud.isNotEmpty()) Pill("▶▶  $holdHud", null, Modifier.align(Alignment.TopCenter).padding(top = 28.dp))

            // volume bar on the LEFT, brightness bar on the RIGHT (screen edges)
            if (indKind == 2) VBar(indPct, Icons.Default.VolumeUp, Modifier.align(Alignment.CenterStart).displayCutoutPadding().padding(start = 28.dp))
            if (indKind == 1) VBar(indPct, Icons.Default.BrightnessMedium, Modifier.align(Alignment.CenterEnd).displayCutoutPadding().padding(end = 28.dp))

            // slim progress bar while swipe-seeking (when the controls are hidden)
            if (swipeFrac >= 0f && !controls) Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000))))
                    .displayCutoutPadding().padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(fmt((swipeFrac * dur).toLong()), color = Color.White, fontSize = 12.sp)
                    Box(Modifier.weight(1f).padding(horizontal = 10.dp).height(3.dp).background(Color(0x55FFFFFF))) {
                        Box(Modifier.fillMaxWidth(swipeFrac.coerceIn(0f, 1f)).fillMaxHeight().background(Color(0xFF4F8DFF)))
                    }
                    Text(fmt(dur), color = Color.White, fontSize = 12.sp)
                }
            }

            // ---- controls ----
            AnimatedVisibility(controls && !a.inPip, enter = fadeIn(), exit = fadeOut()) {
                val allBtns = listOf(
                    Btn("night", Icons.Default.NightsStay, "Night Mode", night) { night = !night },
                    Btn("custom", Icons.Default.Edit, "Customise Items") { dlg = "custom" },
                    Btn("shuffle", Icons.Default.Shuffle, "Shuffle", shuffle) { shuffle = !shuffle; p.shuffleModeEnabled = shuffle },
                    Btn("loop", if (repeat == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat, "Loop", repeat != Player.REPEAT_MODE_OFF) {
                        repeat = when (repeat) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
                        p.repeatMode = repeat
                        flash(when (repeat) { Player.REPEAT_MODE_ALL -> "Loop all"; Player.REPEAT_MODE_ONE -> "Loop one"; else -> "Loop off" })
                    },
                    Btn("mute", if (muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, "Mute", muted) { muted = !muted; p.volume = if (muted) 0f else 1f },
                    Btn("sleep", Icons.Default.Timer, "Sleep Timer", a.sleepMin > 0) { dlg = "sleep" },
                    Btn("ab", Icons.Default.CompareArrows, "A - B Repeat", a.abA >= 0) { flash(a.cycleAB()) },
                    Btn("effect", Icons.Default.GraphicEq, "Audio Effect", a.boostDb > 0) { dlg = "effect" },
                    Btn("eq", Icons.Default.Equalizer, "Equalizer") { dlg = "eq" },
                    Btn("speed", null, "Speed", rate != 1f, text = (if (rate % 1f == 0f) "${rate.toInt()}" else "$rate") + "X") { dlg = "speed" },
                    Btn("shot", Icons.Default.PhotoCamera, "Screenshot") { shot() },
                    Btn("audio", Icons.Default.Headphones, "Background Play", a.audioOnly) { a.applyAudioOnly(!a.audioOnly) },
                    Btn("rotate", Icons.Default.ScreenRotation, "Screen Rotation") {
                        val land = a.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                        a.requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    }
                )
                val order = (Prefs.btnTop.split(",") + allBtns.map { it.key }).distinct()
                val btns = order.mapNotNull { k -> allBtns.firstOrNull { it.key == k } }
                Box(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                            .displayCutoutPadding().padding(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SmallIcon(Icons.AutoMirrored.Filled.ArrowBack, "Back") { a.finish() }
                            Text(title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            SmallIcon(Icons.Default.MusicNote, "Audio track") { dlg = "audio" }
                            SmallIcon(Icons.Default.Subtitles, "Subtitles") { dlg = "sub" }
                            SmallIcon(Icons.Default.MoreVert, "More") { dlg = "more" }
                        }
                        if (!expanded) {
                            // collapsed: a few buttons; drag right to pull the rest in one by one, or tap the arrow to open all
                            val shown = (cfg.screenWidthDp * 0.4f / 64f).toInt().coerceIn(2, 5)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(34.dp).background(DARK_BTN, CircleShape).clickable { expanded = true },
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.ChevronRight, "Show all", tint = Color.White) }
                                Box(Modifier.width((shown * 64 + 30).dp)) {
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                                        Row(Modifier.horizontalScroll(rememberScrollState())) {
                                            btns.forEach { RoundBtn(it, false) }
                                        }
                                    }
                                }
                            }
                        } else {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.Top) {
                                btns.forEach { RoundBtn(it, true) }
                                Box(
                                    Modifier.padding(start = 6.dp, top = 5.dp).size(34.dp).background(DARK_BTN, CircleShape).clickable { expanded = false },
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.ChevronLeft, "Collapse", tint = Color.White) }
                            }
                        }
                    }
                    Column(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                            .displayCutoutPadding().padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmt(if (seeking) (seekVal * dur).toLong() else pos), color = Color.White, fontSize = 12.sp)
                            Slider(
                                value = if (seeking) seekVal else if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
                                onValueChange = { seeking = true; seekVal = it },
                                onValueChangeFinished = { p.seekTo((seekVal * dur).toLong()); seeking = false },
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                            )
                            Text(fmt(dur), color = Color.White, fontSize = 12.sp)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            SmallIcon(Icons.Default.Lock, "Lock") { locked = true; controls = false }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                SmallIcon(Icons.Default.SkipPrevious, "Previous") {
                                    if (Prefs.smartPrev) p.seekToPrevious() else p.seekToPreviousMediaItem()
                                }
                                IconButton(onClick = { toggle() }, modifier = Modifier.size(56.dp)) {
                                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", tint = Color.White, modifier = Modifier.size(40.dp))
                                }
                                SmallIcon(Icons.Default.SkipNext, "Next") { p.seekToNextMediaItem() }
                            }
                            Row {
                                SmallIcon(Icons.Default.AspectRatio, "Aspect ratio") {
                                    resize = when (resize) {
                                        AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                        AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    }
                                    resetZoom()
                                    flash(when (resize) { AspectRatioFrameLayout.RESIZE_MODE_FIT -> "Fit"; AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Crop"; else -> "Stretch" })
                                }
                                SmallIcon(Icons.Default.PictureInPictureAlt, "Picture in picture") { a.enterPip() }
                            }
                        }
                    }
                }
            }
        }

        // ---- side panels (slide in from the RIGHT, translucent so the video stays visible) ----
        val kind = if (dlg != "") dlg else lastDlg
        val pw = (cfg.screenWidthDp * 0.5f).coerceIn(280f, 360f).coerceAtMost(cfg.screenWidthDp * 0.92f).dp
        SidePanel(dlg == "audio" || dlg == "sub" || dlg == "more", pw, { dlg = "" }) {
            when (kind) {
                "audio" -> {
                    PanelTitle("Audio track") { dlg = "" }
                    TrackSection("Tracks", p, tracks, C.TRACK_TYPE_AUDIO, false)
                }
                "sub" -> {
                    PanelTitle("Subtitles") { dlg = "" }
                    TrackSection("Tracks", p, tracks, C.TRACK_TYPE_TEXT, true)
                    TextButton(onClick = { subLauncher.launch(arrayOf("*/*")) }) { Text("Load subtitle file (.srt / .vtt / .ass)") }
                    PLabel("Text size")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0.8f to "S", 1f to "M", 1.3f to "L", 1.6f to "XL").forEach { (v, l) ->
                            FilterChip(selected = Prefs.subSize == v, onClick = { Prefs.subSize = v; Prefs.save() }, label = { Text(l) })
                        }
                    }
                }
                else -> {
                    PanelTitle("Player settings") { dlg = "" }
                    PLabel("Double-tap skip")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(5, 10, 15, 20, 30, 60).forEach { s ->
                            FilterChip(selected = Prefs.seekSec == s, onClick = { Prefs.seekSec = s; Prefs.save() }, label = { Text("${s}s") })
                        }
                    }
                    PLabel("Controls")
                    PSwitch("Double-tap gestures", Prefs.doubleTap) { Prefs.doubleTap = it; Prefs.save() }
                    PSwitch("Swipe gestures", Prefs.swipe) { Prefs.swipe = it; Prefs.save() }
                    PSwitch("Play next automatically", Prefs.autoNext) { Prefs.autoNext = it; Prefs.save() }
                    PSwitch("Remember position", Prefs.resume) { Prefs.resume = it; Prefs.save() }
                }
            }
        }

        // ---- small floating windows in the middle (equalizer, speed, sleep timer, audio effect, customise) ----
        val land = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE
        CenterPanel(
            dlg in listOf("eq", "speed", "sleep", "effect", "custom"),
            if (land) (if (kind == "eq") 0.55f else 0.5f) else 0.92f,
            if (land) (if (kind == "eq") 0.88f else 0.75f) else (if (kind == "eq") 0.62f else 0.5f),
            { dlg = "" }
        ) {
            when (kind) {
                "eq" -> EqPanel { dlg = "" }
                "speed" -> {
                    PanelTitle("Playback speed") { dlg = "" }
                    listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f, 4f).chunked(4).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { s ->
                                FilterChip(selected = rate == s, onClick = { p.setPlaybackSpeed(s); rate = s }, label = { Text("${s}x") })
                            }
                        }
                    }
                }
                "sleep" -> {
                    PanelTitle("Sleep timer") { dlg = "" }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0, 15, 30, 45, 60, 90).forEach { m ->
                            FilterChip(selected = a.sleepMin == m, onClick = { a.setSleep(m) }, label = { Text(if (m == 0) "Off" else "${m} min") })
                        }
                    }
                }
                "effect" -> {
                    PanelTitle("Audio effect: volume boost") { dlg = "" }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0, 3, 6, 9, 12).forEach { d ->
                            FilterChip(selected = a.boostDb == d, onClick = { a.setBoost(d) }, label = { Text(if (d == 0) "Off" else "+$d dB") })
                        }
                    }
                }
                else -> {
                    PanelTitle("Customise items") { dlg = "" }
                    Text("Checked buttons appear first in the row.", fontSize = 12.sp, color = Color(0x99FFFFFF))
                    val keys = listOf(
                        "night" to "Night Mode", "shuffle" to "Shuffle", "loop" to "Loop", "mute" to "Mute", "sleep" to "Sleep Timer",
                        "ab" to "A - B Repeat", "effect" to "Audio Effect", "eq" to "Equalizer", "speed" to "Speed",
                        "shot" to "Screenshot", "audio" to "Background Play", "rotate" to "Screen Rotation"
                    )
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        keys.forEach { (k, l) ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    val cur = Prefs.btnTop.split(",").filter { it.isNotEmpty() }.toMutableList()
                                    if (cur.contains(k)) cur.remove(k) else cur.add(k)
                                    Prefs.btnTop = cur.joinToString(","); Prefs.save()
                                }.padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(checked = Prefs.btnTop.split(",").contains(k), onCheckedChange = null)
                                Spacer(Modifier.width(10.dp)); Text(l)
                            }
                        }
                    }
                }
            }
        }
    }
}
