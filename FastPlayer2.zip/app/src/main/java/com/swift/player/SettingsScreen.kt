package com.swift.player

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import android.widget.Toast

private val THEMES = listOf("system" to "System", "light" to "Light", "dark" to "Dark", "amoled" to "AMOLED", "blue" to "Ocean")
private val FONTS = listOf("0.9" to "Small", "1.0" to "Default", "1.15" to "Large", "1.3" to "Extra large")
private val ORIENTS = listOf(
    "auto" to "Auto (sensor)", "landscape" to "Landscape", "portrait" to "Portrait",
    "system" to "System default", "video" to "Based on video size"
)

/** Me tab (page == null) and every Settings sub page. */
@Composable
fun SettingsHost(page: String?, go: (String?) -> Unit) {
    when (page) {
        null -> MeHome(go)
        "main" -> SettingsMain(go)
        "list" -> ListSettings()
        "player" -> PlayerSettings()
        "audio" -> AudioSettings()
        "subtitle" -> SubtitleSettings()
        else -> GeneralSettings()
    }
}

@Composable
fun MeHome(go: (String?) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painterResource(R.drawable.resume_logo), null,
                Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
            )
            Column(Modifier.padding(start = 16.dp)) {
                Text("Fast Player", style = MaterialTheme.typography.titleLarge)
                Text("Version 1.2", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        ListItem(
            headlineContent = { Text("Settings") },
            supportingContent = { Text("List, Player, Audio, Subtitle, General") },
            leadingContent = { Icon(Icons.Default.Settings, null, tint = MaterialTheme.colorScheme.primary) },
            modifier = Modifier.clickable { go("main") }
        )
        Section("Quick settings")
        Text("Theme", Modifier.padding(start = 16.dp, top = 8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            THEMES.forEach { (k, l) ->
                FilterChip(selected = Prefs.theme == k, onClick = { Prefs.theme = k; Prefs.save() }, label = { Text(l) })
            }
        }
        Text("Font size", Modifier.padding(start = 16.dp, top = 8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FONTS.forEach { (k, l) ->
                FilterChip(selected = Prefs.fontScale == k.toFloat(), onClick = { Prefs.fontScale = k.toFloat(); Prefs.save() }, label = { Text(l) })
            }
        }
        Text("Double-tap skip", Modifier.padding(start = 16.dp, top = 8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 10, 15, 20, 30).forEach { s ->
                FilterChip(selected = Prefs.seekSec == s, onClick = { Prefs.seekSec = s; Prefs.save() }, label = { Text("${s}s") })
            }
        }
        Sw("Floating resume button", "Quick button to continue the last played media", Prefs.floatBtn) { Prefs.floatBtn = it; Prefs.save() }
        Sw("Remember position", "Continue from where you stopped", Prefs.resume) { Prefs.resume = it; Prefs.save() }
        Spacer(Modifier.height(90.dp))
    }
}

@Composable
private fun NavRow(icon: ImageVector, title: String, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        leadingContent = { Icon(icon, null) },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
fun SettingsMain(go: (String?) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        NavRow(Icons.Default.ViewList, "List") { go("list") }
        NavRow(Icons.Default.PlayCircle, "Player") { go("player") }
        NavRow(Icons.Default.MusicNote, "Audio") { go("audio") }
        NavRow(Icons.Default.Subtitles, "Subtitle") { go("subtitle") }
        NavRow(Icons.Default.Info, "General") { go("general") }
    }
}

@Composable
fun ListSettings() {
    var dlg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Section("Appearance")
        Sw("Last media in each folder", "Mark last played media in blue", Prefs.lastMark) { Prefs.lastMark = it; Prefs.save() }
        Sw("Scroll down to last media", "Auto-scroll to the last played media", Prefs.scrollLast) { Prefs.scrollLast = it; Prefs.save() }
        Sw("Floating button", "Button at the bottom right to play the last media", Prefs.floatBtn) { Prefs.floatBtn = it; Prefs.save() }
        RowItem("Period tagged as \"NEW\"", if (Prefs.newDays == 0) "Off" else "${Prefs.newDays} day(s)") { dlg = "new" }
        Section("Scan")
        RowItem("Folders", "Select folders to include in the library") { dlg = "folders" }
        Sw("Show hidden files and folders", "Show folders starting with a dot", Prefs.showHidden) { Prefs.showHidden = it; Prefs.save() }
        Spacer(Modifier.height(40.dp))
    }
    when (dlg) {
        "new" -> RadioDlg("Period tagged as NEW", listOf("0" to "Off", "1" to "1 day", "3" to "3 days", "7" to "7 days"),
            Prefs.newDays.toString(), { Prefs.newDays = it.toInt(); Prefs.save() }) { dlg = "" }
        "folders" -> FoldersDlg { dlg = "" }
    }
}

@Composable
fun FoldersDlg(onClose: () -> Unit) {
    val ex = Prefs.excluded
    val set = remember(ex) { Prefs.excludedSet() }
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Folders") },
        text = {
            if (LibCache.paths.isEmpty()) Text("No folders found yet.")
            else LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(LibCache.paths, key = { it }) { p ->
                    Row(Modifier.fillMaxWidth().clickable { Prefs.toggleExcluded(p) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = p !in set, onCheckedChange = null)
                        Spacer(Modifier.width(10.dp))
                        Text(if (p.isEmpty()) "Internal" else p.trimEnd('/'), maxLines = 2)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } }
    )
}

@Composable
fun PlayerSettings() {
    var dlg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Section("Interface")
        RowItem("Screen orientation", ORIENTS.first { it.first == Prefs.orient }.second) { dlg = "orient" }
        Sw("Keep screen on", "While a video is playing", Prefs.keepOn) { Prefs.keepOn = it; Prefs.save() }
        RowItem("Double-tap skip", "${Prefs.seekSec} seconds") { dlg = "seek" }
        RowItem("Press & hold speed", "${Prefs.holdSpeed}x") { dlg = "hold" }
        Sw("Double-tap gestures", "Left/right to skip, center to pause", Prefs.doubleTap) { Prefs.doubleTap = it; Prefs.save() }
        Sw("Swipe gestures", "Volume, brightness and seek by swiping", Prefs.swipe) { Prefs.swipe = it; Prefs.save() }
        Sw("Double-tap the back button", "Press back twice to close the playback screen", Prefs.doubleBack) { Prefs.doubleBack = it; Prefs.save() }
        Section("Playback")
        Sw("Resume", "Continue from the point where you stopped", Prefs.resume) { Prefs.resume = it; Prefs.save() }
        RowItem("Default playback speed", "${Prefs.defSpeed}x") { dlg = "speed" }
        Sw("Play next automatically", "Go to the next item when finished", Prefs.autoNext) { Prefs.autoNext = it; Prefs.save() }
        Sw("Back to list", "Return to the list after playback is completed", Prefs.backToList) { Prefs.backToList = it; Prefs.save() }
        Sw("Fast seeking", "Seek to the nearest key-frame instead of the exact position", Prefs.fastSeek) { Prefs.fastSeek = it; Prefs.save() }
        Sw("Smart previous button", "Restart the video first, then go to the previous one", Prefs.smartPrev) { Prefs.smartPrev = it; Prefs.save() }
        Sw("Suppress error message", "Skip to the next video if loading fails", Prefs.suppressErr) { Prefs.suppressErr = it; Prefs.save() }
        Sw("Loading circle animation", "Show a spinner while buffering", Prefs.loadingAnim) { Prefs.loadingAnim = it; Prefs.save() }
        Section("Background play")
        RowItem("Background / PiP mode", when (Prefs.bgMode) { "audio" -> "Keep playing audio"; "pip" -> "Picture-in-Picture"; else -> "Pause" }) { dlg = "bg" }
        Spacer(Modifier.height(40.dp))
    }
    when (dlg) {
        "orient" -> RadioDlg("Screen orientation", ORIENTS, Prefs.orient, { Prefs.orient = it; Prefs.save() }) { dlg = "" }
        "seek" -> SeekDlg { dlg = "" }
        "hold" -> RadioDlg("Press & hold speed", listOf("1.5" to "1.5x", "2.0" to "2x", "3.0" to "3x", "4.0" to "4x"),
            Prefs.holdSpeed.toString(), { Prefs.holdSpeed = it.toFloat(); Prefs.save() }) { dlg = "" }
        "speed" -> RadioDlg("Default playback speed", listOf("0.5" to "0.5x", "0.75" to "0.75x", "1.0" to "1x", "1.25" to "1.25x", "1.5" to "1.5x", "2.0" to "2x"),
            Prefs.defSpeed.toString(), { Prefs.defSpeed = it.toFloat(); Prefs.save() }) { dlg = "" }
        "bg" -> RadioDlg("Background / PiP mode", listOf("pause" to "Pause", "audio" to "Keep playing audio", "pip" to "Picture-in-Picture"),
            Prefs.bgMode, { Prefs.bgMode = it; Prefs.save() }) { dlg = "" }
    }
}

@Composable
fun AudioSettings() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Section("Audio")
        Sw("Play alone", "Pause other players while playing", Prefs.playAlone) { Prefs.playAlone = it; Prefs.save() }
        Sw("Pause when headphones disconnect", "Stops playback if headphones are unplugged", Prefs.noisy) { Prefs.noisy = it; Prefs.save() }
        Text(
            "Equalizer (15 bands) and Audio Effect are in the player: tap the arrow next to the top buttons.",
            Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun SubtitleSettings() {
    var dlg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Section("Appearance")
        RowItem("Text size", when (Prefs.subSize) { 0.8f -> "Small"; 1.3f -> "Large"; 1.6f -> "Huge"; else -> "Normal" }) { dlg = "size" }
        RowItem("Text color", Prefs.subColor.replaceFirstChar { it.uppercase() }) { dlg = "color" }
        RowItem("Background", if (Prefs.subBg == "none") "None" else "Black") { dlg = "bg" }
    }
    when (dlg) {
        "size" -> RadioDlg("Text size", listOf("0.8" to "Small", "1.0" to "Normal", "1.3" to "Large", "1.6" to "Huge"),
            Prefs.subSize.toString(), { Prefs.subSize = it.toFloat(); Prefs.save() }) { dlg = "" }
        "color" -> RadioDlg("Text color", listOf("white" to "White", "yellow" to "Yellow", "cyan" to "Cyan"),
            Prefs.subColor, { Prefs.subColor = it; Prefs.save() }) { dlg = "" }
        "bg" -> RadioDlg("Background", listOf("none" to "None", "black" to "Black"),
            Prefs.subBg, { Prefs.subBg = it; Prefs.save() }) { dlg = "" }
    }
}

@Composable
fun GeneralSettings() {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Section("User data")
        Sw("Cache thumbnail", "Keep thumbnails on the device for faster lists", Prefs.cacheThumb) { Prefs.cacheThumb = it; Prefs.save() }
        RowItem("Clear thumbnail cache", "Thumbnails are generated again when the list is opened") {
            Img.loader?.diskCache?.clear(); Img.loader?.memoryCache?.clear()
            Toast.makeText(ctx, "Thumbnail cache cleared", Toast.LENGTH_SHORT).show()
        }
        RowItem("Clear history", "Clear playback positions and the last played item") { dlg = "history" }
        RowItem("Reset settings", "Reset all settings to their default condition") { dlg = "reset" }
        Section("About")
        RowItem("Fast Player", "Version 1.2") { }
    }
    if (dlg == "history") ConfirmDlg("Clear history?", "Playback positions and the last played item will be removed.", { dlg = "" }) { Prefs.clearHistory() }
    if (dlg == "reset") ConfirmDlg("Reset settings?", "All settings return to their defaults. Playlists are kept.", { dlg = "" }) { Prefs.resetSettings() }
}

@Composable
fun ConfirmDlg(title: String, msg: String, onClose: () -> Unit, onOk: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, title = { Text(title) }, text = { Text(msg) },
        confirmButton = { TextButton(onClick = { onOk(); onClose() }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun Section(t: String) {
    Text(t, Modifier.padding(start = 16.dp, top = 18.dp, bottom = 4.dp), color = MaterialTheme.colorScheme.primary,
        style = MaterialTheme.typography.labelLarge)
}

@Composable
fun RowItem(title: String, summary: String, onClick: () -> Unit) {
    ListItem(headlineContent = { Text(title) }, supportingContent = { Text(summary) }, modifier = Modifier.clickable(onClick = onClick))
}

@Composable
fun Sw(title: String, summary: String, value: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) }, supportingContent = { Text(summary) },
        trailingContent = { Switch(checked = value, onCheckedChange = onChange) },
        modifier = Modifier.clickable { onChange(!value) }
    )
}

@Composable
fun RadioDlg(title: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, title = { Text(title) },
        text = {
            Column {
                options.forEach { (k, l) ->
                    Row(Modifier.fillMaxWidth().clickable { onSelect(k); onClose() }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = k == selected, onClick = null)
                        Spacer(Modifier.width(12.dp)); Text(l)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

@Composable
fun SeekDlg(onClose: () -> Unit) {
    var t by remember { mutableStateOf(Prefs.seekSec.toString()) }
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Double-tap skip (seconds)") },
        text = {
            Column {
                OutlinedTextField(t, { t = it.filter(Char::isDigit).take(3) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("Seconds (1–300)") })
                Spacer(Modifier.height(8.dp))
                Text("Suggestions", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(5, 10, 15, 20, 30).forEach { s ->
                        FilterChip(selected = t == s.toString(), onClick = { t = s.toString() }, label = { Text("$s") })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { t.toIntOrNull()?.let { if (it in 1..300) { Prefs.seekSec = it; Prefs.save() } }; onClose() }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
