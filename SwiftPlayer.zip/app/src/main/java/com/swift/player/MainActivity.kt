package com.swift.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Root() }
            }
        }
    }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    fun ok() = perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }
    var granted by remember { mutableStateOf(ok()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = ok() }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(perms) }
    if (granted) Home() else Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Storage permission is needed to find your videos and audio.")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { launcher.launch(perms) }) { Text("Grant permission") }
    }
}

fun sortList(l: List<Media>, by: String, asc: Boolean): List<Media> {
    val s = when (by) {
        "name" -> l.sortedBy { it.title.lowercase() }
        "size" -> l.sortedBy { it.size }
        "duration" -> l.sortedBy { it.durationMs }
        else -> l.sortedBy { it.added }
    }
    return if (asc) s else s.reversed()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Home() {
    val ctx = LocalContext.current
    val act = ctx as ComponentActivity
    var tab by remember { mutableIntStateOf(0) }
    var videos by remember { mutableStateOf<List<Media>>(emptyList()) }
    var audios by remember { mutableStateOf<List<Media>>(emptyList()) }
    var reload by remember { mutableIntStateOf(0) }
    var vFolder by remember { mutableStateOf<String?>(null) }
    var aFolder by remember { mutableStateOf<String?>(null) }
    var plOpen by remember { mutableStateOf<String?>(null) }
    var sortBy by remember { mutableStateOf("date") }
    var asc by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var createDlg by remember { mutableStateOf(false) }
    val loader = remember { ImageLoader.Builder(ctx).components { add(VideoFrameDecoder.Factory()) }.build() }

    DisposableEffect(Unit) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) reload++ }
        act.lifecycle.addObserver(o)
        onDispose { act.lifecycle.removeObserver(o) }
    }
    LaunchedEffect(reload) {
        withContext(Dispatchers.IO) {
            videos = MediaRepo.load(ctx, false)
            audios = MediaRepo.load(ctx, true)
        }
    }
    BackHandler(enabled = (tab == 0 && vFolder != null) || (tab == 1 && aFolder != null) || (tab == 2 && plOpen != null)) {
        when (tab) { 0 -> vFolder = null; 1 -> aFolder = null; 2 -> plOpen = null }
    }
    val title = when (tab) { 0 -> vFolder ?: "Videos"; 1 -> aFolder ?: "Audio"; 2 -> plOpen ?: "Playlists"; else -> "Settings" }
    val inFolder = (tab == 0 && vFolder != null) || (tab == 1 && aFolder != null) || (tab == 2 && plOpen != null)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    if (inFolder) IconButton(onClick = { when (tab) { 0 -> vFolder = null; 1 -> aFolder = null; 2 -> plOpen = null } }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    if (tab < 2) {
                        IconButton(onClick = { reload++ }) { Icon(Icons.Default.Refresh, "Refresh") }
                        Box {
                            IconButton(onClick = { sortMenu = true }) { Icon(Icons.Default.Sort, "Sort") }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                listOf("date" to "Date", "name" to "Name", "size" to "Size", "duration" to "Length").forEach { (k, l) ->
                                    DropdownMenuItem(
                                        text = { Text(l + if (sortBy == k) (if (asc) "  ↑" else "  ↓") else "") },
                                        onClick = { if (sortBy == k) asc = !asc else { sortBy = k; asc = false }; sortMenu = false }
                                    )
                                }
                            }
                        }
                    }
                    if (tab == 2 && plOpen == null) IconButton(onClick = { createDlg = true }) { Icon(Icons.Default.Add, "New playlist") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf("Video" to Icons.Default.VideoLibrary, "Audio" to Icons.Default.MusicNote,
                    "Playlist" to Icons.Default.QueueMusic, "Settings" to Icons.Default.Settings
                ).forEachIndexed { i, (l, ic) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, l) }, label = { Text(l) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> MediaBrowser(sortList(videos, sortBy, asc), vFolder, { vFolder = it }, loader)
                1 -> MediaBrowser(sortList(audios, sortBy, asc), aFolder, { aFolder = it }, loader)
                2 -> PlaylistScreen(plOpen) { plOpen = it }
                else -> SettingsScreen()
            }
            if (tab != 3 && Prefs.lastUri.isNotEmpty()) {
                Box(
                    Modifier.align(Alignment.BottomEnd).padding(16.dp).size(58.dp)
                        .shadow(8.dp, CircleShape).clip(CircleShape)
                        .clickable { launchPlayer(ctx, listOf(QItem(Prefs.lastUri, Prefs.lastTitle, Prefs.lastAudio)), 0) }
                ) {
                    Image(painterResource(R.drawable.resume_logo), "Resume last", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
            }
        }
    }
    if (createDlg) NameDialog("New playlist", { createDlg = false }) { Prefs.plCreate(it) }
}

@Composable
fun NameDialog(title: String, onClose: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose, title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, singleLine = true, label = { Text("Name") }) },
        confirmButton = { TextButton(onClick = { onOk(t); onClose() }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun Empty(msg: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant) }
}

@Composable
fun MediaBrowser(items: List<Media>, folder: String?, onFolder: (String?) -> Unit, loader: ImageLoader) {
    val ctx = LocalContext.current
    var addTarget by remember { mutableStateOf<Media?>(null) }
    if (items.isEmpty()) { Empty("No media found"); return }
    if (folder == null) {
        val groups = remember(items) { items.groupBy { it.folder }.toList().sortedBy { it.first.lowercase() } }
        LazyColumn(Modifier.fillMaxSize()) {
            items(groups, key = { it.first }) { (name, list) ->
                ListItem(
                    headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text("${list.size} items") },
                    leadingContent = { Icon(Icons.Default.Folder, null, tint = MaterialTheme.colorScheme.primary) },
                    modifier = Modifier.clickable { onFolder(name) }
                )
            }
        }
    } else {
        val list = remember(items, folder) { items.filter { it.folder == folder } }
        val queue = remember(list) { list.map { QItem(it.uri.toString(), it.title, it.audio) } }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
            itemsIndexed(list, key = { _, m -> m.id }) { i, m ->
                MediaRow(m, loader, { launchPlayer(ctx, queue, i) }, { addTarget = m })
            }
        }
    }
    addTarget?.let { m -> AddToPlaylistDialog(m) { addTarget = null } }
}

@Composable
fun MediaRow(m: Media, loader: ImageLoader, onClick: () -> Unit, onAdd: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(width = 104.dp, height = 60.dp).clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
            if (m.audio) Icon(Icons.Default.MusicNote, null, Modifier.align(Alignment.Center))
            else AsyncImage(model = m.uri, imageLoader = loader, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            Text(fmt(m.durationMs), fontSize = 11.sp, color = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).background(Color(0xAA000000)).padding(horizontal = 4.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(m.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            Text(sizeText(m.size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { menu = false; onAdd() })
            }
        }
    }
}

@Composable
fun AddToPlaylistDialog(m: Media, onClose: () -> Unit) {
    val tick = Prefs.playlistTick
    val names = remember(tick) { Prefs.plNames() }
    var nn by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Add to playlist") },
        text = {
            Column {
                names.forEach { n ->
                    Text(n, Modifier.fillMaxWidth().clickable { Prefs.plAdd(n, m.uri.toString(), m.title); onClose() }.padding(vertical = 12.dp))
                }
                OutlinedTextField(nn, { nn = it }, singleLine = true, label = { Text("New playlist") })
            }
        },
        confirmButton = {
            TextButton(onClick = { if (nn.isNotBlank()) { Prefs.plCreate(nn); Prefs.plAdd(nn.trim(), m.uri.toString(), m.title) }; onClose() }) { Text("Create & add") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun PlaylistScreen(open: String?, onOpen: (String?) -> Unit) {
    val ctx = LocalContext.current
    val tick = Prefs.playlistTick
    if (open == null) {
        val names = remember(tick) { Prefs.plNames() }
        if (names.isEmpty()) { Empty("No playlists yet. Tap + to create one."); return }
        LazyColumn(Modifier.fillMaxSize()) {
            items(names, key = { it }) { n ->
                ListItem(
                    headlineContent = { Text(n) },
                    supportingContent = { Text("${Prefs.plItems(n).size} items") },
                    leadingContent = { Icon(Icons.Default.QueueMusic, null, tint = MaterialTheme.colorScheme.primary) },
                    trailingContent = { IconButton(onClick = { Prefs.plDelete(n) }) { Icon(Icons.Default.Delete, "Delete") } },
                    modifier = Modifier.clickable { onOpen(n) }
                )
            }
        }
    } else {
        val its = remember(tick, open) { Prefs.plItems(open) }
        if (its.isEmpty()) { Empty("Empty playlist. Use ⋮ on a video/audio to add."); return }
        val queue = remember(its) { its.map { QItem(it.first, it.second, it.first.contains("/audio/")) } }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
            itemsIndexed(its) { i, (_, t) ->
                ListItem(
                    headlineContent = { Text(t, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                    leadingContent = { Icon(if (queue[i].audio) Icons.Default.MusicNote else Icons.Default.PlayCircle, null) },
                    modifier = Modifier.clickable { launchPlayer(ctx, queue, i) }
                )
            }
        }
    }
}
