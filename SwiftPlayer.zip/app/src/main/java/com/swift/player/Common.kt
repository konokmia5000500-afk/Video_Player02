package com.swift.player

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

data class Media(
    val id: Long, val uri: Uri, val title: String, val folder: String,
    val durationMs: Long, val size: Long, val added: Long, val audio: Boolean
)

data class QItem(val uri: String, val title: String, val audio: Boolean)

/** Process-wide play queue: avoids Intent size limits for big folders. */
object PlayQueue { var items: List<QItem> = emptyList() }

fun launchPlayer(ctx: Context, list: List<QItem>, index: Int) {
    PlayQueue.items = list
    ctx.startActivity(Intent(ctx, PlayerActivity::class.java).putExtra("index", index))
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

fun sizeText(b: Long) = if (b >= 1_073_741_824L) "%.2f GB".format(b / 1073741824.0) else "%.1f MB".format(b / 1048576.0)

object MediaRepo {
    fun load(ctx: Context, audio: Boolean): List<Media> {
        val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME, MediaStore.MediaColumns.DURATION,
            MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED
        )
        val out = ArrayList<Media>()
        try {
            ctx.contentResolver.query(coll, proj, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    out.add(Media(id, ContentUris.withAppendedId(coll, id), c.getString(1) ?: "",
                        c.getString(2) ?: "Internal", c.getLong(3), c.getLong(4), c.getLong(5), audio))
                }
            }
        } catch (_: Exception) {}
        return out
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    val darkBase = darkColorScheme(primary = Color(0xFF6FA0FF))
    val scheme = when (Prefs.theme) {
        "light" -> lightColorScheme(primary = Color(0xFF1E5BFF))
        "dark" -> darkBase
        "amoled" -> darkColorScheme(primary = Color(0xFF6FA0FF), background = Color.Black, surface = Color.Black)
        "blue" -> darkColorScheme(primary = Color(0xFF4FC3F7), background = Color(0xFF0A1A4A), surface = Color(0xFF10246B))
        else -> if (sys) darkBase else lightColorScheme(primary = Color(0xFF1E5BFF))
    }
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * Prefs.fontScale)) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
