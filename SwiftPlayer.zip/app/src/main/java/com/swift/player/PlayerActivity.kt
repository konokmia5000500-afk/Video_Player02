@file:OptIn(UnstableApi::class)

package com.swift.player

import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

class PlayerActivity : ComponentActivity() {
    lateinit var player: ExoPlayer
    lateinit var queue: List<QItem>
    private var eq: Equalizer? = null
    var inPip by mutableStateOf(false)
    var audioOnly by mutableStateOf(false)
    private var bright = -1f
    private var volF = -1f
    private val am by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)

        val d = intent?.data
        queue = if (d != null) listOf(QItem(d.toString(), d.lastPathSegment ?: "Media", intent.type?.startsWith("audio") == true))
        else PlayQueue.items
        val start = if (d != null) 0 else intent.getIntExtra("index", 0).coerceIn(0, (queue.size - 1).coerceAtLeast(0))
        if (queue.isEmpty()) { finish(); return }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).run {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (Prefs.keepOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = when (Prefs.orient) {
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            "system" -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR
        }

        // Small buffers = video starts almost instantly; CLOSEST_SYNC = seeks jump to nearest keyframe (no long loading)
        val lc = DefaultLoadControl.Builder().setBufferDurationsMs(2000, 12000, 250, 700).build()
        player = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setLoadControl(lc).build().apply {
                setSeekParameters(SeekParameters.CLOSEST_SYNC)
                setHandleAudioBecomingNoisy(true)
                setAudioAttributes(AudioAttributes.DEFAULT, true)
                repeatMode = if (Prefs.loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        saveLast()
                        if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && !Prefs.autoNext) pause()
                    }
                    override fun onVideoSizeChanged(v: VideoSize) {
                        if (Prefs.orient == "video" && v.width > 0) requestedOrientation =
                            if (v.width >= v.height) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    }
                })
            }
        val items = queue.map {
            MediaItem.Builder().setUri(it.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).build()).build()
        }
        val sp = if (Prefs.resume) Prefs.pos(queue[start].uri) else 0L
        player.setMediaItems(items, start, if (sp > 0) sp else C.TIME_UNSET)
        player.prepare()
        player.playWhenReady = true

        setContent { AppTheme { PlayerScreen(this) } }
    }

    fun isAudioNow(): Boolean = audioOnly || queue.getOrNull(player.currentMediaItemIndex)?.audio == true

    fun saveLast() {
        if (!::player.isInitialized) return
        val q = queue.getOrNull(player.currentMediaItemIndex) ?: return
        val dur = player.duration; val p = player.currentPosition
        Prefs.setPos(q.uri, if (dur > 0 && p > dur - 3000) 0 else p)
        Prefs.lastUri = q.uri; Prefs.lastTitle = q.title; Prefs.lastAudio = q.audio; Prefs.save()
    }

    override fun onStop() {
        super.onStop()
        if (!::player.isInitialized) return
        saveLast()
        if (!isInPictureInPictureMode && !isAudioNow()) player.pause()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (::player.isInitialized && Prefs.pipHome && player.isPlaying && !isAudioNow()) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }

    override fun onDestroy() {
        super.onDestroy()
        eq?.release()
        if (::player.isInitialized) { saveLast(); player.release() }
    }

    fun enterPip() {
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        } catch (_: Exception) {}
    }

    fun setAudioOnly(v: Boolean) {
        audioOnly = v
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, v).build()
    }

    fun equalizer(): Equalizer? {
        if (eq == null) eq = try { Equalizer(0, player.audioSessionId).also { it.setEnabled(true) } } catch (_: Exception) { null }
        return eq
    }

    // ---- System brightness (window) / system media volume ----
    fun addBright(f: Float): Int {
        if (bright < 0) bright = try {
            android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Exception) { 0.5f }
        bright = (bright + f).coerceIn(0.01f, 1f)
        window.attributes = window.attributes.also { it.screenBrightness = bright }
        return (bright * 100).roundToInt()
    }
    fun syncVol() { volF = -1f }
    fun addVolume(f: Float): Int {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (volF < 0) volF = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
        volF = (volF + f).coerceIn(0f, 1f)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (volF * max).roundToInt(), 0)
        return (volF * 100).roundToInt()
    }
}

@Composable
fun CtlBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, active: Boolean = false, onClick: () -> Unit) {
    IconButton(
        onClick = onClick,
        modifier = Modifier.padding(end = 8.dp).size(40.dp)
            .background(if (active) Color(0xFF2F6BFF) else Color(0x44FFFFFF), CircleShape)
    ) { Icon(icon, desc, tint = Color.White) }
}

@Composable
fun PlayerScreen(a: PlayerActivity) {
    val p = a.player
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(true) }
    var title by remember { mutableStateOf("") }
    var idx by remember { mutableIntStateOf(0) }
    var controls by remember { mutableStateOf(true) }
    var seeking by remember { mutableStateOf(false) }
    var seekVal by remember { mutableFloatStateOf(0f) }
    var hud by remember { mutableStateOf("") }
    var hudKey by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf("") }
    var resize by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var rate by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(Unit) {
        while (true) {
            pos = p.currentPosition; dur = p.duration.coerceAtLeast(0L); playing = p.isPlaying
            title = p.mediaMetadata.title?.toString() ?: ""; idx = p.currentMediaItemIndex
            delay(250)
        }
    }
    LaunchedEffect(controls, playing, seeking, dlg) {
        if (controls && playing && !seeking && dlg == "") { delay(3500); controls = false }
    }
    LaunchedEffect(hudKey) { if (hud.isNotEmpty()) { delay(700); hud = "" } }

    fun flash(s: String) { hud = s; hudKey++ }
    fun seek(sec: Int) {
        val d = p.duration
        val t = (p.currentPosition + sec * 1000L).coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
        p.seekTo(t)
        flash(if (sec > 0) "+${sec}s" else "${sec}s")
    }
    fun toggle() {
        if (p.isPlaying) p.pause() else { if (p.playbackState == Player.STATE_ENDED) p.seekTo(0); p.play() }
    }

    val showLogo = a.audioOnly || a.queue.getOrNull(idx)?.audio == true

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                    setKeepContentOnPlayerReset(true)
                    player = p
                }
            },
            update = { it.resizeMode = resize },
            modifier = Modifier.fillMaxSize()
        )
        if (showLogo) Box(Modifier.fillMaxSize().background(Color(0xFF0A1A4A)), contentAlignment = Alignment.Center) {
            Image(painterResource(R.drawable.resume_logo), null, Modifier.size(140.dp))
        }

        // ---- Gesture layer: taps (zones), vertical swipe (brightness/volume), horizontal swipe (seek) ----
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { controls = !controls },
                        onDoubleTap = { o ->
                            val fx = o.x / size.width
                            val fy = o.y / size.height
                            if (Prefs.doubleTap && fy in 0.12f..0.88f) {
                                if (fx in 0.06f..0.38f) seek(-Prefs.seekSec)
                                else if (fx in 0.62f..0.94f) seek(Prefs.seekSec)
                                else if (fx in 0.40f..0.60f) toggle()
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    var mode = 0
                    val m = 56.dp.toPx()
                    detectVerticalDragGestures(
                        onDragStart = { o ->
                            mode = if (!Prefs.swipe || o.x < m || o.x > size.width - m || o.y < m || o.y > size.height - m) 0
                            else if (o.x < size.width / 2f) 1 else 2
                            a.syncVol()
                        },
                        onDragEnd = { mode = 0 }, onDragCancel = { mode = 0 },
                        onVerticalDrag = { change, dy ->
                            if (mode != 0) {
                                change.consume()
                                val f = -dy / size.height * 1.4f
                                if (mode == 1) flash("Brightness ${a.addBright(f)}%") else flash("Volume ${a.addVolume(f)}%")
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    var ok = false; var acc = 0f; var base = 0L; var target = 0L
                    val m = 56.dp.toPx()
                    detectHorizontalDragGestures(
                        onDragStart = { o ->
                            ok = Prefs.swipe && o.x > m && o.x < size.width - m && o.y > m && o.y < size.height - m
                            acc = 0f; base = p.currentPosition; target = base
                        },
                        onDragEnd = { if (ok) p.seekTo(target); ok = false },
                        onDragCancel = { ok = false },
                        onHorizontalDrag = { change, dx ->
                            if (ok) {
                                change.consume(); acc += dx
                                val d = p.duration
                                target = (base + (acc / size.width * 90000).toLong()).coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
                                flash(fmt(target))
                            }
                        }
                    )
                }
        )

        if (hud.isNotEmpty()) Surface(
            Modifier.align(Alignment.Center), color = Color(0xAA000000), shape = RoundedCornerShape(12.dp)
        ) { Text(hud, color = Color.White, fontSize = 22.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) }

        AnimatedVisibility(controls && !a.inPip, enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize()) {
                Column(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                        .displayCutoutPadding().padding(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { a.finish() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                        Text(title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        IconButton(onClick = { dlg = "settings" }) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(start = 12.dp)) {
                        CtlBtn(Icons.Default.Headphones, "Audio only", a.audioOnly) { a.setAudioOnly(!a.audioOnly) }
                        CtlBtn(Icons.Default.ScreenRotation, "Rotate") {
                            val land = a.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                            a.requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        }
                        CtlBtn(Icons.Default.PictureInPictureAlt, "Picture in picture") { a.enterPip() }
                        CtlBtn(Icons.Default.Equalizer, "Equalizer") { dlg = "eq" }
                        CtlBtn(Icons.Default.AspectRatio, "Aspect ratio") {
                            resize = when (resize) {
                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                            }
                            flash(when (resize) { AspectRatioFrameLayout.RESIZE_MODE_FIT -> "Fit"; AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Crop"; else -> "Stretch" })
                        }
                    }
                }
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                        .displayCutoutPadding().padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(fmt(if (seeking) (seekVal * dur).toLong() else pos), color = Color.White, fontSize = 12.sp)
                        Slider(
                            value = if (seeking) seekVal else if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
                            onValueChange = { seeking = true; seekVal = it },
                            onValueChangeFinished = { p.seekTo((seekVal * dur).toLong()); seeking = false },
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                        )
                        Text(fmt(dur), color = Color.White, fontSize = 12.sp)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { p.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
                        IconButton(onClick = { seek(-Prefs.seekSec) }) { Icon(Icons.Default.FastRewind, "Back", tint = Color.White) }
                        IconButton(onClick = { toggle() }, modifier = Modifier.size(56.dp)) {
                            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", tint = Color.White, modifier = Modifier.size(40.dp))
                        }
                        IconButton(onClick = { seek(Prefs.seekSec) }) { Icon(Icons.Default.FastForward, "Forward", tint = Color.White) }
                        IconButton(onClick = { p.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
                    }
                }
            }
        }
    }

    when (dlg) {
        "settings" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Player settings") },
            text = {
                Column {
                    Text("Speed", style = MaterialTheme.typography.labelLarge)
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { s ->
                                FilterChip(selected = rate == s, onClick = { rate = s; p.setPlaybackSpeed(s) }, label = { Text("${s}x") })
                            }
                        }
                    }
                    Sw("Loop", "Repeat current item", Prefs.loop) {
                        Prefs.loop = it; Prefs.save(); p.repeatMode = if (it) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                    }
                    Sw("Double-tap gestures", "Skip / pause zones", Prefs.doubleTap) { Prefs.doubleTap = it; Prefs.save() }
                    Sw("Swipe gestures", "Volume, brightness, seek", Prefs.swipe) { Prefs.swipe = it; Prefs.save() }
                }
            },
            confirmButton = { TextButton(onClick = { dlg = "" }) { Text("Close") } }
        )
        "eq" -> {
            val e = remember { a.equalizer() }
            AlertDialog(
                onDismissRequest = { dlg = "" }, title = { Text("Equalizer") },
                text = {
                    if (e == null) Text("Equalizer is not available on this device.")
                    else Column {
                        val range = e.bandLevelRange
                        for (i in 0 until e.numberOfBands) {
                            val b = i.toShort()
                            var lvl by remember { mutableFloatStateOf(e.getBandLevel(b).toFloat()) }
                            Text("${e.getCenterFreq(b) / 1000} Hz", style = MaterialTheme.typography.labelMedium)
                            Slider(
                                value = lvl, onValueChange = { lvl = it; e.setBandLevel(b, it.toInt().toShort()) },
                                valueRange = range[0].toFloat()..range[1].toFloat()
                            )
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { dlg = "" }) { Text("Close") } }
            )
        }
    }
}
