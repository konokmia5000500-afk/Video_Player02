# Swift Player (MX Player-style, Kotlin + Jetpack Compose + Media3 ExoPlayer)

## APK বানানোর উপায়
**A) GitHub (সবচেয়ে সহজ, ফোন থেকেও):** ZIP extract করে সব ফাইল একটি নতুন repo-তে upload করুন (`main` branch)।
Actions ট্যাব → "Build APK" → run শেষ হলে Artifacts থেকে `SwiftPlayer-debug-apk` ডাউনলোড করুন।

**B) Android Studio:** File → Open → এই ফোল্ডার → Gradle sync → Build → Build APK(s)।

Requirements: JDK 17, compileSdk 34, minSdk 29 (Android 10+).
